NUSANTARA CYBER-KERATON — TAHAP 28
Distributed Infrastructure Control Plane

FITUR BARU
- Pemeriksaan koneksi PostgreSQL dan Redis (opsional).
- Registry node lokal dengan heartbeat, role, capacity, active task, status, dan metadata.
- PostgreSQL registry table nck_cluster_nodes_v28 jika DSN dikonfigurasi.
- Redis TTL heartbeat key nck:v28:node:<node_id>.
- Redis Streams event bus nck:v28:infra-events untuk event infrastruktur.
- Dashboard Cluster Control Plane dan endpoint monitoring.

ENDPOINT BARU
GET  /api/v28/infrastructure/status
POST /api/v28/cluster/heartbeat
POST /api/v28/cluster/local-heartbeat
GET  /api/v28/cluster/nodes
GET  /api/v28/infrastructure/events?limit=100

KONFIGURASI OPSIONAL
NCK_NODE_ID=<unique-node-id>
NCK_NODE_ROLE=api-worker
NCK_POSTGRES_DSN=postgresql://user:password@host:5432/database
NCK_REDIS_URL=redis://host:6379/0
NCK_WORKER_CONCURRENCY=3

DEPENDENCIES
redis>=5.0,<7
psycopg[binary]>=3.1,<4
Tanpa NCK_POSTGRES_DSN dan NCK_REDIS_URL, aplikasi tetap berjalan dalam mode kompatibilitas SQLite.

MENJALANKAN
1. Ekstrak ZIP, masuk ke NCK_Tahap19_Backend.
2. Buat virtualenv dan install requirements.txt.
3. Atur token NCK_VIEWER_TOKEN, NCK_OPERATOR_TOKEN, NCK_ADMIN_TOKEN.
4. Isi NCK_POSTGRES_DSN dan NCK_REDIS_URL bila layanan tersedia.
5. Jalankan: uvicorn main:app --host 0.0.0.0 --port 8000
6. Buka HTML Tahap 28 dan atur URL backend/token pada Pengaturan AI.

BATASAN PENTING
Tahap 28 adalah control-plane cluster dan integrasi konektivitas. PostgreSQL baru menyimpan registry node Tahap 28; Redis menyimpan heartbeat dan event infrastruktur. Database inti task, memory, workflow, governance, serta eksekusi task masih memakai SQLite Tahap 27. Karena itu jangan mengaktifkan beberapa host worker untuk mengeksekusi task yang sama pada tahap ini. Eksekusi terdistribusi lintas-host baru dinyatakan siap setelah migrasi penuh data plane dan implementasi worker consumer bersama pada Tahap 29.

SECURITY
- Jangan commit DSN, password, atau token ke HTML/repository publik.
- Gunakan TLS/private network untuk PostgreSQL dan Redis pada deployment produksi.
- Batasi akses endpoint operator melalui token dan jaringan internal.
- Redis event stream tidak berisi API key.
