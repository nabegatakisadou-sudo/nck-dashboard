NUSANTARA CYBER-KERATON — TAHAP 21
Enterprise AI Agent Execution & Real Multi-Agent Collaboration

ISI PAKET
- Nusantara_Cyber_Keraton_Tahap21.html: dashboard lengkap, mempertahankan HTML Tahap 20 dan menambahkan panel Tahap 21.
- NCK_Tahap19_Backend/main.py: backend kompatibel dengan endpoint Tahap 19, 20, dan 21.
- requirements.txt: dependensi Python.
- .env.example: contoh konfigurasi rahasia server.

PEMBARUAN BACKEND
1. Cadangkan folder backend dan database nck_enterprise.db yang sekarang.
2. Ganti main.py backend lama dengan main.py dari paket ini.
3. Pertahankan environment variable token Tahap 19: NCK_VIEWER_TOKEN, NCK_OPERATOR_TOKEN, NCK_ADMIN_TOKEN.
4. Tambahkan OPENAI_API_KEY atau GEMINI_API_KEY pada environment server. Opsional: OPENAI_MODEL dan GEMINI_MODEL.
5. Set NCK_CORS_ORIGINS ke origin frontend yang benar; jangan gunakan wildcard untuk produksi.
6. Install dependensi: pip install -r requirements.txt
7. Jalankan: uvicorn main:app --host 0.0.0.0 --port 8000
8. Backup database sebelum update. Skema Tahap 21 ditambahkan otomatis saat startup; data Tahap 19/20 tidak dihapus.

CARA PAKAI
1. Buka HTML Tahap 21 di browser.
2. Masukkan URL backend dan token Operator/Admin pada panel Tahap 21.
3. Uji status backend. Pastikan provider API key sudah terkonfigurasi di server.
4. Atur workflow, agen, instruksi, dan dependensi.
5. Buat workflow, lalu setujui melalui Approval Gate.
6. Pantau status melalui Workflow ID dan Usage Monitor.

ENDPOINT TAHAP 21
GET  /api/v21/status
GET  /api/v21/agents
POST /api/v21/workflows
GET  /api/v21/workflows
GET  /api/v21/workflows?status=pending_approval
POST /api/v21/workflows/{id}/approve
GET  /api/v21/workflows/{id}
GET  /api/v21/usage

FITUR
- Eksekusi AI sungguhan melalui OpenAI atau Gemini di backend.
- Enam agen spesialis pertama berdasarkan nama/role yang sudah diberikan dalam spesifikasi proyek.
- Dependensi DAG dan eksekusi paralel maksimal empat langkah independen.
- Hasil agen dependensi diteruskan sebagai konteks.
- AI Reviewer, skor, feedback, retry, dan status per langkah.
- Pencatatan panggilan dan token usage yang dilaporkan provider.

BATASAN & KEAMANAN
- Daftar spesialis yang terdefinisi pada sumber proyek hanya enam agen pertama. Empat puluh empat agen lainnya belum diberi identitas/konfigurasi spesialis sehingga tidak dipalsukan pada tahap ini.
- Tahap ini memakai FastAPI BackgroundTasks dan SQLite agar kompatibel dengan backend sebelumnya. Untuk skala produksi, migrasikan worker ke antrean persisten dan database server.
- Provider online belum dapat dinyatakan lolos uji end-to-end tanpa kredensial provider, server deployment, dan koneksi internet yang valid.
- Token API tidak pernah dikirim ke frontend. Jangan memasukkan API key provider ke HTML.
- Aktifkan HTTPS, batasi CORS, rate limiting, backup, monitoring, dan rotasi token sebelum publikasi.
- Usage token mengikuti data yang dikembalikan provider; biaya uang tidak dihitung otomatis.
