NUSANTARA CYBER-KERATON — TAHAP 23
Autonomous Agent Operations & Real-Time Command Center

BASIS
Tahap 23 dikembangkan langsung dari paket Tahap 22. HTML dan backend Tahap 20–22 tetap disertakan.

FITUR
1. Persistent task execution queue (status tersimpan di SQLite).
2. Eksekusi task Tahap 22 oleh agen AI melalui OpenAI/Gemini backend.
3. Konteks otomatis: Shared Knowledge Base, memori khusus agen, dan komunikasi sebelumnya.
4. AI Supervisor quality gate, skor, feedback, dan retry otomatis.
5. Hasil sukses disimpan ke task dan ditambahkan sebagai memori pengalaman agen.
6. Event log, detail eksekusi, filter status, dan monitoring antrean.
7. Pemulihan task berstatus running menjadi queued saat backend startup.

ENDPOINT BARU
GET  /api/v23/status
POST /api/v23/tasks/{task_id}/execute
POST /api/v23/queue/dispatch
GET  /api/v23/operations?status=queued|running|completed|failed
GET  /api/v23/tasks/{task_id}/execution

INSTALASI
Gunakan langkah instalasi Tahap 22: pip install -r requirements.txt; salin .env.example ke .env; isi token dan API key provider pada server; jalankan uvicorn main:app --host 0.0.0.0 --port 8000. Backup database sebelum upgrade.

CATATAN TEKNIS DAN BATASAN
- Task execution disimpan persisten pada SQLite, termasuk status, hasil, retry, review, dan event log.
- Eksekusi background pada versi ini menggunakan FastAPI BackgroundTasks dalam satu proses. Ini bukan distributed worker dan tidak menjamin job aktif tetap berjalan jika proses dihentikan paksa. Task berstatus running dikembalikan ke queued pada startup; operator dapat menjalankan dispatch lagi.
- Untuk produksi multi-instance, gunakan PostgreSQL + Redis/Celery atau queue durable, worker terpisah, HTTPS, rate limit, backup, dan observability.
- Provider AI nyata memerlukan OPENAI_API_KEY atau GEMINI_API_KEY pada backend. Jangan masukkan API key ke HTML.
- Enam identitas agen resmi tetap sama; tidak menambah nama agen tanpa spesifikasi.

VALIDASI
Jalankan py_compile pada main.py. Uji API dan eksekusi AI nyata memerlukan server, token, dan provider credential.
