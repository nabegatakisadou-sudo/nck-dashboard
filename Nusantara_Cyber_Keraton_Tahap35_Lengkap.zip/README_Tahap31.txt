NUSANTARA CYBER-KERATON — TAHAP 31
Security Hardening & Audit Controls

ISI PAKET
- Dashboard Tahap 31; seluruh dashboard tahap sebelumnya dipertahankan.
- Backend API dengan security middleware dan endpoint keamanan Tahap 31.
- Konfigurasi environment dan docker-compose.stage31.yml.

PENINGKATAN
1. Perbandingan digest token menggunakan constant-time compare.
2. Security response headers: nosniff, frame deny, referrer policy, permissions policy, CORP; HSTS hanya saat HTTPS/force HTTPS.
3. Batas ukuran request berbasis Content-Length.
4. Rate limit umum dan endpoint mahal dengan bucket in-process.
5. Audit event keamanan, termasuk rate-limit dan exception.
6. Validasi konfigurasi fail-closed saat NCK_ENV=production: tiga token unik minimal 32 karakter dan CORS exact allowlist tanpa wildcard.
7. Endpoint status keamanan dan event admin.
8. Docker Compose membatasi port API ke loopback dan mengaktifkan no-new-privileges.

ENDPOINT
GET  /api/v31/status
GET  /api/v31/security/status (authenticated)
GET  /api/v31/security/events?limit=50 (admin only)
POST /api/v31/security/test-event (operator/admin)

PENTING
- Rate limiter bawaan bersifat per proses dan tidak berbagi state antar instance. Untuk produksi multi-instance, pasang WAF/API gateway atau Redis-backed limiter.
- TLS/HTTPS harus dikonfigurasi pada reverse proxy/load balancer tepercaya; jangan expose API plain HTTP ke internet. HSTS tidak menggantikan TLS.
- Token harus dihasilkan dengan CSPRNG, disimpan pada secret manager, tidak ditaruh di HTML/JS, dan dirotasi melalui deployment. Jangan menggunakan nilai contoh .env.
- CORS hanya mengatur browser; bukan mekanisme autentikasi.
- Tahap 31 belum merupakan sertifikasi keamanan atau pentest. Belum dilakukan pengujian eksternal, fuzzing, load test, threat-model review formal, maupun deployment multi-instance.
- Sistem aplikasi tetap menggunakan SQLite pada tahap ini; Tahap 32 adalah cutover PostgreSQL.
- Eksekusi AI multi-host masih memerlukan executor adapter yang idempotent dan integrasi worker; bukan bagian yang diklaim selesai pada Tahap 31.

PENGUJIAN LOKAL
1. Install requirements.txt dan gunakan NCK_ENV=development.
2. Set NCK_DB_PATH ke database sementara dan token viewer/operator/admin yang berbeda.
3. Jalankan: uvicorn main:app --host 127.0.0.1 --port 8000.
4. Uji /health, /api/v31/status, /api/v31/security/status, /api/v31/security/test-event.
5. Verifikasi admin-only /api/v31/security/events, security headers, 413 body limit, dan 429 rate limit.
6. Uji production startup hanya dengan secret random unik >=32 karakter dan CORS origin exact.

STATUS
Tahap 31 menambahkan kontrol aplikasi dasar dan konfigurasi fail-closed. Status produksi tetap belum diberikan sampai reverse proxy/TLS, shared rate limiting, secret management, pentest, observability, dan pengujian pada infrastruktur nyata selesai.
