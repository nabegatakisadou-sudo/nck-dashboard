NUSANTARA CYBER-KERATON — TAHAP 27
Distributed-Ready AI Workforce & Persistent Queue Infrastructure

FITUR BARU
- SQLite persistent task queue with atomic task leases.
- Worker pool multi-thread dengan kapasitas NCK_WORKER_CONCURRENCY (default 3, maksimum 16).
- Pause/resume worker pool; task aktif dibiarkan selesai, worker tidak mengambil task baru saat pause.
- Retry manual khusus task failed.
- Queue events, worker registry, heartbeat, dan pemantauan kapasitas.
- Pemulihan antrean saat service restart melalui tahap init sebelumnya dan pemulihan lease.
- Dashboard Tahap 27 ditambahkan tanpa menghapus modul Tahap 20–26.

ENDPOINT BARU
GET  /api/v27/status
GET  /api/v27/queue
GET  /api/v27/events?limit=100
POST /api/v27/workers/control   {"paused":true|false,"reason":"..."}
POST /api/v27/queue/retry       {"task_id":123}

KONFIGURASI
NCK_WORKER_CONCURRENCY=3
NCK_DB_PATH=./nck_enterprise.db (opsional)
Token tetap melalui NCK_VIEWER_TOKEN, NCK_OPERATOR_TOKEN, NCK_ADMIN_TOKEN.
Provider key tetap hanya di environment backend: OPENAI_API_KEY / GEMINI_API_KEY.

CARA MENJALANKAN
1. Ekstrak ZIP.
2. Masuk ke NCK_Tahap19_Backend.
3. Buat virtualenv, install requirements.txt.
4. Salin .env.example menjadi .env dan isi token + provider key yang diperlukan.
5. Jalankan: uvicorn main:app --host 0.0.0.0 --port 8000
6. Buka HTML Tahap 27, isi URL backend dan token pada Pengaturan AI seperti tahap sebelumnya.

CATATAN ARSITEKTUR PENTING
Rilis ini adalah persistent worker pool dalam satu proses API dengan beberapa thread, bukan worker multi-host penuh. Task queue dan lease tersimpan di SQLite, dan task queued dapat dipulihkan setelah restart. Untuk deployment multi-process/multi-host yang benar-benar horizontal, tahap lanjutan perlu memindahkan antrean/lease ke PostgreSQL dan broker seperti Redis/RabbitMQ, serta menambahkan heartbeat lease expiry/renewal lintas host. Jangan menjalankan beberapa proses Uvicorn worker dengan SQLite pada mode ini karena startup recovery tiap proses dapat saling memengaruhi.

VALIDASI
Python compile dan endpoint smoke/integration test perlu dijalankan pada paket deployment. AI provider live memerlukan API key backend yang valid.
