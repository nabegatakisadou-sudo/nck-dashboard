NUSANTARA CYBER-KERATON — TAHAP 30
Release Reliability Candidate: backup, readiness, diagnostics, Redis worker recovery

ISI PAKET
- Nusantara_Cyber_Keraton_Tahap30.html: dashboard Tahap 30 (mempertahankan modul Tahap 20–29).
- NCK_Tahap19_Backend/main.py: API lama + endpoint operasi Tahap 30.
- worker_service_v30.py: consumer Redis Streams dengan reclaim pending dan dead-letter.
- docker-compose.stage30.yml: contoh deployment API dan worker.
- .env.example: konfigurasi tambahan.

ENDPOINT BARU
GET  /api/v30/status
GET  /api/v30/health/ready
GET  /api/v30/ops/diagnostics (operator/admin)
POST /api/v30/backup/create (operator/admin)
GET  /api/v30/backup/list (operator/admin)

KEAMANAN DAN OPERASI
- Endpoint memakai autentikasi X-NCK-Token sesuai role yang ada.
- Backup memakai SQLite online backup API, integrity_check, SHA-256, dan retensi terbatas.
- Direktori backup harus berada di volume privat, bukan folder publik web.
- Worker mengandalkan adapter eksternal yang wajib menerapkan idempotency key.
- Pesan gagal tetap pending untuk recovery; setelah batas delivery dipindahkan ke DLQ.
- Simpan token, DSN, dan API key hanya di environment/secret manager server.

BATASAN YANG TIDAK BOLEH DIANGGAP SELESAI
- Database aplikasi utama masih SQLite compatibility mode. PostgreSQL hanya infrastruktur ops/migrasi dari tahap sebelumnya, belum cutover seluruh data.
- Redis worker masih memanggil executor adapter eksternal; worker tidak langsung menjalankan enam agen.
- Multi-host AI execution belum aktif/terbukti. Adapter harus mengunci dispatch_id secara atomik dan memperbarui state task secara otoritatif.
- Belum ada uji beban, uji failover lintas mesin, pentest, atau validasi backup-restore pada server produksi.
- Docker Compose adalah template deployment; sesuaikan Dockerfile/paths, secrets, health checks, TLS reverse proxy, dan persistent volumes sebelum dipakai.

PENGUJIAN LOKAL
1. Buat virtualenv dan install requirements.txt.
2. Set NCK_DB_PATH ke file SQLite yang dapat ditulis; set token viewer/operator/admin acak.
3. Jalankan API: uvicorn main:app --host 127.0.0.1 --port 8000.
4. Panggil endpoint dengan header X-NCK-Token.
5. POST /api/v30/backup/create lalu GET /api/v30/backup/list.
6. Untuk Redis worker, siapkan Redis dan adapter executor yang idempotent sebelum mengaktifkan dispatch.

Tahap 30 adalah kandidat reliabilitas operasional, bukan klaim sistem production-perfect. Status produksi final baru dapat diberikan setelah cutover database, adapter agen, staging dengan layanan nyata, pemulihan backup, uji keamanan, dan uji beban berhasil dilakukan.

PEMULIHAN BACKUP (RESTORE)
- Hentikan API dan seluruh worker sebelum restore.
- Validasi tanpa mengubah file: python tools/restore_sqlite_backup.py --backup ./backups/nck_sqlite_....db --target ./nck_enterprise.db --dry-run
- Jalankan restore: python tools/restore_sqlite_backup.py --backup ./backups/nck_sqlite_....db --target ./nck_enterprise.db
- Tool membuat safety copy database lama secara default, memvalidasi integrity_check/quick_check, lalu mengganti file secara atomik.
- Uji prosedur restore pada staging terlebih dahulu. Jangan jalankan saat proses API masih aktif.

Docker Compose
- Siapkan file NCK_Tahap19_Backend/.env dari .env.example dan ganti seluruh token/password placeholder.
- Set POSTGRES_PASSWORD dan REDIS_PASSWORD melalui environment deployment, bukan commit ke repository.
- Jalankan: docker compose -f docker-compose.stage30.yml up -d --build
- Worker distributed berada dalam profile opsional dan tidak boleh diaktifkan sebelum NCK_V29_EXECUTOR_URL/TOKEN menunjuk adapter yang sudah diuji idempotency.
