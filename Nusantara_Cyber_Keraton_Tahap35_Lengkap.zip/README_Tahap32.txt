NUSANTARA CYBER-KERATON — TAHAP 32
PostgreSQL Migration Readiness & Controlled Cutover Gates

PENAMBAHAN
- Endpoint read-only /api/v32/status dan /api/v32/database/readiness.
- Pemeriksaan SQLite integrity_check, foreign_key_check, daftar tabel dan row count.
- Pemeriksaan konektivitas PostgreSQL (jika NCK_POSTGRES_DSN diatur) dan row count tabel target.
- Tool migrasi v32: snapshot SQLite online, pemeriksaan sumber, transaksi PostgreSQL, pembuatan tabel, FK komposit, pemindahan data batch, row-count verification, migration ledger. Target yang sudah berisi data ditolak kecuali flag penggantian data diberikan secara eksplisit.
- Tool audit schema portabilitas untuk menginventarisasi tabel, index, FK, view, trigger dan objek yang perlu ditinjau manual.

CARA AUDIT SUMBER
python tools/audit_sqlite_schema_v32.py --sqlite ./nck_enterprise.db --output ./nck_schema_audit_v32.json

SIMULASI / MIGRASI
python tools/migrate_sqlite_to_postgres_v32.py --sqlite ./nck_enterprise.db --postgres "$NCK_POSTGRES_DSN" --dry-run
python tools/migrate_sqlite_to_postgres_v32.py --sqlite ./nck_enterprise.db --postgres "$NCK_POSTGRES_DSN" --snapshot
# Jika schema target memang boleh dikosongkan/diganti (destruktif, transaction-protected):
python tools/migrate_sqlite_to_postgres_v32.py --sqlite ./nck_enterprise.db --postgres "$NCK_POSTGRES_DSN" --snapshot --replace-target-data
python tools/migrate_sqlite_to_postgres_v32.py --sqlite ./nck_enterprise.db --postgres "$NCK_POSTGRES_DSN" --verify-only

PERINGATAN TEKNIS PENTING
1. Aplikasi utama masih menggunakan sqlite3 dan SQLite. Tahap ini TIDAK mengubah koneksi runtime ke PostgreSQL dan tidak mengklaim cutover selesai.
2. Migrasi tidak menghapus database sumber. Snapshot konsisten dibuat melalui SQLite backup API.
3. Migrasi data dan pembuatan skema berjalan dalam satu transaksi PostgreSQL. Default-nya menolak target yang sudah berisi data. --replace-target-data bersifat destruktif: TRUNCATE semua tabel target yang dimigrasikan dengan CASCADE, namun perubahan tetap berada dalam transaksi PostgreSQL dan dapat rollback jika gagal. Gunakan hanya pada schema staging khusus NCK.
4. Trigger dan view hanya diinventarisasi. Indeks kompleks/parsial dan ekspresi, generated columns, CHECK constraints, collation, serta trigger perlu konversi manual sebelum produksi. Tipe SQLite yang dinamis dipetakan ke tipe PostgreSQL generik; validasi domain data tetap wajib.
5. Verifikasi jumlah baris bukan pengganti validasi checksum konten, constraint semantics, query behavior, concurrency, dan regression seluruh endpoint.
6. --verify-only membandingkan jumlah baris sumber dan target tanpa menyalin data.
7. Jangan arahkan aplikasi ke PostgreSQL sampai adapter database lintas semua modul, regression test, migrasi final, rollback rehearsal, dan backup restore test selesai.

ENDPOINT
GET /api/v32/status (authenticated)
GET /api/v32/database/readiness (operator/admin)

PENGUJIAN LOKAL
- python -m py_compile main.py tools/migrate_sqlite_to_postgres_v32.py tools/audit_sqlite_schema_v32.py
- Jalankan backend dengan NCK_DB_PATH ke database uji.
- Uji endpoint readiness; tanpa DSN, endpoint harus menyatakan PostgreSQL belum dikonfigurasi.
- Audit schema pada database uji dan tinjau seluruh objek non-table.
- PostgreSQL live migration belum dapat diklaim lulus tanpa server PostgreSQL aktif.

STATUS
Tahap 32 menyelesaikan fondasi migrasi terkendali, audit skema, snapshot, verifikasi jumlah data, dan readiness gate. PostgreSQL production cutover belum dilakukan.
