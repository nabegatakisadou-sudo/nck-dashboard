NUSANTARA CYBER-KERATON — TAHAP 20
Autonomous Agent Orchestration & Workflow Engine

Paket berisi:
- Nusantara_Cyber_Keraton_Tahap20.html
- Folder NCK_Tahap19_Backend: backend Tahap 19 yang diperluas dengan endpoint workflow Tahap 20.
- README_Tahap20.txt

CARA UPDATE BACKEND
1. Buat cadangan folder backend Tahap 19 dan file nck_enterprise.db.
2. Ganti main.py lama dengan main.py dari paket ini (requirements Tahap 19 tetap digunakan).
3. Jalankan kembali: uvicorn main:app --host 0.0.0.0 --port 8000
4. Database workflow Tahap 20 dibuat otomatis saat startup.
5. Gunakan token Operator/Admin dari konfigurasi Tahap 19.

CARA MENGGUNAKAN
1. Buka HTML Tahap 20.
2. Masukkan Base URL backend dan token Operator, lalu simpan.
3. Buat workflow dengan nama, instruksi, dan langkah satu per baris.
4. Workflow masuk status pending_approval.
5. Muat workflow menunggu, lalu klik Setujui & jalankan.
6. Pantau progres menggunakan ID workflow.

ENDPOINT TAMBAHAN
GET /api/v20/status
POST /api/v20/workflows
GET /api/v20/workflows
GET /api/v20/workflows?status=pending_approval
POST /api/v20/workflows/{id}/approve
GET /api/v20/workflows/{id}

BATASAN
- Engine ini mengelola lifecycle workflow, status langkah, approval, dan retry.
- Langkah saat ini adalah checkpoint orchestration dan pencatatan hasil, bukan pemanggilan LLM untuk setiap langkah.
- Workflow diproses berurutan per workflow. Belum ada worker queue eksternal, eksekusi paralel lintas langkah, websocket realtime, atau integrasi otomatis dengan 50 agent.
- BackgroundTasks berjalan dalam proses API; untuk produksi gunakan antrean persisten seperti Celery/RQ/Arq dan database PostgreSQL.
- Validasi syntax bukan pengganti pengujian deployment end-to-end.
