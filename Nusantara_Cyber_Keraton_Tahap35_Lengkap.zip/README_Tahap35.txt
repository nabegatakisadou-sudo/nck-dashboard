NUSANTARA CYBER-KERATON — TAHAP 35
Operasi & Produksi: database permanen, backup terverifikasi, latihan restore, pemantauan, rotasi token

Tanggal build: 2026-11-21
Status jujur: paket ini memberi ALAT dan PEMERIKSAAN untuk menjalankan NCK sebagai layanan nyata. Paket ini
TIDAK menyatakan NCK "siap produksi". Itu keputusan Anda setelah daftar periksa lulus dan batas di bagian 9 dibaca.
Yang saya nyatakan "lulus" adalah hasil uji nyata di sesi pengembangan. Bukti terkuat tetap hasil hijau GitHub
Actions milik Anda sendiri (langkah C). Hasil CI untuk perbaikan Tahap 34 (run ke-3) BELUM saya lihat: jalankan ulang.


1. ISI PAKET (yang baru / berubah di Tahap 35)
- Nusantara_Cyber_Keraton_Tahap35.html          dashboard: panel "Operasi & Produksi" (kesiapan, metrik, riwayat backup, pembuat token)
- NCK_Tahap19_Backend/nck_ops_v35.py            modul operasi: /ready, /api/v35/ops/*
- NCK_Tahap19_Backend/main.py                   rotasi token (*_PREVIOUS), validasi start produksi, versi 35.0.0
- NCK_Tahap19_Backend/tools/pg_backup_v35.sh    backup PostgreSQL terverifikasi + terenkripsi
- NCK_Tahap19_Backend/tools/restore_drill_v35.sh latihan restore ke database sementara + perbandingan isi
- NCK_Tahap19_Backend/tools/prod_preflight_v35.py uji asap URL produksi (HTTPS, header, CORS, kesiapan)
- NCK_Tahap19_Backend/tools/report_backup_v35.py  lapor hasil backup/latihan ke dashboard
- NCK_Tahap19_Backend/tools/pgtools_v35.sh, dsn_with_db_v35.py  pembantu (pilih pg_dump yang versinya cocok dengan server)
- NCK_Tahap19_Backend/tests/                    uji baru (bagian 7)
- render.yaml                                   cetak biru Render (OPSIONAL)
- .github/workflows/nck-ci.yml                  CI yang diperbarui (ganti isi lama; langkah B)
- .github/workflows/nck-ops.yml                 BARU: smoke / backup / restore-drill (buat file; langkah B)
- PENUTUP_PROYEK_NCK.txt                        peta tahap, yang terbukti vs belum, kalender operasi


2. FAKTA PLATFORM YANG MEMENGARUHI RANCANGAN (per 21 Nov 2026, dari dokumentasi masing-masing; periksa ulang bila penting)
- Render paket Free: disk SEMENTARA (data SQLite hilang saat restart/deploy) dan layanan tidur setelah 15 menit tanpa
  trafik (permintaan pertama sekitar 1 menit). Karena itu produksi WAJIB memakai PostgreSQL di luar Render.
- Postgres gratis milik Render kedaluwarsa dalam 30 hari dan tanpa backup, jadi TIDAK dipakai di sini.
- Rekomendasi database: Neon (paket Free). Yang saya baca: 1 GB penyimpanan, 100 CU-jam per bulan, komputasi tidur otomatis
  setelah 5 menit, pemulihan titik-waktu sekitar 6 jam. Angka dapat berubah; cek halaman harga Neon sebelum bergantung padanya.
- Jangan membuat "pemanggil" yang menembak server tiap beberapa menit untuk menjaganya tetap bangun: itu menghabiskan jatah
  CU-jam Neon. /health tidak menyentuh database; /ready dan /api/v35/ops/* menyentuh database (membangunkan Neon).
- Render menjadikan Python 3.14 bawaan untuk layanan baru; NCK diuji di CI pada 3.12, maka dipatok PYTHON_VERSION=3.12.11.


3. LANGKAH DI HP (urut, satu per satu)

A. Unggah ZIP ke repo
   1. Repo > tab "Code" > "Add file" > "Upload files".
   2. Pilih Nusantara_Cyber_Keraton_Tahap35_Lengkap.zip > tunggu 100% > "Commit changes".
   ZIP lama boleh dibiarkan: workflow memilih ZIP Tahap 34/35 yang commit-nya PALING BARU.

B. Workflow (WAJIB ditempel manual; GitHub melarang proses otomatis menulis file workflow)
   1. Ganti isi nck-ci.yml:  Code > .github > workflows > nck-ci.yml > ikon pensil > hapus semua > tempel isi baru > Commit.
   2. Buat nck-ops.yml:  Code > "Add file" > "Create new file" > ketik nama persis
        .github/workflows/nck-ops.yml
      (ketik "/" untuk membuat folder) > tempel isi nck-ops.yml dari pesan saya > Commit.

C. Jalankan NCK CI (bukti bahwa kode lulus di mesin asli)
   1. Tab "Actions" > "NCK CI" > "Run workflow" > "Run workflow". Tunggu ±15-25 menit.
   2. Hijau = semua uji di bagian 7 lulus. Merah = ketuk langkah yang merah, salin ±30 baris terakhir lognya, kirim ke saya.
   Peringatan kuning "Node.js 20 deprecated" aman diabaikan.

D. Database permanen (Neon) — hanya setelah C hijau
   1. neon.com > daftar > "Create project" (pilih wilayah terdekat, mis. Singapore).
   2. Di halaman project > "Connect": MATIKAN pilihan "Connection pooling" (kita butuh koneksi LANGSUNG, hostnya tanpa "-pooler").
   3. Salin connection string. Bentuk: postgresql://USER:SANDI@HOST/DB?sslmode=require
      (bila ada tambahan &channel_binding=require, biarkan). Simpan di pengelola kata sandi. Ini rahasia.
   4. Biarkan skema "public". Tabel dibuat otomatis oleh NCK saat start pertama.
   Data SQLite lama di Render Free memang tidak permanen. Bila ada data yang ingin dibawa, tanyakan ke saya
   (alat tools/migrate_sqlite_to_postgres_v33.py ada, tetapi butuh file SQLite itu; tanpa file itu tidak ada yang dibawa).

E. Token & sandi acak
   1. Buka dashboard Tahap 35 > kartu "04 · PEMBUAT TOKEN ACAK" > "Buat token baru".
      (Layar HP: pakai kotak "Lompat ke panel" di kanan bawah untuk menuju panel Tahap 35.)
   2. Anda mendapat 4 nilai: VIEWER, OPERATOR, ADMIN, dan SANDI BACKUP. Salin satu per satu ke pengelola kata sandi.
      Nilai ini hanya ada di layar Anda; tidak dikirim dan tidak disimpan. Hapus dari layar setelah disalin.
   3. SANDI BACKUP: bila hilang, backup terenkripsi TIDAK bisa dibuka oleh siapa pun, termasuk saya.

F. Render
   Bila layanan Render sudah ada: tidak perlu layanan baru; ubah Start Command dan Environment saja.
   Bila belum: Render > New + > Web Service > pilih repo > isi:
     Root Directory : NCK_Tahap19_Backend
     Build Command  : pip install -r requirements.txt
     Start Command  : uvicorn main:app --host 0.0.0.0 --port ${PORT:-10000}
     Instance Type  : Free        Health Check Path: /health        Auto-Deploy: Off (deploy manual = rollback terkendali)
   Environment (Render > service > Environment). Isi persis:
     NCK_ENV               production
     NCK_DB_BACKEND        postgres
     NCK_POSTGRES_DSN      (string Neon dari langkah D)
     NCK_VIEWER_TOKEN      (dari langkah E)
     NCK_OPERATOR_TOKEN    (dari langkah E)
     NCK_ADMIN_TOKEN       (dari langkah E)
     NCK_CORS_ORIGINS      https://AKUN.github.io     (alamat ASAL dashboard Anda, tanpa garis miring akhir, tanpa *)
     NCK_FORCE_HTTPS       1
     FORWARDED_ALLOW_IPS   *
     PYTHON_VERSION        3.12.11
     NCK_WORKER_MODE       both
   Nama menu Render bisa sedikit berbeda dari tulisan saya; yang penting nilainya sama.
   Lalu "Manual Deploy" > "Deploy latest commit". Pantau tab "Logs".
   Bila server MENOLAK START dengan pesan "produksi": itu disengaja (token lemah/sama, CORS kosong atau "*").
   Baca pesannya di Logs, perbaiki variabelnya, deploy ulang.

   CATATAN CORS PENTING: server produksi hanya menerima dashboard dari alamat yang tercantum di NCK_CORS_ORIGINS.
   Dashboard yang dibuka sebagai berkas lokal di HP (file://) punya asal "null" dan AKAN DIBLOKIR. Sajikan dashboard
   dari alamat https, mis. GitHub Pages: Repo > Settings > Pages > Source "Deploy from a branch" > main / (root) > Save.
   Alamat dashboard: https://AKUN.github.io/NAMA-REPO/Nusantara_Cyber_Keraton_Tahap35.html, dan asalnya (untuk
   NCK_CORS_ORIGINS) hanya https://AKUN.github.io. (GitHub Pages untuk repo privat memerlukan paket berbayar GitHub.)

G. Rahasia GitHub dan uji asap
   1. Repo > Settings > Secrets and variables > Actions > "New repository secret". Buat:
        NCK_BASE_URL          https://NAMA-LAYANAN.onrender.com     (tanpa garis miring akhir)
        NCK_VIEWER_TOKEN      token viewer produksi
        NCK_ADMIN_TOKEN       token admin produksi          (opsional; agar hasil backup tampil di dashboard)
        NCK_FRONTEND_ORIGIN   https://AKUN.github.io        (opsional; uji CORS positif)
        NCK_BACKUP_DSN        string Neon langsung (sama seperti NCK_POSTGRES_DSN)
        NCK_BACKUP_PASSPHRASE sandi backup dari langkah E
   2. Actions > "NCK Ops" > Run workflow > aksi "smoke" > Run. Tunggu sampai ±3 menit (server tidur butuh waktu bangun).
      Hijau = HTTPS, /health, /ready, penolakan tanpa token, header keamanan, CORS, dan kesiapan dari server lulus.
      Merah = ketuk langkahnya, kirim ±30 baris terakhir log ke saya.

H. Backup pertama dan latihan restore (jangan dilewati: backup yang belum pernah dipulihkan belum terbukti)
   1. Actions > "NCK Ops" > Run workflow > aksi "backup". Hijau = dump valid, semua tabel ada, terenkripsi, sha256 dicatat,
      disimpan sebagai artifact "nck-backup" (30 hari). Backup otomatis berikutnya berjalan tiap hari 03:17 WIB.
   2. Setelah backup hijau: Run workflow > aksi "restore-drill". Skrip mengambil backup TERBARU, memulihkannya ke server
      PostgreSQL sementara (docker di runner GitHub), lalu membandingkan jumlah baris setiap tabel dengan sumbernya.
      Hijau = backup itu terbukti bisa dipulihkan.
   3. Buka dashboard > "Periksa kesiapan": item "Backup terverifikasi terbaru" dan "Latihan restore terbaru" menjadi LULUS
      (butuh rahasia NCK_BASE_URL dan NCK_ADMIN_TOKEN agar dilaporkan).

I. Dashboard
   1. Buka dashboard Tahap 35 dari alamat https (langkah F). Isi URL backend dan token di panel Backend Connection (Tahap 19).
   2. Kartu 01 "Periksa kesiapan": baca dari atas (GAGAL dan CATATAN muncul lebih dulu; tiap butir memuat "Perbaikan").
   3. Kartu 02 metrik, kartu 03 riwayat backup (butuh token operator atau admin).
   Panel hanya membaca. Tidak ada pemanggilan otomatis, jadi tidak membangunkan Render/Neon tanpa Anda sadari.


4. ROTASI TOKEN TANPA DOWNTIME (sebulan sekali, atau segera bila token dicurigai bocor)
   1. Buat token baru (kartu 04).
   2. Render > Environment, untuk setiap peran yang dirotasi (mis. admin): buat NCK_ADMIN_TOKEN_PREVIOUS = token LAMA,
      lalu ubah NCK_ADMIN_TOKEN = token BARU. Simpan (layanan restart; sekitar 1 menit).
      Token lama tetap berlaku HANYA pada perannya sendiri (token viewer lama tidak pernah naik jadi admin).
   3. Perbarui token di dashboard dan di GitHub Secrets (NCK_VIEWER_TOKEN, NCK_ADMIN_TOKEN).
   4. "Periksa kesiapan": butir "Rotasi token" tampil CATATAN dan menyebut kapan token lama terakhir dipakai (menit lalu).
   5. Bila token lama sudah tidak dipakai siapa pun: HAPUS variabel *_PREVIOUS > simpan. Token lama langsung ditolak.
   Token PREVIOUS harus >=32 karakter dan tidak boleh sama dengan token aktif (produksi menolak start bila melanggar).
   Waktu pemakaian terakhir token lama tersimpan di memori satu proses dan hilang saat restart.
   Rotasi sandi backup: buat sandi baru, ganti rahasia NCK_BACKUP_PASSPHRASE, jalankan backup baru. Backup LAMA tetap butuh
   sandi LAMA: simpan sandi lama selama backup lama masih Anda perlukan (artifact hilang setelah 30 hari).


5. RILIS DAN ROLLBACK
   - Rilis: unggah ZIP baru > jalankan NCK CI sampai hijau > Render "Manual Deploy" > NCK Ops "smoke" > "Periksa kesiapan".
   - Rollback kode: Render > service > Events/Deploys > pilih deploy sebelumnya yang sukses > Rollback (nama tombol bisa berbeda).
     Perubahan skema Tahap 35 bersifat penambahan (tabel baru ops_backups_v35), sehingga kode lama tetap bisa berjalan di
     database yang sama. Rollback kode TIDAK mengembalikan DATA.
   - Pulihkan DATA: lihat bagian 9, poin "celah terbesar".


6. KALENDER OPERASI SINGKAT
   - Setiap selesai deploy : NCK Ops "smoke" + "Periksa kesiapan".
   - Harian (otomatis)      : backup 03:17 WIB. Cek email/notifikasi GitHub bila merah.
   - Mingguan               : buka dashboard, kartu 01 dan kartu 03; pastikan backup terakhir < 36 jam.
   - Bulanan                : "restore-drill" dan rotasi token.
   - Tiap ±45 hari          : buka repo (commit kecil / jalankan workflow manual). GitHub menonaktifkan workflow terjadwal
                              di repo publik bila tidak ada aktivitas 60 hari; backup otomatis berhenti diam-diam.
   Daftar periksa insiden (layanan tidak menjawab):
   1. Buka <url>/health. Tidak menjawab > 1 menit = Render tidur/bangun; tunggu. Tetap gagal > lihat Render Logs.
   2. /health OK tetapi /ready 503 = database tidak terjangkau: cek Neon (project aktif? kuota CU-jam habis?).
   3. Dashboard menampilkan "Token ditolak" = token salah/rotasi baru; cocokkan dengan Environment Render.
   4. Dashboard menampilkan "Tidak bisa menghubungi server" = URL salah, server mati, atau NCK_CORS_ORIGINS tidak memuat
      asal dashboard Anda.
   5. Lonjakan galat 5xx: kartu 02 menampilkan 5xx terbaru; log JSON "nck.access" di Render Logs memuat jalur dan waktu.


7. UJI YANG SUDAH SAYA JALANKAN (di sesi pengembangan, bukan di GitHub Actions Anda)
   - tests/test_ops_v35.py: 126 pemeriksaan (logika kesiapan, middleware metrik, rotasi token, validasi start produksi;
     SQLite dan PostgreSQL 16 lokal).
   - tests/ci_ops_pg_v35.sh pada PostgreSQL 16 asli + server uvicorn asli: penolakan start (token lemah, CORS *), backup
     terenkripsi, latihan restore, uji NEGATIF yang disengaja (sandi salah, berkas rusak, tabel hilang -> harus gagal),
     backup polos, pelaporan, preflight negatif, rotasi token via HTTP, dan pemindaian kebocoran rahasia pada log.
     Jalur docker dicoba dengan "docker palsu" yang menjalankan PostgreSQL lokal; docker sungguhan hanya ada di CI.
   - Dashboard Tahap 35 di Chromium (desktop dan layar HP) terhadap backend nyata: token salah, server mati, pembuat token
     (panjang, keunikan, uji khi-kuadrat sederhana, tidak ada permintaan jaringan, tidak ada penyimpanan), tata letak.
   - Seluruh uji Tahap 19-34 dijalankan ulang sebagai regresi dari ZIP yang sama dengan yang Anda terima (hasil di bagian 7b).
7b. REGRESI PENUH DARI ZIP (diekstrak ke folder baru, PostgreSQL 16 lokal; bukan dari folder kerja)
   compileall bersih | test_translate semua lulus | pg_smoke 41/41 | test_ddl_race 1/1 | test_legacy_v34 214/214 |
   test_distributed_v34 36/36 | test_ops_v35 126/126 | http_checks_v34 70/70 + beban ringan semua lulus + pg_dump/pg_restore
   (42 tabel identik) | ci_ops_pg_v35.sh semua pemeriksaan lulus (api 20/20, laporan 4/4, rotasi 4/4 + 3/3, preflight
   21 lulus/3 peringatan HTTP-lokal/0 gagal). Langkah ekstraksi workflow disimulasikan: ZIP Tahap 35 terpilih, .github tidak tertimpa.
   Pemindaian pola rahasia pada isi ZIP: tidak ada (hanya contoh/placeholder di uji dan README lama).
   Langkah CI baru di nck-ci.yml: "Uji modul operasi Tahap 35" dan "Uji operasi produksi nyata (...)".


8. VARIABEL BARU (ringkas; contoh lengkap di .env.example)
   Wajib untuk produksi: NCK_ENV=production, NCK_DB_BACKEND=postgres, NCK_POSTGRES_DSN, tiga token, NCK_CORS_ORIGINS.
   Disarankan: NCK_FORCE_HTTPS=1, FORWARDED_ALLOW_IPS=*, PYTHON_VERSION=3.12.11.
   Opsional: NCK_*_TOKEN_PREVIOUS (rotasi), NCK_SLOW_MS (bawaan 2000), NCK_ACCESS_LOG=1 (catat SEMUA permintaan; ramai),
   NCK_RELEASE. "FORWARDED_ALLOW_IPS=*" masuk akal di Render karena, sepengetahuan saya, aplikasi hanya dijangkau lewat proxy Render;
   jangan memakainya bila aplikasi bisa dijangkau langsung tanpa proxy tepercaya (alamat klien bisa dipalsukan lewat
   X-Forwarded-For dan pembatas laju bisa dielakkan).


9. BATAS YANG JUJUR (baca sebelum menyebut NCK "siap produksi")
   - CELAH TERBESAR: pemulihan DATA ke produksi dari HP belum punya tombol. Yang terbukti adalah pemulihan ke database
     SEMENTARA. Memulihkan ke database produksi butuh perintah pg_restore dari komputer atau satu aksi workflow tambahan
     (dengan konfirmasi) yang belum saya bangun/uji. Jalur HP yang tersedia sekarang hanyalah fitur pemulihan milik Neon
     (jendela waktu pendek di paket Free; cek dokumentasi Neon) — belum pernah saya coba di akun Anda.
   - Render Free tidur; permintaan pertama lambat. Tidak ada jaminan ketersediaan (SLA).
   - Metrik dan pembatas laju disimpan di memori satu proses; tidak dibagi antar-instance; hilang saat restart.
   - Belum ada uji beban besar, uji banyak-instance, uji failover/pemutusan database, atau uji penetrasi/audit keamanan.
     (Uji beban ringan Tahap 34: 802 permintaan, 8 thread, tanpa 5xx dan tanpa penulisan hilang. Latensinya sangat bergantung
     pada mesin uji: di sesi saya p95 berkisar 0,3 sampai 2,5 detik, dan kode Tahap 34 lama menghasilkan angka serupa di mesin
     yang sama. Itu bukan ukuran kapasitas produksi.)
   - Tidak ada pemantauan eksternal bawaan. Bila memasang pemantau uptime, arahkan ke /health (tanpa database) dan jangan
     terlalu sering.
   - Pemeriksaan kesiapan hanya membaca konfigurasi/keadaan proses itu sendiri; "lulus" bukan bukti keamanan.
   - Kepatuhan data pribadi (mis. UU PDP), retensi data, dan kebijakan penghapusan data belum dinilai.
   - Backup: enkripsi AES-256-CBC (PBKDF2, 200000 putaran) tanpa MAC; kerusakan terdeteksi lewat sha256 di backup_meta.json,
     tetapi meta itu sendiri tidak ditandatangani. Perbandingan jumlah baris memakai jendela [sebelum, sesudah] dump,
     karena tabel boleh berubah saat dump berjalan; ini bukan perbandingan isi per baris.
   - Artifact backup berada di GitHub. Di repo PUBLIK, sepengetahuan saya artifact dapat diunduh siapa pun yang punya akun
     GitHub; isinya terenkripsi, tetapi nama tabel dan jumlah baris di backup_meta.json terlihat. Repo privat lebih aman.
     Gunakan sandi acak dari kartu 04, jangan sandi buatan sendiri.
   - Neon dan Render dapat mengubah paket/kuota/harga kapan saja; angka di bagian 2 adalah yang saya baca pada tanggal build.
   - docker-compose.stage34.yml (Tahap 34) tidak pernah dijalankan dengan Docker sungguhan.
   - Pencarian dokumen/knowledge memakai TF-IDF leksikal (bukan embedding semantik); AI hanya berjalan bila kunci penyedia
     diisi di server, dan tanpa itu endpoint AI menjawab 503 (tidak ada hasil palsu).
   - Kemiripan visual dengan gambar referensi tidak dapat saya ukur: gambar referensi tidak tersedia di sesi ini.
