NUSANTARA CYBER-KERATON — TAHAP 33
PostgreSQL Runtime Adapter (opsional) + Perbaikan Cacat Tahap 32

Tanggal build: 2026-11-19
Status jujur: aplikasi TETAP berjalan di SQLite secara bawaan. PostgreSQL hanya aktif bila Anda
sendiri mengubah NCK_DB_BACKEND=postgres. Tahap ini BELUM menyatakan siap produksi (lihat bagian
"YANG BELUM DIUJI").


1. ISI PAKET (yang baru / berubah di Tahap 33)
- Nusantara_Cyber_Keraton_Tahap33.html     dashboard baru (menu mobile, panel Adapter DB)
- NCK_Tahap19_Backend/nck_db.py             adapter database (SQLite atau PostgreSQL)
- NCK_Tahap19_Backend/main.py               memakai adapter; endpoint v33 baru
- NCK_Tahap19_Backend/tools/migrate_sqlite_to_postgres_v33.py   alat migrasi baru
- NCK_Tahap19_Backend/tests/                tes otomatis (test_translate.py, pg_smoke.py, pg_shim/)
- .github/workflows/nck-postgres-ci.yml     uji otomatis di GitHub Actions (PostgreSQL sungguhan)
- docker-compose.stage33.yml                compose Tahap 33 (BELUM diuji dengan Docker)
- NCK_Tahap19_Backend/.env.example, Dockerfile   diperbarui
Catatan: Nusantara_Cyber_Keraton_Tahap22.html dihapus karena isinya identik byte-per-byte dengan
Tahap24. HTML Tahap 22 yang asli tidak ada di paket yang saya terima.


2. CACAT TAHAP 32 YANG DIPERBAIKI
a. Alat migrasi v32 gagal memuat data pada tabel yang saling berelasi (urutan FK salah; terbukti di
   PostgreSQL asli). Alat v33 memuat tabel berurutan menurut dependensi dan menambahkan FK SETELAH
   data masuk. Alat v32 (dan versi yang lebih lama) kini menolak jalan kecuali diberi --allow-deprecated.
b. Docker: pada konfigurasi bawaan Tahap 31/32 volume dipasang di /app/data, tetapi lokasi file SQLite
   hanya masuk volume bila NCK_DB_PATH diarahkan ke sana (contoh .env lama tidak melakukannya), sehingga
   data bisa hilang saat container dibuat ulang. Kini Dockerfile, compose, dan .env.example memakai
   NCK_DB_PATH=/app/data/nck_enterprise.db (di dalam volume).
c. .env.example memuat dua DSN PostgreSQL dengan nama database berbeda. Kini hanya satu: NCK_POSTGRES_DSN.
d. Label menu dashboard Tahap 27–31 salah. Sudah diperbaiki.
e. Teks runbook lama di dashboard (Tahap 32) diganti dengan catatan bahwa alat v32 sudah usang.
f. Menu dashboard di layar kecil (HP): kini tombol "Menu" yang bisa dibuka/ditutup. PERUBAHAN
   DISENGAJA: di HP menu tertutup secara bawaan agar isi halaman langsung terlihat. Tampilan desktop
   tidak berubah.


3. FITUR BARU
3.1 Adapter database (nck_db.py)
- NCK_DB_BACKEND=sqlite  (bawaan)  atau  postgres
- NCK_POSTGRES_DSN dan NCK_POSTGRES_SCHEMA (bawaan: public)
- Kode aplikasi yang sudah ada tetap memakai SQL gaya SQLite; adapter menerjemahkannya ke PostgreSQL
  (placeholder ?, LIKE -> ILIKE, IFNULL, julianday, INSERT OR IGNORE/REPLACE, identity/lastrowid,
  PRAGMA table_info, dsb.).
- Klaim tugas oleh worker memakai FOR UPDATE SKIP LOCKED di PostgreSQL, sehingga banyak worker tidak
  mengambil tugas yang sama (diuji dengan 3 worker).
- Saat start, sequence id PostgreSQL disinkronkan otomatis (supaya INSERT baru tidak bentrok dengan id
  hasil migrasi). Bila ada yang diperbaiki, dicatat di log keamanan: db.identity_sequence_synced.
3.2 Endpoint baru
- GET /api/v33/status                 (token apa pun)
- GET /api/v33/database/adapter       (operator/admin): backend aktif, jumlah baris tiap tabel, status sequence
3.3 Alat migrasi v33  (python tools/migrate_sqlite_to_postgres_v33.py ...)
- --dry-run        simulasi, TIDAK butuh driver PostgreSQL dan tidak menyentuh PostgreSQL
- --snapshot       migrasi dari salinan konsisten file SQLite (bukan file yang sedang dipakai)
- --verify-only    benar-benar hanya-baca: bandingkan jumlah baris + checksum isi tiap tabel
- --replace-target-data   DESTRUKTIF pada schema tujuan (dengan pemeriksaan ketergantungan FK dari tabel luar)
- Satu transaksi; gagal = rollback. Gerbang konflik tipe: bila data SQLite punya tipe yang tidak cocok
  dengan kolomnya, migrasi DIBLOKIR sebelum menyentuh PostgreSQL (exit code 3).
- Kode keluar: 0 sukses, 2 checksum/jumlah tidak cocok, 3 konflik tipe, 4 dibatalkan/rollback.
- Database SQLite sumber TIDAK dihapus atau diubah.
- Yang dibawa: PRIMARY KEY, UNIQUE, indeks, FK (+ aksi ON DELETE/UPDATE), CHECK sederhana, kolom
  identity. CHECK yang dialeknya tidak cocok dicatat di "manual_review" (tidak membatalkan migrasi).
  Trigger/view hanya diinventarisasi.


4. HASIL UJI (jujur)
Dijalankan 2026-11-19 pada PostgreSQL 16 asli di mesin pengembangan:
- tests/test_translate.py   19 cek penerjemah SQL                       -> semua lulus
- tests/pg_smoke.py         41 cek migrasi + adapter + aplikasi          -> 41/41 lulus
  Mencakup: dry-run, urutan muat FK, migrasi + checksum, penolakan target berisi, --replace-target-data,
  --verify-only tidak menulis, deteksi perubahan 1 sel, gerbang konflik tipe, UNIQUE/FK/CHECK/identity
  berfungsi, aplikasi start di schema kosong DAN di schema hasil migrasi, duplikat proyek -> 409,
  pencarian tidak peka huruf besar/kecil, karakter % dan kutip, 3 worker berebut 12 tugas (tiap tugas
  diklaim tepat sekali), paritas skema (DDL aplikasi = hasil migrasi).
- Selama pengembangan juga dijalankan (skripnya tidak disertakan): validasi seluruh SQL konstan main.py
  terhadap PostgreSQL (PREPARE), perbandingan hasil endpoint SQLite vs PostgreSQL, dan latihan cutover.
- Uji ini menemukan 1 bug nyata di alat migrasi sendiri (CHECK terlewat bila database yang sama sudah
  punya schema lain). Sudah diperbaiki dan ada tes regresinya.


5. YANG BELUM DIUJI / BATASAN — BACA SEBELUM PRODUKSI
1. Driver: di mesin pengembangan tidak ada internet, jadi psycopg ASLI dan FastAPI ASLI tidak terpasang.
   Tes memakai "shim" psql (tests/pg_shim) dan stub FastAPI (fungsi endpoint dipanggil langsung).
   Shim BUKAN driver produksi. Aplikasi belum pernah dijalankan lewat HTTP nyata (uvicorn) di atas
   PostgreSQL. Workflow GitHub Actions di paket ini dibuat justru untuk menguji hal itu dengan paket
   asli, tetapi BELUM pernah dijalankan.
2. docker-compose.stage33.yml BELUM diuji dengan Docker.
3. Belum ada: uji beban, uji failover PostgreSQL, uji pg_dump/restore, uji multi-node, uji cutover di
   lingkungan Render/penyedia Anda.
4. Tidak ada connection pool: satu koneksi PostgreSQL per permintaan. Pada paket gratis yang membatasi
   jumlah koneksi, ini bisa menjadi batas.
5. Backup Tahap 30 (/api/v30/backups) hanya untuk SQLite; pada PostgreSQL endpoint itu menjawab 501.
   Gunakan pg_dump / fitur backup penyedia PostgreSQL.
6. Tidak ada sinkronisasi balik PostgreSQL -> SQLite. Setelah beralih, data baru hanya di PostgreSQL.
   "Rollback" berarti kembali ke SQLite lama (utuh, tetapi tanpa data yang masuk sesudah cutover).
7. Rate limiter di belakang reverse proxy (mis. Render): KEMUNGKINAN semua pengguna terlihat sebagai
   satu IP. Atur FORWARDED_ALLOW_IPS seperti di .env.example setelah Anda memastikan IP proxy tepercaya.
8. Eksekusi AI terdistribusi lintas-host (separuh kedua rencana Tahap 33) BELUM dibuat; ditunda ke
   Tahap 34. Worker saat ini tetap dalam proses yang sama dengan API.
9. Sekitar 20 endpoint yang dipanggil panel dashboard lama (Tahap 10–18) tidak punya backend. Panel itu
   tidak akan berfungsi. Perlu keputusan Anda: sembunyikan panel tersebut, atau bangun backend-nya.
10. Desain dashboard: gambar acuan asli tidak tersedia pada sesi ini, jadi kecocokan piksel-demi-piksel
    dengan gambar itu TIDAK dapat saya verifikasi. Perubahan Tahap 33 hanya menambah panel/menu dengan
    gaya warna yang sama (obsidian/emas/perunggu).
11. Catatan Render Free (menurut pengetahuan saya; periksa dokumentasi Render): layanan web gratis
    umumnya tidak punya disk permanen, sehingga file SQLite bisa hilang saat deploy ulang/restart.
    Itu alasan nyata untuk memakai PostgreSQL eksternal. Periksa juga masa berlaku/batas database
    gratis penyedia Anda sebelum mengandalkannya.


6. LANGKAH PRAKTIS (cocok dari HP)
A. Uji otomatis di GitHub (tanpa terminal)
   1. Unggah isi paket ke repo, pertahankan susunan folder: folder NCK_Tahap19_Backend dan folder
      .github/workflows/ harus berada di AKAR repo. Bila backend Anda ada di akar repo (bukan dalam
      folder NCK_Tahap19_Backend), ubah "working-directory" dan "paths" di file workflow.
   2. Buka repo di browser -> tab "Actions" -> pilih "NCK PostgreSQL CI" -> "Run workflow".
   3. Tunggu sampai selesai (sekitar beberapa menit). Hijau = semua langkah lulus. Merah = buka
      langkah yang gagal, salin pesan error-nya, dan kirim ke saya.
B. Pindah ke PostgreSQL (hanya setelah A hijau, dan lakukan di STAGING dulu)
   1. Unduh/backup file nck_enterprise.db.
   2. Simulasi:   python tools/migrate_sqlite_to_postgres_v33.py --sqlite ./nck_enterprise.db --dry-run
   3. Migrasi:    python tools/migrate_sqlite_to_postgres_v33.py --sqlite ./nck_enterprise.db \
                    --postgres "$NCK_POSTGRES_DSN" --schema public --snapshot
      Harus berakhir "status": "VERIFIED". Bila tidak, JANGAN lanjut.
   4. Verifikasi:  ... --verify-only (ulangi perintah yang sama dengan flag ini)
   5. Di server staging isi NCK_DB_BACKEND=postgres + NCK_POSTGRES_DSN, deploy ulang.
   6. Buka dashboard -> panel "Tahap 33 · Adapter DB" -> tekan tombol status: backend harus
      "postgres" dan sequence "sehat".
   7. Rollback: ubah NCK_DB_BACKEND kembali ke sqlite dan deploy ulang (lihat batasan nomor 6).


7. TES LOKAL
   cd NCK_Tahap19_Backend
   python tests/test_translate.py          # tanpa database
   export NCK_TEST_PG_DSN="postgresql://user:pass@host:5432/dbtes"
   python tests/pg_smoke.py                # hanya menyentuh schema bernama nck_ci_* (dibuat lalu dihapus)
JANGAN arahkan NCK_TEST_PG_DSN ke database produksi.


8. STATUS
Tahap 33 menyelesaikan: perbaikan cacat Tahap 32, adapter runtime PostgreSQL opsional, alat migrasi
terverifikasi checksum, dan tes otomatis. BELUM selesai: eksekusi AI terdistribusi, uji dengan driver
dan HTTP asli, uji beban/failover/restore, keputusan panel lama. Rencana: Tahap 34 pengujian
enterprise (+ eksekusi terdistribusi), Tahap 35 deployment produksi.
