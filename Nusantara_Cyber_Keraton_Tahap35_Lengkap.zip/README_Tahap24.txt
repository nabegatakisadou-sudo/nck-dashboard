NUSANTARA CYBER-KERATON — PAKET TAHAP 24
Multi-Agent Intelligence Network & Autonomous Collaboration

ISI PAKET
- Nusantara_Cyber_Keraton_Tahap24.html : dashboard HTML lengkap, mempertahankan UI Tahap 23 dan menambahkan modul Tahap 24.
- Nusantara_Cyber_Keraton_Tahap23.html : snapshot dashboard tahap sebelumnya.
- Nusantara_Cyber_Keraton_Tahap21.html dan Tahap22.html : snapshot tahapan sebelumnya.
- NCK_Tahap19_Backend/main.py : backend kumulatif sampai Tahap 24.
- NCK_Tahap19_Backend/requirements.txt : dependensi Python.
- NCK_Tahap19_Backend/.env.example : contoh konfigurasi.
- README tahapan 20–24.

FITUR TAHAP 24
1. Orkestrasi kolaborasi berurutan 2–8 tahap memakai agen terdaftar.
2. Handoff otomatis: keluaran agen sebelumnya masuk ke instruksi agen berikutnya dan disimpan sebagai pesan antar-agen.
3. Rekomendasi agen berdasarkan pencocokan kata kunci dengan enam peran agen yang benar-benar terdaftar.
4. AI Supervisor memeriksa kontradiksi, duplikasi, asumsi yang tidak didukung, dan celah koordinasi lintas-agen.
5. Status kolaborasi, setiap tahap, keluaran, handoff, laporan konflik, dan error disimpan di SQLite.
6. Endpoint status, rekomendasi, create collaboration, list, dan detail tersedia di /api/v24/*.
7. Modul Tahap 19–23 dipertahankan; tidak menghapus data tabel lama.

ENDPOINT BARU
GET  /api/v24/status
POST /api/v24/agents/recommend
POST /api/v24/collaborations
GET  /api/v24/collaborations
GET  /api/v24/collaborations/{id}

INSTALASI RINGKAS
1. Ekstrak ZIP.
2. Masuk ke folder NCK_Tahap19_Backend.
3. Buat virtual environment Python, lalu install: pip install -r requirements.txt
4. Salin .env.example menjadi .env dan isi token akses serta OPENAI_API_KEY atau GEMINI_API_KEY di lingkungan backend. Jangan menaruh API key di HTML.
5. Jalankan server ASGI sesuai deployment Anda, misalnya: uvicorn main:app --host 0.0.0.0 --port 8000
6. Buka HTML Tahap24. Atur URL backend dan token pada Pengaturan AI sesuai konfigurasi sebelumnya.

CATATAN TEKNIS & BATASAN
- Handoff saat ini berjalan berurutan, bukan paralel. Jika satu tahap gagal, tahap sesudahnya ditahan/blocked.
- Rekomendasi agen merupakan pencocokan kata kunci, bukan model klasifikasi AI.
- Worker memakai FastAPI BackgroundTasks in-process. Untuk produksi multi-server / skala besar, gunakan antrean eksternal durable (mis. Redis + Celery/RQ), PostgreSQL, HTTPS, backup, dan monitoring.
- Pengujian end-to-end provider AI live belum dilakukan karena membutuhkan API key dan server deployment milik operator.
- Pengujian integrasi lokal dilakukan dengan mock provider: dua agen berhasil menyelesaikan tugas, handoff tercatat, dan laporan Supervisor tersimpan.
- API key tetap berada di backend; jangan pernah memasukkannya ke HTML atau ZIP frontend.
