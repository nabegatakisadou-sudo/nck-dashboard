NUSANTARA CYBER-KERATON — TAHAP 29
Migrasi Data & Fondasi Worker Cluster

YANG DITAMBAHKAN
- Tool migrasi SQLite ke PostgreSQL: membuat tabel target, menyalin data, mempertahankan nama kolom/primary key, dan memverifikasi jumlah baris.
- Mode --dry-run dan --verify-only. Sumber SQLite tidak dihapus/diubah.
- API status migrasi dan status Redis Streams.
- Endpoint operator untuk menerbitkan task dispatch ke Redis Streams (opt-in).
- Layanan consumer Redis Streams terpisah dengan consumer group, HTTP executor adapter, dan event hasil worker.
- Docker Compose dasar untuk PostgreSQL, Redis, dan worker dispatcher.
- Panel monitoring baru pada dashboard HTML.

ENDPOINT BARU
GET  /api/v29/status
GET  /api/v29/migration/status
GET  /api/v29/queue/status
POST /api/v29/dispatch  (operator; NCK_V29_QUEUE_ENABLED=1)

MIGRASI DATABASE
1. Backup file database SQLite.
2. Install dependencies: pip install -r requirements.txt
3. Dry run: python tools/migrate_sqlite_to_postgres.py --sqlite ./nck_enterprise.db --postgres "$NCK_POSTGRES_DSN" --dry-run
4. Eksekusi: python tools/migrate_sqlite_to_postgres.py --sqlite ./nck_enterprise.db --postgres "$NCK_POSTGRES_DSN"
5. Simpan output JSON dan pastikan semua tabel verified=true.
6. Jangan alihkan aplikasi ke PostgreSQL hanya berdasarkan row count; lakukan uji integrasi baca/tulis dan validasi relasi terlebih dahulu.

BATASAN MIGRASI
Tool saat ini menyalin semua tabel SQLite non-internal, nilai baris, nama kolom, dan primary key. Tool tidak otomatis memindahkan trigger, view, index, foreign-key constraint, atau seluruh semantik SQL SQLite. Jalankan pada database target kosong/khusus atau lakukan backup target sebelum pengulangan. Data source tidak dihapus. Untuk tabel tanpa primary key, target table dibersihkan lalu disalin ulang.

WORKER SERVICE
worker_service_v29.py membaca stream nck:v29:task-dispatch dalam consumer group dan mengirim pesan ke NCK_V29_EXECUTOR_URL/execute. Adapter tersebut HARUS disediakan dan harus menjamin idempotensi serta transisi status database. Worker generik ini tidak mengimpor mesin eksekusi SQLite NCK; dengan demikian ia belum merupakan pengganti langsung worker Tahap 27. Jangan mengaktifkan NCK_V29_QUEUE_ENABLED sebelum Redis dan adapter siap.

STATUS EKSEKUSI APLIKASI
Task, memory, workflow, governance, dan data inti masih berjalan melalui SQLite compatibility mode Tahap 27. PostgreSQL migration utility dan Redis dispatch foundation telah ditambahkan, tetapi cutover penuh aplikasi ke PostgreSQL serta eksekusi AI multi-host belum aktif. Ini disengaja agar tidak terjadi split-brain atau duplikasi eksekusi.

KONFIGURASI
NCK_POSTGRES_DSN=postgresql://user:password@host:5432/nck
NCK_REDIS_URL=redis://host:6379/0
NCK_V29_QUEUE_ENABLED=0  (ubah 1 hanya setelah adapter siap)
NCK_V29_EXECUTOR_URL=https://internal-executor
NCK_V29_EXECUTOR_TOKEN=secret

VALIDASI
- Jalankan python -m py_compile main.py tools/migrate_sqlite_to_postgres.py worker_service_v29.py
- Jalankan node --check pada script dashboard.
- PostgreSQL dan Redis eksternal perlu diuji di lingkungan deployment karena tidak disertakan dalam paket.
