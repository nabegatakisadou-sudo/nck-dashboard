NUSANTARA CYBER-KERATON — PAKET TAHAP 25
Enterprise AI Governance & Self-Learning Intelligence

ISI PAKET
- Nusantara_Cyber_Keraton_Tahap25.html: dashboard kumulatif Tahap 24 + panel governance Tahap 25.
- Nusantara_Cyber_Keraton_Tahap24.html: snapshot dashboard tahap sebelumnya.
- Tahap 21–23: snapshot dashboard sebelumnya.
- NCK_Tahap19_Backend/main.py: backend kumulatif Tahap 19–25.
- requirements.txt, .env.example, .gitignore, README backend, README Tahap 20–25.

FITUR TAHAP 25
1. Kebijakan governance dengan cakupan global, project, atau agen dan tingkat risiko.
2. Gerbang persetujuan untuk permintaan tindakan eksternal/berisiko; persetujuan risiko critical hanya oleh admin; keputusan dicatat, tidak mengeksekusi tindakan eksternal.
3. Scorecard enam agen resmi dari metrik task run, skor Supervisor, dan evaluasi manusia.
4. Form evaluasi manusia dengan kualitas, akurasi, kepatuhan instruksi, dan kolaborasi (skala 1–5).
5. Usulan pembelajaran agen melalui proses propose → approve/reject. Hanya usulan yang disetujui masuk ke agent_memory_v22 sebagai approved_lesson.
6. Audit event untuk kebijakan, evaluasi, approval, dan keputusan pembelajaran.
7. Data Tahap 19–24 dipertahankan; tabel governance baru ditambahkan secara non-destruktif.

ENDPOINT BARU
GET  /api/v25/status
GET  /api/v25/policies[?active=true|false]
POST /api/v25/policies
GET  /api/v25/approvals[?status=pending|approved|rejected]
POST /api/v25/approvals
POST /api/v25/approvals/{id}/decision  {decision: approved|rejected, note: ...}
GET  /api/v25/agents/performance
POST /api/v25/evaluations
GET  /api/v25/learning[?status=proposed|approved|rejected]
POST /api/v25/learning
POST /api/v25/learning/{id}/decision  {decision: approved|rejected}

INSTALASI
1. Ekstrak ZIP. Masuk ke NCK_Tahap19_Backend.
2. Buat virtual environment Python dan jalankan: pip install -r requirements.txt
3. Salin .env.example menjadi .env, lalu isi token NCK dan minimal satu API key AI di environment server.
4. Jalankan: uvicorn main:app --host 0.0.0.0 --port 8000
5. Buka HTML Tahap25 dan gunakan URL backend serta token operator/admin yang sudah dipakai pada tahap sebelumnya.
6. Jangan menaruh API key provider di HTML atau membagikan token operator/admin.

BATASAN DAN KEAMANAN
- Kebijakan disimpan dan ditampilkan sebagai standar governance; tahap ini belum menjadi policy enforcement otomatis di setiap prompt agen. Integrasi enforcement prompt wajib menjadi pekerjaan lanjutan dan harus diuji.
- Gerbang approval menyimpan keputusan tata kelola; endpoint ini tidak menjalankan publikasi, transfer dana, ekspor data, atau perubahan sistem. Sistem eksternal harus memeriksa status approval sebelum bertindak.
- Pembelajaran tidak berjalan tanpa pengawasan. Hanya lesson yang disetujui operator/admin dimasukkan ke memori agen. Tidak ada auto-rewrite system prompt.
- Scorecard menampilkan metrik yang tersedia; bila belum ada run/evaluasi maka ditampilkan kosong, bukan angka perkiraan.
- Worker masih FastAPI BackgroundTasks in-process seperti Tahap 23–24. Untuk produksi skala besar gunakan durable queue, worker terpisah, PostgreSQL, HTTPS, secret manager, backup, monitoring, dan kontrol akses yang ditinjau.
- Pengujian provider AI live memerlukan API key dan deployment operator; jangan menganggap simulasi lokal sebagai uji provider live.
