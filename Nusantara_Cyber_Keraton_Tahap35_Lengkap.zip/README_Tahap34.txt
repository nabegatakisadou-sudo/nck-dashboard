NUSANTARA CYBER-KERATON — TAHAP 34
Panel Lama Kini Punya Backend + Eksekusi AI Terdistribusi + Uji Enterprise

Tanggal build: 2026-11-21
Status jujur: ini BELUM "siap produksi". Tahap 35 (deployment produksi) belum dikerjakan. Semua yang saya
nyatakan "lulus" di bawah adalah hasil uji nyata di sesi pengembangan; yang belum terbukti saya tulis di
bagian 8. Bukti terkuat untuk FastAPI/PostgreSQL asli adalah hasil hijau GitHub Actions milik Anda sendiri
(langkah C) — jalankan itu sebelum memercayai paket ini.


1. ISI PAKET (yang baru / berubah di Tahap 34)
- Nusantara_Cyber_Keraton_Tahap34.html        dashboard baru: panel lama memakai token otomatis + panel Tahap 34
- NCK_Tahap19_Backend/nck_legacy_v34.py       BACKEND untuk panel lama (49 endpoint) — baru
- NCK_Tahap19_Backend/nck_agents_v34.py       direktori 50 agen (diambil dari kartu agen di dashboard) — baru
- NCK_Tahap19_Backend/worker_service_v34.py   worker AI mandiri untuk deployment terdistribusi — baru
- NCK_Tahap19_Backend/main.py                 provider AI baru, mode worker, pemulihan berbasis heartbeat, CORS
- NCK_Tahap19_Backend/nck_db.py               perbaikan balapan pembuatan skema/tabel di PostgreSQL
- NCK_Tahap19_Backend/tests/                  uji baru (lihat bagian 6)
- NCK_Tahap19_Backend/requirements.txt        + pypdf (untuk unggah PDF)
- NCK_Tahap19_Backend/.env.example            variabel baru (bagian 4)
- NCK_Tahap19_Backend/Dockerfile.worker       sekarang menjalankan worker_service_v34.py
- docker-compose.stage34.yml                  API + 2 worker + PostgreSQL (BELUM diuji dengan Docker)
- .github/workflows/nck-ci.yml                workflow CI baru (harus ditempel manual; lihat langkah B)


2. LANGKAH DI HP (urut, satu per satu)

A. Unggah ZIP ke repo
   1. Buka repo NUSANTARA-CYBER-KERATON di browser HP > tab "Code".
   2. Ketuk "Add file" > "Upload files".
   3. Pilih file Nusantara_Cyber_Keraton_Tahap34_Lengkap.zip > tunggu sampai 100%.
   4. Ketuk "Commit changes" (hijau). ZIP Tahap 33 lama boleh dibiarkan.
   (Mengunggah ulang ZIP Tahap 34 untuk perbaikan: boleh nama sama atau nama lain berawalan
   "Nusantara_Cyber_Keraton_Tahap34". Workflow versi 21 Nov memilih ZIP yang commit-nya PALING BARU.)

B. Ganti isi workflow (WAJIB, kalau tidak CI masih mencari ZIP Tahap 33)
   1. Code > folder ".github" > "workflows" > file "nck-ci.yml".
   2. Ketuk ikon pensil (Edit).
   3. Pilih semua isi lama dan hapus; tempel seluruh isi nck-ci.yml baru dari pesan saya.
   4. Ketuk "Commit changes" > Commit.
   (Alasannya: GitHub tidak mengizinkan proses otomatis menulis file workflow, jadi hanya Anda yang bisa.)

C. Jalankan uji
   1. Tab "Actions" > pilih "NCK CI" di kiri > "Run workflow" > "Run workflow".
   2. Tunggu ±10-20 menit sampai ada tanda hijau atau merah.
   3. Hijau = semua uji di bagian 6 lulus dengan FastAPI + PostgreSQL 16 asli.
      Merah = ketuk langkah yang merah, salin ±30 baris terakhir lognya, kirim ke saya. Saya perbaiki.
      Langkah lain tetap dijalankan walau satu langkah merah, jadi Anda akan melihat semua yang gagal sekaligus.
   Peringatan kuning "Node.js 20 deprecated" aman diabaikan.

D. Render (hanya setelah C hijau)
   Tidak ada variabel wajib baru. Mode bawaan NCK_WORKER_MODE=both = perilaku lama (satu proses, cocok untuk
   Render Free + SQLite). Render akan memasang pypdf otomatis saat build. Setelah deploy, buka
   <url-backend>/health lalu dashboard Tahap 34.

E. Dashboard
   1. Buka Nusantara_Cyber_Keraton_Tahap34.html.
   2. Isi URL backend dan Token di panel yang sama seperti Tahap 33 (kolom Token pada panel Tahap 19, ketuk "Cek Koneksi").
   3. Panel lama (AI Engine, Knowledge, Dokumen, Intelligence, Autonomous, Kolaborasi, Command Center) kini
      otomatis memakai token itu. Bila token kurang/salah, muncul pesan kecil di bawah layar.
   4. Menu "Tahap 34 · Panel Lama & Worker" menampilkan status backend dan worker (hanya membaca).


3. PANEL LAMA KINI BERBACKEND
Semua endpoint wajib token (header X-NCK-Token). viewer = baca + pencarian/perencanaan lokal; operator = tulis +
panggil AI; admin = backup/restore.
- AI Engine: POST /api/chat, POST /api/orchestrate (provider: gemini, openai/custom, ollama).
- Knowledge: GET/POST /api/knowledge, DELETE /api/knowledge/{id}, POST /api/knowledge/search.
- Dokumen: unggah TXT/MD/CSV/JSON/DOCX/PDF (maks. NCK_UPLOAD_MAX_BYTES, bawaan 12 MB), cari, baca, hapus, ringkas.
- Intelligence: pencarian, graf, perbandingan sumber. Agen: GET /api/agents (50 agen).
- Autonomous: rencana LOKAL (kata kunci, bukan AI) + eksekusi DAG (tugas bergantung, retry, review kualitas, sintesis).
- Kolaborasi: eksekusi DAG latar belakang (run_id, polling GET /api/collaboration/runs/{id}).
- Command Center Tahap 13-15: proyek, memori, tugas, persetujuan, jadwal (menjadi persetujuan pending; tidak
  dieksekusi otomatis), audit, backup/restore JSON, prepare > approve > launch > sync, umpan balik & routing agen.
Perilaku penting:
- Tanpa kunci/URL provider -> HTTP 503 dengan pesan jelas. TIDAK ada hasil AI palsu.
- Pencarian dokumen/knowledge = TF-IDF kata kunci (BUKAN embedding semantik).
- Aksi mahal (chat, orkestrasi, unggah, autonomous, kolaborasi, ringkas) kini ikut batas laju "mahal"
  (NCK_EXPENSIVE_RATE_LIMIT, bawaan 12/menit per IP). Naikkan bila panel terasa terblokir.
- CORS kini mengizinkan metode PATCH dan DELETE (dibutuhkan panel).


4. VARIABEL LINGKUNGAN BARU (semua opsional; lihat .env.example)
- OPENAI_BASE_URL            gateway/LLM kompatibel OpenAI (provider "openai" atau "custom")
- NCK_OLLAMA_URL, OLLAMA_MODEL   server Ollama sendiri (provider "ollama")
- NCK_UPLOAD_MAX_BYTES       batas unggah (bawaan 12 MB, maksimum 25 MB)
- NCK_WORKER_MODE            both (bawaan) | api | worker
- NCK_WORKER_STALE_SECONDS   worker dianggap mati bila heartbeat lebih lama (bawaan 90; 15-3600)
- NCK_WORKER_HEARTBEAT_SECONDS  interval heartbeat (bawaan 10)
- NCK_SHUTDOWN_GRACE_SECONDS    waktu tunggu tugas berjalan saat SIGTERM (bawaan 10)
- NCK_WORKER_CONCURRENCY     slot worker per proses (bawaan 3, maks. 16) — sudah ada sebelumnya


5. EKSEKUSI AI TERDISTRIBUSI
Cara kerja: tugas antre di database; tiap worker mengklaim tugas secara atomik (SELECT ... FOR UPDATE SKIP LOCKED),
mengirim heartbeat, dan mencatat hasil. Worker yang mati (heartbeat basi) dilepas dan tugasnya kembali ke antrean.
- Mode both : API + worker satu proses (bawaan).
- Mode api  : hanya HTTP.   Mode worker: python worker_service_v34.py (tanpa HTTP).
- SYARAT terdistribusi: PostgreSQL bersama (NCK_DB_BACKEND=postgres). Dengan SQLite jangan jalankan >1 proses.
- Semantik: AT-LEAST-ONCE. Tugas milik worker yang mati/membeku bisa dijalankan ULANG; hasil pertama yang tercatat
  yang dipakai (hasil susulan dari worker basi dibuang dan dicatat sebagai kejadian). Pastikan instruksi tugas aman bila diulang.
- Shutdown (SIGTERM): tugas berjalan diselesaikan sampai batas tunggu, sisanya langsung kembali ke antrean.
- Status: GET /api/v34/distributed/status (viewer) dan panel Tahap 34.
- Perubahan perilaku dari Tahap 27-33: start ulang TIDAK lagi mereset semua tugas "running" dan registry worker secara
  buta, dan status "pause" worker kini bertahan setelah restart. (SQLite + mode both tetap memulihkan tugas yatim
  segera saat start, seperti sebelumnya.)
- Coba lokal: docker compose -f docker-compose.stage34.yml up --build  (butuh file .env berisi NCK_PG_PASSWORD).
  BELUM diuji dengan Docker.


6. UJI OTOMATIS (hasil di sesi pengembangan; CI Anda mengulangnya dengan perangkat asli)
Di sesi saya FastAPI/psycopg asli tidak tersedia, jadi saya memakai stub (+ shim psql ke PostgreSQL 16 asli) dan,
untuk uji HTTP, server uvicorn sungguhan di atas "mini-FastAPI" buatan saya. Karena itu hasil di bawah adalah
bukti kuat tetapi BUKAN pengganti CI hijau Anda.
- tests/test_translate.py     19/19  penerjemah SQL SQLite -> PostgreSQL
- tests/pg_smoke.py           41/41  migrasi + adapter + klaim antrean di PostgreSQL
- tests/test_ddl_race.py      lulus  6 proses start serentak pada skema kosong, 4 ronde (menemukan DAN memperbaiki bug nyata)
- tests/test_legacy_v34.py    214/214 (107 SQLite + 107 PostgreSQL) backend panel lama, RBAC, DAG, unggah, backup/restore
- tests/test_distributed_v34.py  36/36 proses worker nyata: klaim tunggal, shutdown terkendali, worker lambat tidak
                                  dicuri, kill -9 di tengah tugas dipulihkan
- tests/http_checks_v34.py    70/70  HTTP nyata: 401/403/RBAC, CORS, unggah (413/415/422), AI via server palsu,
                                  kolaborasi latar belakang, persetujuan, backup/restore, antrean worker
- tests/load_check_v34.py     lulus  800 permintaan, 8 thread: tanpa 5xx, tanpa penulisan hilang
- tests/ci_http_pg_v34.sh     pg_dump > pg_restore ke database baru: jumlah baris 41 tabel sama persis, API baru di
                              atas hasil restore membaca data dan menulis data baru. Alat pg_dump/pg_restore dipilih
                              yang versi mayornya SAMA dengan server (biner berversi, atau image docker postgres:<mayor>);
                              bisa dipaksa dengan NCK_PG_TOOLS=local|docker.
Catatan beban: di sesi saya PostgreSQL diakses lewat shim lambat, jadi angka latensi dari sana tidak mewakili apa-apa.
Angka yang berarti adalah milik CI Anda; ambang p95 uji beban 3000 ms.


7. BUG NYATA YANG DITEMUKAN UJI TAHAP INI
- Balapan DDL: dua proses (API + worker) yang pertama kali nyala bersamaan pada database kosong gagal dengan
  "duplicate key ... pg_namespace_nspname_index" / "relation already exists". Sekarang DDL idempoten dijalankan
  dengan SAVEPOINT + ulang (nck_db.py). Ini juga ada di Tahap 33.
- Start ulang mereset tugas milik worker lain yang masih hidup (berbahaya pada multi-proses) -> diganti pemulihan berbasis heartbeat.
- Hasil worker basi bisa menimpa hasil worker lain -> kini hanya dicatat bila tugas masih berstatus "running".

CI nyata #2 (21 Nov, dilaporkan pengguna): semua langkah uji kode lulus di FastAPI + PostgreSQL 16 asli
(HTTP 70/70, beban ringan 802 permintaan p95 322 ms, tanpa 5xx). Dua langkah merah, KEDUANYA masalah alat CI, bukan kode NCK:
- Pemasangan postgresql-client-16 lewat apt gagal (kode 100): paket tidak tersedia di image runner. Langkah itu dihapus.
- pg_restore gagal: runner membawa pg_dump versi lebih baru (>= 17) yang menulis "SET transaction_timeout",
  parameter yang tidak dikenal server PostgreSQL 16. Skrip kini memakai alat yang mayornya sama dengan server
  (image docker postgres:16 bila perlu). Perbaikan diuji lokal dengan klien "versi 18" palsu yang meniru galat itu
  (galat berhasil direproduksi dengan skrip lama, lalu lulus dengan skrip baru), tetapi BUKTI SEBENARNYA adalah CI #3.


8. YANG BELUM DIUJI / BATAS YANG JUJUR
- Belum ada bukti dengan FastAPI asli sampai CI Anda hijau (langkah C).
- docker-compose.stage34.yml dan Dockerfile.worker belum pernah dijalankan dengan Docker.
- Belum diuji: banyak mesin/region, beban tinggi/lama (soak), failover PostgreSQL, pemutusan jaringan ke database,
  penerapan Render nyata. Render Free tidak menyediakan Background Worker; worker terpisah butuh layanan berbayar
  atau server sendiri.
- autonomous/run bersifat sinkron (satu permintaan HTTP panjang); proxy dapat memutusnya pada tugas yang sangat lama.
  Kolaborasi dan Command Center v14 berjalan di latar belakang dan tidak punya masalah ini.
- Eksekusi latar belakang kolaborasi/v14 berada di proses API (BackgroundTasks); bila proses mati di tengah, run
  ditandai gagal setelah 15 menit tanpa pembaruan (tidak dilanjutkan otomatis).
- Uji AI memakai server AI palsu: alur dan penanganan galat terbukti, kualitas jawaban model nyata tidak.
- Tidak ada uji penetrasi/keamanan mendalam, tidak ada audit pihak ketiga.
- Dashboard: desain lama dipertahankan dan panel baru mengikuti gaya yang sama; saya TIDAK dapat membandingkan
  piksel-per-piksel dengan gambar referensi karena gambar itu tidak tersedia di sesi ini.
- Unggah PDF hasil scan/gambar tidak punya teks (ditolak 422); tidak ada OCR.


9. TAHAP BERIKUTNYA
Tahap 35 — deployment produksi: checklist rahasia & token, HTTPS/CORS, backup terjadwal + uji pulih, pemantauan,
runbook rilis dan rollback, lalu penutupan proyek. Mulai setelah CI Tahap 34 hijau.
