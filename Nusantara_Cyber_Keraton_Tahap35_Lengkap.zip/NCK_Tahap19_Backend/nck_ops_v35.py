"""Tahap 35 - operasi produksi.

Isi:
  GET  /ready                          publik; 200 bila database menjawab, 503 bila tidak (untuk pemantau uptime)
  GET  /api/v35/status                 ringkasan tahap
  GET  /api/v35/ops/status             rilis (commit), uptime, platform, database, mode worker
  GET  /api/v35/ops/readiness          daftar periksa kesiapan produksi (lulus / peringatan / gagal) + batas yang jujur
  GET  /api/v35/ops/metrics            metrik PROSES INI (jumlah permintaan, latensi p50/p95/p99, 5xx, antrean tugas)
  POST /api/v35/ops/backup-report      (admin) workflow backup/latihan restore melaporkan hasilnya
  GET  /api/v35/ops/backups            (operator) riwayat laporan backup

Aturan keras modul ini: TIDAK PERNAH mengembalikan atau mencatat token, kata sandi DSN, atau isi header otorisasi.
Variabel lingkungan hanya DIEVALUASI (panjang, keunikan, bentuk) lalu dibuang.
Metrik hanya hidup di memori proses (hilang saat restart, tidak digabung antar-instance).
"""
import collections
import json
import logging
import os
import platform
import sys
import threading
import time
from datetime import datetime, timedelta, timezone
from typing import Optional
from urllib.parse import urlsplit

from fastapi import Depends, HTTPException, Request
from pydantic import BaseModel, Field
from starlette.responses import JSONResponse

VERSION = '35.0.0'
STARTED_AT = time.time()
ROLES = (('viewer', 'NCK_VIEWER_TOKEN'), ('operator', 'NCK_OPERATOR_TOKEN'), ('admin', 'NCK_ADMIN_TOKEN'))

DDL = """
CREATE TABLE IF NOT EXISTS ops_backups_v35(
  id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, ok INTEGER NOT NULL,
  bytes INTEGER NOT NULL DEFAULT 0, sha256 TEXT NOT NULL DEFAULT '', detail TEXT NOT NULL DEFAULT '',
  source TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
"""

# Hal yang TIDAK dicakup pemeriksaan otomatis ini; selalu ditampilkan agar tidak ada klaim berlebihan.
LIMITS = [
    'Pemeriksaan ini hanya membaca konfigurasi dan keadaan proses ini; bukan audit keamanan atau uji penetrasi.',
    'Belum ada uji beban besar, uji banyak-instance, uji failover database, atau uji pemutusan jaringan.',
    'Rate limiter dan metrik berada di memori satu proses; tidak dibagi antar-instance.',
    'Tidak ada pemantauan eksternal bawaan: pasang pemantau uptime pada /ready bila perlu.',
    'Kepatuhan data pribadi (mis. UU PDP) dan retensi data belum dinilai.',
]

_PREV_USE = {}
_PREV_LOCK = threading.Lock()


def note_previous_use(role):
    """Dipanggil auth() bila token LAMA (*_PREVIOUS) dipakai; hanya mencatat waktu, bukan token."""
    with _PREV_LOCK:
        _PREV_USE[role] = time.time()


# ------------------------------------------------------------------ metrik proses
class _Metrics:
    def __init__(self):
        self.lock = threading.Lock()
        self.reset()

    def reset(self):
        with self.lock:
            self.total = 0
            self.by_class = collections.Counter()
            self.by_group = collections.Counter()
            self.lat = collections.deque(maxlen=2000)
            self.slow = 0
            self.recent_5xx = collections.deque(maxlen=20)

    @staticmethod
    def group_of(path):
        seg = [s for s in path.split('/') if s][:2]
        return '/' + '/'.join(seg) if seg else '/'

    def record(self, method, path, status, ms, slow_ms):
        with self.lock:
            self.total += 1
            self.by_class[f'{status // 100}xx'] += 1
            g = self.group_of(path)
            if g not in self.by_group and len(self.by_group) >= 60:
                g = 'lainnya'
            self.by_group[g] += 1
            self.lat.append(ms)
            if ms >= slow_ms:
                self.slow += 1
            if status >= 500:
                self.recent_5xx.append({'at': datetime.now(timezone.utc).isoformat(timespec='seconds'),
                                        'method': method, 'path': path[:120], 'status': status})

    def snapshot(self):
        with self.lock:
            lat = sorted(self.lat)
            n = len(lat)

            def pct(q):
                return round(lat[min(n - 1, int(round(q * (n - 1))))], 1) if n else None
            return {'requests_total': self.total, 'by_class': dict(self.by_class),
                    'latency_ms': {'p50': pct(0.50), 'p95': pct(0.95), 'p99': pct(0.99),
                                   'max': round(lat[-1], 1) if n else None, 'samples': n},
                    'slow_requests': self.slow, 'recent_5xx': list(self.recent_5xx),
                    'top_groups': dict(self.by_group.most_common(15))}


METRICS = _Metrics()


def _slow_ms():
    try:
        return max(100, min(int(os.getenv('NCK_SLOW_MS', '2000')), 60000))
    except ValueError:
        return 2000


_LOGGER = None


def _logger():
    """Log JSON satu-baris ke stdout (Render menampilkannya di tab Logs). Dibuat sekali."""
    global _LOGGER
    if _LOGGER is None:
        lg = logging.getLogger('nck.access')
        if not lg.handlers:
            h = logging.StreamHandler(sys.stdout)
            h.setFormatter(logging.Formatter('%(message)s'))
            lg.addHandler(h)
        lg.setLevel(logging.INFO)
        lg.propagate = False
        _LOGGER = lg
    return _LOGGER


# ------------------------------------------------------------------ logika kesiapan (murni, tanpa jaringan)
def _e(env, key):
    return (env.get(key) or '').strip()


def dsn_info(dsn):
    """Ambil host dan sslmode dari DSN. Kata sandi tidak pernah dikembalikan."""
    host, ssl = '', ''
    d = (dsn or '').strip()
    if '://' in d:
        try:
            u = urlsplit(d)
            host = u.hostname or ''
            for part in (u.query or '').split('&'):
                if part.startswith('sslmode='):
                    ssl = part.split('=', 1)[1]
        except ValueError:
            pass
    else:
        for tok in d.split():
            if tok.startswith('host='):
                host = tok[5:]
            elif tok.startswith('sslmode='):
                ssl = tok[8:]
    return {'host': host, 'sslmode': ssl, 'local': host in ('', 'localhost', '127.0.0.1', '::1') or host.startswith('/')}


def _c(cid, label, status, detail, fix=''):
    return {'id': cid, 'label': label, 'status': status, 'detail': detail, 'fix': fix}


def _age_hours(iso, now_ts):
    try:
        dt = datetime.fromisoformat(iso)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return max(0.0, (now_ts - dt.timestamp()) / 3600.0)
    except (TypeError, ValueError):
        return None


def readiness_checks(env, ctx):
    """env: mapping lingkungan. ctx: backend, req{scheme,xfp,xff,client}, db_ms, db_error, backup_last, drill_last,
    exceptions_24h, prev_use{role:ts}, now (detik epoch)."""
    out = []
    add = out.append
    backend = ctx.get('backend', 'sqlite')
    now_ts = ctx.get('now') or time.time()
    prod = _e(env, 'NCK_ENV').lower() == 'production'
    add(_c('env_production', 'Mode produksi (NCK_ENV=production)', 'pass' if prod else 'warn',
           'Aktif: token/CORS lemah membuat server menolak start.' if prod else
           'NCK_ENV bukan "production": server TIDAK menolak start walau token atau CORS lemah.',
           '' if prod else 'Render > Environment: NCK_ENV = production'))

    vals = {r: _e(env, v) for r, v in ROLES}
    weak = [r for r, v in vals.items() if len(v) < 32 or v.lower().startswith('replace_with_')]
    add(_c('tokens_strong', 'Token peran kuat (>=32 karakter acak)', 'fail' if weak else 'pass',
           ('Lemah atau kosong: ' + ', '.join(weak) + '.') if weak else 'Ketiga token (viewer, operator, admin) terisi dan panjang.',
           'Buat token acak panjang di panel Operasi lalu isi NCK_VIEWER_TOKEN / NCK_OPERATOR_TOKEN / NCK_ADMIN_TOKEN.' if weak else ''))
    distinct = len(set(vals.values())) == 3 and all(vals.values())
    add(_c('tokens_distinct', 'Ketiga token berbeda', 'pass' if distinct else 'fail',
           'Token viewer, operator, dan admin berbeda.' if distinct else 'Ada token yang sama atau kosong: hak akses jadi tidak bermakna.',
           '' if distinct else 'Isi tiga token yang berbeda.'))

    prevs = [r for r, v in ROLES if _e(env, v + '_PREVIOUS')]
    if prevs:
        use = ctx.get('prev_use') or {}
        seen = []
        for r in prevs:
            ts = use.get(r)
            seen.append(f'{r}: ' + (f'dipakai {int((now_ts - ts) // 60)} menit lalu' if ts else 'belum dipakai sejak server start'))
        add(_c('tokens_rotation', 'Rotasi token', 'warn', 'Token LAMA masih berlaku (' + '; '.join(seen) + ').',
               'Setelah semua perangkat memakai token baru, hapus variabel *_PREVIOUS lalu deploy ulang.'))
    else:
        add(_c('tokens_rotation', 'Rotasi token', 'pass', 'Tidak ada token lama yang masih berlaku.'))

    cors = [x.strip() for x in _e(env, 'NCK_CORS_ORIGINS').split(',') if x.strip()]
    if not cors or '*' in cors:
        add(_c('cors_exact', 'CORS: daftar origin persis', 'fail', 'NCK_CORS_ORIGINS kosong atau memakai "*".',
               'Isi origin frontend persis, mis. https://nama.github.io (tanpa garis miring di akhir).'))
    else:
        local = [o for o in cors if 'localhost' in o or '127.0.0.1' in o]
        plain = [o for o in cors if o.startswith('http://') and o not in local]
        if prod and (local or plain):
            add(_c('cors_exact', 'CORS: daftar origin persis', 'warn',
                   f'{len(cors)} origin; ada origin lokal atau http:// biasa yang tidak perlu di produksi.',
                   'Hapus origin localhost/http:// dari NCK_CORS_ORIGINS bila tidak dipakai.'))
        else:
            add(_c('cors_exact', 'CORS: daftar origin persis', 'pass', f'{len(cors)} origin persis, tanpa wildcard.'))

    on_render = _e(env, 'RENDER') == 'true'
    if backend == 'postgres':
        add(_c('database_durable', 'Database tahan restart', 'pass', 'PostgreSQL dipakai sebagai database aplikasi.'))
    elif on_render:
        add(_c('database_durable', 'Database tahan restart', 'fail',
               'SQLite berjalan di Render: sistem berkas Render (termasuk paket Free) hilang saat restart, deploy ulang, atau spin-down.',
               'Pakai PostgreSQL eksternal permanen (NCK_DB_BACKEND=postgres + NCK_POSTGRES_DSN). Lihat README_Tahap35.'))
    else:
        add(_c('database_durable', 'Database tahan restart', 'warn',
               'SQLite: aman hanya bila berkas DB berada di disk persisten dan dicadangkan.',
               'Letakkan NCK_DB_PATH di volume persisten atau pindah ke PostgreSQL.'))

    if backend == 'postgres':
        info = dsn_info(_e(env, 'NCK_POSTGRES_DSN'))
        if info['local']:
            add(_c('database_tls', 'Koneksi database terenkripsi (TLS)', 'info', 'Database lokal/socket: TLS tidak relevan.'))
        elif info['sslmode'] in ('require', 'verify-ca', 'verify-full'):
            add(_c('database_tls', 'Koneksi database terenkripsi (TLS)', 'pass', f'sslmode={info["sslmode"]}.'))
        else:
            add(_c('database_tls', 'Koneksi database terenkripsi (TLS)', 'warn',
                   'DSN database jauh tanpa sslmode=require; lalu lintas ke database bisa tidak terenkripsi.',
                   'Tambahkan ?sslmode=require di akhir NCK_POSTGRES_DSN.'))

    req = ctx.get('req') or {}
    xfp = (req.get('xfp') or '').split(',')[0].strip().lower()
    https = req.get('scheme') == 'https' or xfp == 'https'
    add(_c('https_request', 'Permintaan ini lewat HTTPS', 'pass' if https else 'warn',
           'Ya.' if https else 'Permintaan ini lewat HTTP biasa (wajar untuk uji lokal, tidak untuk produksi).',
           '' if https else 'Buka lewat URL https:// dari penyedia hosting.'))
    force = _e(env, 'NCK_FORCE_HTTPS') == '1'
    add(_c('hsts', 'Header HSTS dikirim', 'pass' if (force or req.get('scheme') == 'https') else 'warn',
           'HSTS aktif.' if (force or req.get('scheme') == 'https') else
           'HSTS hanya dikirim bila NCK_FORCE_HTTPS=1 (di belakang proxy server melihat http).',
           '' if (force or req.get('scheme') == 'https') else 'Render > Environment: NCK_FORCE_HTTPS = 1'))

    xff = (req.get('xff') or '').split(',')[0].strip()
    if xff:
        ok = xff == (req.get('client') or '')
        add(_c('proxy_headers', 'IP klien asli terbaca (batas laju per pengguna)', 'pass' if ok else 'warn',
               'X-Forwarded-For dipercaya: batas laju dihitung per IP klien asli.' if ok else
               'Server hanya melihat IP proxy walau ada X-Forwarded-For: semua pengguna berbagi satu jatah batas laju.',
               '' if ok else 'Render > Environment: FORWARDED_ALLOW_IPS = *  (hanya aman bila layanan hanya dapat dicapai lewat proxy hosting).'))
    else:
        add(_c('proxy_headers', 'IP klien asli terbaca (batas laju per pengguna)', 'info',
               'Permintaan ini tanpa X-Forwarded-For (tidak ada proxy terdeteksi).'))

    mode = _e(env, 'NCK_WORKER_MODE').lower() or 'both'
    if mode in ('api', 'worker') and backend != 'postgres':
        add(_c('worker_mode', f'Mode worker ({mode})', 'fail', 'Mode api/worker memerlukan PostgreSQL bersama.',
               'Set NCK_WORKER_MODE=both atau pindah ke PostgreSQL.'))
    else:
        add(_c('worker_mode', f'Mode worker ({mode})', 'pass', 'Kombinasi mode worker dan database valid.'))

    ai = bool(_e(env, 'OPENAI_API_KEY') or _e(env, 'GEMINI_API_KEY') or _e(env, 'OPENAI_BASE_URL') or _e(env, 'NCK_OLLAMA_URL'))
    add(_c('ai_provider', 'Penyedia AI terkonfigurasi', 'pass' if ai else 'warn',
           'Ada kunci/URL penyedia AI.' if ai else 'Tidak ada: endpoint AI menjawab 503 (tidak ada hasil palsu).',
           '' if ai else 'Isi OPENAI_API_KEY atau GEMINI_API_KEY di environment server (jangan di dashboard).'))

    if ctx.get('db_error'):
        add(_c('db_ping', 'Database menjawab', 'fail', 'Gagal: ' + str(ctx['db_error'])[:160], 'Periksa NCK_POSTGRES_DSN dan status database.'))
    else:
        ms = ctx.get('db_ms')
        add(_c('db_ping', 'Database menjawab', 'warn' if (ms is not None and ms > 800) else 'pass',
               f'Latensi {ms} ms.' if ms is not None else 'OK.',
               'Latensi tinggi: database mungkin baru bangun dari tidur (wajar di paket gratis) atau jauh secara jaringan.' if (ms or 0) > 800 else ''))

    b = ctx.get('backup_last')
    if not b:
        add(_c('backup_recent', 'Backup terverifikasi terbaru', 'warn', 'Belum ada laporan backup yang berhasil.',
               'Jalankan workflow "NCK Ops" aksi backup (lihat README_Tahap35).'))
    else:
        h = _age_hours(b.get('created_at'), now_ts)
        st = 'pass' if (h is not None and h <= 36) else ('warn' if (h is not None and h <= 72) else 'fail')
        add(_c('backup_recent', 'Backup terverifikasi terbaru', st,
               f'Backup berhasil terakhir {int(h)} jam lalu.' if h is not None else 'Waktu backup tidak terbaca.',
               '' if st == 'pass' else 'Backup harian macet: periksa tab Actions > NCK Ops.'))
    d = ctx.get('drill_last')
    if not d:
        add(_c('restore_drill', 'Latihan restore terbaru', 'warn', 'Belum ada latihan restore yang berhasil dilaporkan.',
               'Jalankan workflow "NCK Ops" aksi restore-drill. Backup yang belum pernah dipulihkan belum terbukti.'))
    else:
        h = _age_hours(d.get('created_at'), now_ts)
        days = int(h // 24) if h is not None else None
        add(_c('restore_drill', 'Latihan restore terbaru', 'pass' if (days is not None and days <= 35) else 'warn',
               f'Latihan restore berhasil {days} hari lalu.' if days is not None else 'Waktu tidak terbaca.',
               '' if (days is not None and days <= 35) else 'Ulangi latihan restore (sebulan sekali).'))

    exc = ctx.get('exceptions_24h')
    if exc is not None:
        add(_c('exceptions_24h', 'Galat tak tertangani 24 jam terakhir', 'pass' if exc == 0 else 'warn',
               'Tidak ada.' if exc == 0 else f'{exc} kejadian request.exception tercatat.',
               '' if exc == 0 else 'Baca event keamanan (admin) dan log server.'))
    return out


def summarize(checks):
    n = collections.Counter(c['status'] for c in checks)
    if n['fail']:
        verdict = 'belum_siap'
    elif n['warn']:
        verdict = 'siap_dengan_catatan'
    else:
        verdict = 'lulus_pemeriksaan_otomatis'
    return {'pass': n['pass'], 'warn': n['warn'], 'fail': n['fail'], 'info': n['info'], 'verdict': verdict}


# ------------------------------------------------------------------ pendaftaran endpoint
class BackupReportIn(BaseModel):
    kind: str = Field(pattern=r'^(backup|restore_drill)$')
    ok: bool
    bytes: int = Field(default=0, ge=0, le=10 ** 13)
    sha256: str = Field(default='', pattern=r'^([0-9a-fA-F]{64})?$')
    detail: str = Field(default='', max_length=800)
    source: str = Field(default='github-actions', max_length=60)


def register(app, *, conn, auth, require_operator, audit, now, backend, service=''):
    def require_admin(role=Depends(auth)):
        if role != 'admin':
            raise HTTPException(403, 'Hak Admin diperlukan.')
        return role

    @app.on_event('startup')
    def startup_v35():
        with conn() as c:
            c.executescript(DDL)

    @app.middleware('http')
    async def ops_metrics_middleware35(request, call_next):
        t0 = time.perf_counter()
        status, rid = 500, ''
        try:
            response = await call_next(request)
            status = response.status_code
            rid = response.headers.get('X-Request-ID', '')
            return response
        finally:
            ms = (time.perf_counter() - t0) * 1000.0
            slow = _slow_ms()
            METRICS.record(request.method, request.url.path, status, ms, slow)
            if status >= 500 or ms >= slow or os.getenv('NCK_ACCESS_LOG', '0') == '1':
                try:
                    _logger().info(json.dumps({'evt': 'http', 'm': request.method, 'p': request.url.path[:160], 's': status,
                                               'ms': round(ms, 1), 'rid': rid[:40], 'slow': ms >= slow}, ensure_ascii=False))
                except Exception:  # noqa: BLE001 - logging tidak boleh menjatuhkan permintaan
                    pass

    def db_probe():
        t0 = time.perf_counter()
        try:
            with conn() as c:
                c.execute('SELECT 1').fetchone()
            return round((time.perf_counter() - t0) * 1000.0, 1), None
        except Exception as e:  # noqa: BLE001
            return None, type(e).__name__ + ': ' + str(e)[:160]

    @app.get('/ready')
    def ready():
        ms, err = db_probe()
        if err:
            return JSONResponse({'ready': False, 'service': service}, status_code=503)
        return {'ready': True, 'service': service, 'db_ms': ms}

    @app.get('/api/v35/status')
    def v35_status(role=Depends(auth)):
        return {'stage': 35, 'module': 'operasi_produksi', 'version': VERSION,
                'endpoints': ['/ready', '/api/v35/ops/status', '/api/v35/ops/readiness', '/api/v35/ops/metrics',
                              '/api/v35/ops/backup-report', '/api/v35/ops/backups'],
                'production_ready': False,
                'reason': 'Tahap ini menambah alat operasi dan pemeriksaan; "siap produksi" tetap keputusan Anda setelah daftar periksa lulus dan batas di /ops/readiness dibaca.'}

    @app.get('/api/v35/ops/status')
    def v35_ops_status(role=Depends(auth)):
        env = os.environ
        return {'version': VERSION, 'service': service, 'environment': _e(env, 'NCK_ENV') or 'development',
                'release': {'commit': (_e(env, 'RENDER_GIT_COMMIT') or _e(env, 'NCK_RELEASE') or 'tidak diketahui')[:40],
                            'branch': _e(env, 'RENDER_GIT_BRANCH')[:80]},
                'platform': 'render' if _e(env, 'RENDER') == 'true' else 'lainnya',
                'started_at': datetime.fromtimestamp(STARTED_AT, timezone.utc).isoformat(timespec='seconds'),
                'uptime_seconds': int(time.time() - STARTED_AT),
                'python': sys.version.split()[0], 'os': platform.system(),
                'database': backend, 'worker_mode': _e(env, 'NCK_WORKER_MODE').lower() or 'both',
                'note': 'Uptime kecil di paket Render Free berarti instance baru bangun dari spin-down atau baru deploy.'}

    @app.get('/api/v35/ops/readiness')
    def v35_ops_readiness(request: Request, role=Depends(auth)):
        env = os.environ
        ms, err = db_probe()
        ctx = {'backend': backend, 'db_ms': ms, 'db_error': err, 'now': time.time(), 'prev_use': dict(_PREV_USE),
               'req': {'scheme': request.url.scheme, 'xfp': request.headers.get('x-forwarded-proto', ''),
                       'xff': request.headers.get('x-forwarded-for', ''), 'client': request.client.host if request.client else ''}}
        try:
            with conn() as c:
                for key, kind in (('backup_last', 'backup'), ('drill_last', 'restore_drill')):
                    r = c.execute('SELECT created_at FROM ops_backups_v35 WHERE kind=? AND ok=1 ORDER BY id DESC LIMIT 1', (kind,)).fetchone()
                    ctx[key] = {'created_at': r['created_at']} if r else None
                cutoff = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()
                ctx['exceptions_24h'] = c.execute(
                    "SELECT COUNT(*) FROM security_events_v31 WHERE event='request.exception' AND created_at>=?", (cutoff,)).fetchone()[0]
        except Exception:  # noqa: BLE001 - kesiapan tetap dijawab walau tabel belum ada
            pass
        checks = readiness_checks(env, ctx)
        return {'version': VERSION, 'generated_at': now(), 'checks': checks, 'summary': summarize(checks), 'limits': LIMITS}

    @app.get('/api/v35/ops/metrics')
    def v35_ops_metrics(role=Depends(auth)):
        snap = METRICS.snapshot()
        snap.update({'version': VERSION, 'uptime_seconds': int(time.time() - STARTED_AT),
                     'scope': 'proses ini saja; hilang saat restart; tidak digabung antar-instance',
                     'slow_threshold_ms': _slow_ms()})
        ms, err = db_probe()
        snap['db'] = {'ok': err is None, 'ping_ms': ms}
        try:
            with conn() as c:
                snap['task_runs'] = {s: c.execute('SELECT COUNT(*) FROM task_runs_v23 WHERE status=?', (s,)).fetchone()[0]
                                     for s in ('queued', 'running', 'completed', 'failed')}
        except Exception:  # noqa: BLE001
            snap['task_runs'] = None
        return snap

    @app.post('/api/v35/ops/backup-report')
    def v35_backup_report(data: BackupReportIn, role=Depends(require_admin)):
        with conn() as c:
            c.execute('INSERT INTO ops_backups_v35(kind,ok,bytes,sha256,detail,source,created_at) VALUES(?,?,?,?,?,?,?)',
                      (data.kind, 1 if data.ok else 0, data.bytes, data.sha256.lower(), data.detail.strip(), data.source.strip(), now()))
        audit(role, 'v35.backup_report', f'kind={data.kind}; ok={data.ok}; bytes={data.bytes}')
        return {'status': 'recorded', 'kind': data.kind, 'ok': data.ok}

    @app.get('/api/v35/ops/backups')
    def v35_backups(limit: int = 30, role=Depends(require_operator)):
        limit = max(1, min(limit, 100))
        with conn() as c:
            rows = c.execute('SELECT id,kind,ok,bytes,sha256,detail,source,created_at FROM ops_backups_v35 ORDER BY id DESC LIMIT ?', (limit,)).fetchall()
        return {'items': [dict(r) for r in rows]}
