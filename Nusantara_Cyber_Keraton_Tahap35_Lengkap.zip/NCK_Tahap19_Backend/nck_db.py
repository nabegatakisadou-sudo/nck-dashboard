"""NCK Tahap 33 - adapter database runtime.

Default tetap SQLite (perilaku lama tidak berubah). PostgreSQL hanya aktif jika
NCK_DB_BACKEND=postgres dan NCK_POSTGRES_DSN diisi.

Adapter ini membuat koneksi PostgreSQL berperilaku seperti sqlite3 yang dipakai main.py:
  - conn.execute(sql, params) mengembalikan cursor, "?" diubah menjadi "%s"
  - baris dapat diakses lewat indeks (r[0]) maupun nama (r["kolom"])
  - cursor.lastrowid (lewat RETURNING pada tabel ber-identity), cursor.rowcount
  - executescript(), INSERT OR IGNORE / OR REPLACE, LIKE (tidak peka huruf), IFNULL
  - DDL SQLite (INTEGER PRIMARY KEY [AUTOINCREMENT], INTEGER, REAL) diterjemahkan
  - PRAGMA table_info dan daftar tabel (sqlite_master) dipetakan ke information_schema

Batasan yang disengaja (lihat README_Tahap33): satu koneksi baru per conn() tanpa pool,
dan terjemahan SQL berbasis aturan - bukan penerjemah SQL umum.
"""
import os
import re
import sqlite3
import time
from functools import lru_cache

BACKEND = os.getenv('NCK_DB_BACKEND', 'sqlite').strip().lower()
if BACKEND not in ('sqlite', 'postgres'):
    raise RuntimeError("NCK_DB_BACKEND harus 'sqlite' atau 'postgres'.")
IS_PG = BACKEND == 'postgres'
PG_DSN = os.getenv('NCK_POSTGRES_DSN', '').strip()
PG_SCHEMA = os.getenv('NCK_POSTGRES_SCHEMA', 'public').strip() or 'public'
if IS_PG:
    if not PG_DSN:
        raise RuntimeError('NCK_DB_BACKEND=postgres membutuhkan NCK_POSTGRES_DSN.')
    if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,62}', PG_SCHEMA):
        raise RuntimeError('NCK_POSTGRES_SCHEMA tidak valid.')

# Klausa yang hanya relevan di PostgreSQL (kosong di SQLite).
SKIP_LOCKED_R = ' FOR UPDATE OF r SKIP LOCKED' if IS_PG else ''

if IS_PG:
    import psycopg  # noqa: E402
    import psycopg.errors  # noqa: E402
    INTEGRITY_ERRORS = (sqlite3.IntegrityError, psycopg.errors.IntegrityError)
else:
    INTEGRITY_ERRORS = (sqlite3.IntegrityError,)


def q(name):
    return '"' + str(name).replace('"', '""') + '"'


# --------------------------------------------------------------------------- Row
class Row:
    """Baris hibrida: r[0], r['nama'], r.keys(), dict(r) - mirip sqlite3.Row."""
    __slots__ = ('_k', '_v')

    def __init__(self, keys, values):
        self._k = tuple(keys)
        self._v = tuple(values)

    def keys(self):
        return list(self._k)

    def __getitem__(self, i):
        if isinstance(i, (int, slice)):
            return self._v[i]
        try:
            return self._v[self._k.index(i)]
        except ValueError:
            raise IndexError('No item with that key')

    def __iter__(self):
        return iter(self._v)

    def __len__(self):
        return len(self._v)

    def __eq__(self, other):
        return isinstance(other, Row) and self._k == other._k and self._v == other._v

    def __repr__(self):
        return 'Row(' + ', '.join(f'{k}={v!r}' for k, v in zip(self._k, self._v)) + ')'


# ---------------------------------------------------------------- SQL tokenizer
def _segments(sql):
    """Pecah SQL menjadi (jenis, teks): code / str / ident / comment."""
    out, i, n = [], 0, len(sql)
    buf_start = 0

    def flush(upto):
        if upto > buf_start:
            out.append(('code', sql[buf_start:upto]))

    while i < n:
        ch = sql[i]
        if ch == "'" or ch == '"':
            flush(i)
            j = i + 1
            while j < n:
                if sql[j] == ch:
                    if j + 1 < n and sql[j + 1] == ch:
                        j += 2
                        continue
                    break
                j += 1
            out.append(('str' if ch == "'" else 'ident', sql[i:j + 1]))
            i = j + 1
            buf_start = i
        elif ch == '-' and sql.startswith('--', i):
            flush(i)
            j = sql.find('\n', i)
            j = n if j < 0 else j
            out.append(('comment', sql[i:j]))
            i = j
            buf_start = i
        elif ch == '/' and sql.startswith('/*', i):
            flush(i)
            j = sql.find('*/', i + 2)
            j = n if j < 0 else j + 2
            out.append(('comment', sql[i:j]))
            i = j
            buf_start = i
        else:
            i += 1
    flush(n)
    return out


def split_statements(script):
    """Pisahkan skrip menjadi pernyataan (titik koma di luar kutip/komentar)."""
    stmts, cur = [], []
    for kind, text in _segments(script):
        if kind != 'code':
            cur.append(text)
            continue
        parts = text.split(';')
        for idx, part in enumerate(parts):
            cur.append(part)
            if idx < len(parts) - 1:
                s = _strip_leading_comments(''.join(cur))
                if s and not _only_comments(s):
                    stmts.append(s)
                cur = []
    s = _strip_leading_comments(''.join(cur))
    if s and not _only_comments(s):
        stmts.append(s)
    return stmts


def _strip_leading_comments(s):
    segs = _segments(s)
    i = 0
    while i < len(segs) and (segs[i][0] == 'comment' or (segs[i][0] == 'code' and not segs[i][1].strip())):
        i += 1
    return ''.join(t for _, t in segs[i:]).strip()


def _only_comments(s):
    return all(k == 'comment' or (k == 'code' and not t.strip()) for k, t in _segments(s))


# -------------------------------------------------------------- terjemahan SQL
class Translated:
    __slots__ = ('sql', 'noop', 'upsert', 'insert_table', 'has_returning')

    def __init__(self, sql, noop=False, upsert=None, insert_table=None, has_returning=False):
        self.sql = sql
        self.noop = noop
        self.upsert = upsert
        self.insert_table = insert_table
        self.has_returning = has_returning


_RE_BEGIN = re.compile(r'^\s*BEGIN(\s+(IMMEDIATE|DEFERRED|EXCLUSIVE|TRANSACTION))?\s*;?\s*$', re.I)
_RE_PRAGMA_TI = re.compile(r'^\s*PRAGMA\s+table_info\(\s*["\']?([A-Za-z0-9_]+)["\']?\s*\)\s*;?\s*$', re.I)
_RE_MASTER = re.compile(
    r"^\s*SELECT\s+name\s+FROM\s+sqlite_master\s+WHERE\s+type\s*=\s*'table'"
    r"(?:\s+AND\s+name\s+NOT\s+LIKE\s+'sqlite_%')?(\s+ORDER\s+BY\s+name)?\s*;?\s*$", re.I)
_RE_INT_PK = re.compile(r'\bINTEGER\s+PRIMARY\s+KEY(?:\s+AUTOINCREMENT)?', re.I)
_RE_INTEGER = re.compile(r'\bINTEGER\b', re.I)
_RE_REAL = re.compile(r'\bREAL\b', re.I)
_RE_LIKE = re.compile(r'\bLIKE\b', re.I)
_RE_IFNULL = re.compile(r'\bIFNULL\s*\(', re.I)
_RE_OR_IGNORE = re.compile(r'^(\s*)INSERT\s+OR\s+IGNORE\s+INTO\b', re.I)
_RE_OR_REPLACE = re.compile(r'^(\s*)INSERT\s+OR\s+REPLACE\s+INTO\s+("?[A-Za-z0-9_]+"?)\s*\(([^)]*)\)', re.I)
_RE_JULIAN = re.compile(r'\bjulianday\s*\(', re.I)


def _julianday(t):
    """julianday(x) -> hari (float) sejak epoch; hanya selisih yang bermakna, sama seperti pemakaian main.py."""
    out, i = [], 0
    while True:
        m = _RE_JULIAN.search(t, i)
        if not m:
            out.append(t[i:])
            return ''.join(out)
        out.append(t[i:m.start()])
        j, depth = m.end(), 1
        while j < len(t) and depth:
            depth += (t[j] == '(') - (t[j] == ')')
            j += 1
        out.append('(EXTRACT(EPOCH FROM (' + t[m.end():j - 1] + ')::timestamptz)/86400.0)')
        i = j


_RE_INSERT_TABLE = re.compile(r'^\s*INSERT\s+INTO\s+"?([A-Za-z0-9_]+)"?', re.I)


def _map_code(sql, fn):
    return ''.join(fn(t) if k == 'code' else t for k, t in _segments(sql))


def _first_word(sql):
    for k, t in _segments(sql):
        if k == 'code' and t.strip():
            return t.split()[0].upper()
    return ''


def _placeholders(sql, escape):
    """'?' -> '%s' (di luar kutip). Jika escape, '%' literal menjadi '%%'."""
    parts = []
    for kind, text in _segments(sql):
        if kind == 'code':
            text = text.replace('%', '%%') if escape else text
            text = text.replace('?', '%s')
        elif escape:
            text = text.replace('%', '%%')
        parts.append(text)
    return ''.join(parts)


@lru_cache(maxsize=2048)
def translate(sql, escape=True):
    """Terjemahkan satu pernyataan SQLite ke PostgreSQL."""
    s = sql.strip()
    if _RE_BEGIN.match(s):
        return Translated('', noop=True)
    m = _RE_PRAGMA_TI.match(s)
    if m:
        tbl = m.group(1).lower().replace("'", "''")
        return Translated(
            "SELECT (c.ordinal_position-1) AS cid, c.column_name AS name, c.data_type AS type, "
            "CASE WHEN c.is_nullable='NO' THEN 1 ELSE 0 END AS notnull, c.column_default AS dflt_value, "
            "CASE WHEN EXISTS (SELECT 1 FROM information_schema.table_constraints tc "
            "JOIN information_schema.key_column_usage k ON k.constraint_name=tc.constraint_name "
            "AND k.table_schema=tc.table_schema AND k.table_name=tc.table_name "
            "WHERE tc.constraint_type='PRIMARY KEY' AND tc.table_schema=c.table_schema "
            "AND tc.table_name=c.table_name AND k.column_name=c.column_name) THEN 1 ELSE 0 END AS pk "
            "FROM information_schema.columns c WHERE c.table_schema=current_schema() "
            f"AND c.table_name='{tbl}' ORDER BY c.ordinal_position")
    m = _RE_MASTER.match(s)
    if m:
        order = ' ORDER BY name' if m.group(1) else ''
        return Translated("SELECT table_name AS name FROM information_schema.tables "
                          "WHERE table_schema=current_schema() AND table_type='BASE TABLE'" + order)
    word = _first_word(s)
    body = s.rstrip(';').rstrip()
    upsert = None
    if word in ('CREATE', 'ALTER'):
        def ddl(t):
            t = _RE_INT_PK.sub('BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY', t)
            t = _RE_INTEGER.sub('BIGINT', t)
            return _RE_REAL.sub('DOUBLE PRECISION', t)
        body = _map_code(body, ddl)
    elif word == 'INSERT':
        mo = _RE_OR_REPLACE.match(body)
        if mo:
            table = mo.group(2).strip('"')
            cols = [c.strip().strip('"') for c in mo.group(3).split(',')]
            body = _RE_OR_REPLACE.sub(lambda x: f'{x.group(1)}INSERT INTO {x.group(2)}({x.group(3)})', body, count=1)
            upsert = (table, cols)
        elif _RE_OR_IGNORE.match(body):
            body = _RE_OR_IGNORE.sub(lambda x: f'{x.group(1)}INSERT INTO', body, count=1)
            if not re.search(r'\bON\s+CONFLICT\b', body, re.I):
                body += ' ON CONFLICT DO NOTHING'
    if word not in ('CREATE', 'ALTER'):
        body = _map_code(body, lambda t: _julianday(_RE_IFNULL.sub('COALESCE(', _RE_LIKE.sub('ILIKE', t))))
    body = _placeholders(body, escape)
    mi = _RE_INSERT_TABLE.match(body) if word == 'INSERT' else None
    has_ret = bool(re.search(r'\bRETURNING\b', body, re.I))
    return Translated(body, upsert=upsert, insert_table=mi.group(1) if mi else None, has_returning=has_ret)


def _adapt_param(v):
    """Angka dikirim sebagai teks tak-bertipe agar PostgreSQL menyimpulkan tipe dari konteks
    (meniru typing longgar SQLite: kolom TEXT yang diisi angka, perbandingan teks/angka)."""
    if isinstance(v, bool):
        return '1' if v else '0'
    if isinstance(v, (int, float)):
        return str(v)
    return v


# ----------------------------------------------------------------- PostgreSQL
_META_CACHE = {}


# --- Tahap 34: DDL idempoten yang aman terhadap balapan antar proses (API + worker start bersamaan pada skema kosong).
# PostgreSQL: dua transaksi yang menjalankan CREATE ... IF NOT EXISTS bersamaan dapat gagal 'duplicate key ... pg_*_index'
# (transaksi kedua menunggu yang pertama commit, lalu menabrak indeks katalog). Solusi: SAVEPOINT per statement DDL + ulang;
# pada percobaan ulang IF NOT EXISTS melihat objek yang sudah di-commit.
_DDL_RE = re.compile(r'^\s*(CREATE\s+(UNIQUE\s+)?(TABLE|INDEX|SEQUENCE|SCHEMA)|ALTER\s+TABLE)\b', re.I)
_DDL_RACE_INDEXES = ('pg_type_typname_nsp_index', 'pg_namespace_nspname_index', 'pg_class_relname_nsp_index',
                     'pg_proc_proname_args_nsp_index', 'pg_constraint_conrelid_contypid_conname_index')
_DDL_RETRIES = 8


def _is_ddl_race(exc):
    st = getattr(exc, 'sqlstate', None)
    if st in ('42P07', '42P06', '42710'):  # relation/schema/object sudah ada (dibuat proses lain di antara cek & buat)
        return True
    return st == '23505' and any(n in str(exc) for n in _DDL_RACE_INDEXES)


def _execute_ddl(raw_cursor, stmt, args):
    for attempt in range(_DDL_RETRIES):
        raw_cursor.execute('SAVEPOINT nck_ddl')
        try:
            raw_cursor.execute(stmt, args)
            raw_cursor.execute('RELEASE SAVEPOINT nck_ddl')
            return
        except Exception as exc:  # noqa: BLE001
            raw_cursor.execute('ROLLBACK TO SAVEPOINT nck_ddl')
            raw_cursor.execute('RELEASE SAVEPOINT nck_ddl')
            if getattr(exc, 'sqlstate', None) == '42701' and re.match(r'\s*ALTER\s+TABLE', stmt, re.I):
                return  # kolom sudah ditambahkan proses lain
            if attempt < _DDL_RETRIES - 1 and _is_ddl_race(exc):
                time.sleep(0.25 * (attempt + 1))
                continue
            raise


class PGCursor:
    def __init__(self, conn):
        self._conn = conn
        self._raw = conn._raw.cursor()
        self.lastrowid = None
        self.rowcount = -1
        self._cols = None
        self._has_result = False

    # metadata (cache proses): kolom identity dan primary key
    def _identity(self, table):
        key = ('identity', PG_SCHEMA, table)
        if key not in _META_CACHE:
            cur = self._conn._raw.cursor()
            cur.execute("SELECT column_name FROM information_schema.columns WHERE table_schema=current_schema() "
                        "AND table_name=%s AND is_identity='YES' ORDER BY ordinal_position", (table,))
            row = cur.fetchone()
            _META_CACHE[key] = row[0] if row else None
        return _META_CACHE[key]

    def _pk(self, table):
        key = ('pk', PG_SCHEMA, table)
        if key not in _META_CACHE:
            cur = self._conn._raw.cursor()
            cur.execute("SELECT a.attname FROM pg_index i JOIN pg_attribute a ON a.attrelid=i.indrelid "
                        "AND a.attnum=ANY(i.indkey) WHERE i.indrelid=%s::regclass AND i.indisprimary "
                        "ORDER BY array_position(i.indkey, a.attnum)", (table,))
            _META_CACHE[key] = [r[0] for r in cur.fetchall()]
        return _META_CACHE[key]

    def execute(self, sql, params=()):
        params = tuple(params) if params else ()
        t = translate(sql, bool(params))
        self.lastrowid = None
        self._cols = None
        self._has_result = False
        if t.noop:
            self.rowcount = -1
            return self
        stmt = t.sql
        if t.upsert:
            table, cols = t.upsert
            pk = self._pk(table)
            if not pk:
                raise RuntimeError(f'INSERT OR REPLACE pada tabel tanpa primary key: {table}')
            upd = [c for c in cols if c not in pk]
            tail = (' ON CONFLICT (' + ','.join(q(c) for c in pk) + ') DO UPDATE SET ' +
                    ','.join(f'{q(c)}=EXCLUDED.{q(c)}' for c in upd)) if upd else \
                   ' ON CONFLICT (' + ','.join(q(c) for c in pk) + ') DO NOTHING'
            stmt += tail
        ret_col = None
        if t.insert_table and not t.has_returning:
            ret_col = self._identity(t.insert_table)
            if ret_col:
                stmt += ' RETURNING ' + q(ret_col)
        args = tuple(_adapt_param(p) for p in params) if params else None
        if _DDL_RE.match(stmt):
            _execute_ddl(self._raw, stmt, args)
        else:
            self._raw.execute(stmt, args)
        self.rowcount = self._raw.rowcount
        if ret_col:
            rows = self._raw.fetchall()
            self.lastrowid = rows[-1][0] if rows else None
        elif self._raw.description:
            self._cols = [d[0] for d in self._raw.description]
            self._has_result = True
        return self

    def executemany(self, sql, seq):
        total = 0
        for params in seq:
            self.execute(sql, params)
            total += max(self.rowcount, 0)
        self.rowcount = total
        return self

    def executescript(self, script):
        for stmt in split_statements(script):
            self.execute(stmt)
        return self

    def _wrap(self, row):
        return None if row is None else Row(self._cols, row)

    def fetchone(self):
        if not self._has_result:
            return None
        return self._wrap(self._raw.fetchone())

    def fetchall(self):
        if not self._has_result:
            return []
        return [self._wrap(r) for r in self._raw.fetchall()]

    def fetchmany(self, size=1):
        if not self._has_result:
            return []
        return [self._wrap(r) for r in self._raw.fetchmany(size)]

    def __iter__(self):
        return iter(self.fetchall())

    def close(self):
        try:
            self._raw.close()
        except Exception:
            pass


class PGConnection:
    def __init__(self, raw):
        self._raw = raw

    def cursor(self):
        return PGCursor(self)

    def execute(self, sql, params=()):
        return self.cursor().execute(sql, params)

    def executemany(self, sql, seq):
        return self.cursor().executemany(sql, seq)

    def executescript(self, script):
        return self.cursor().executescript(script)

    def commit(self):
        self._raw.commit()

    def rollback(self):
        self._raw.rollback()

    def close(self):
        try:
            self._raw.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, et, ev, tb):
        try:
            if et is None:
                self._raw.commit()
            else:
                self._raw.rollback()
        finally:
            self.close()
        return False


def ensure_schema():
    """Buat schema PostgreSQL bila bukan 'public' (dipanggil sekali saat start)."""
    if not IS_PG or PG_SCHEMA == 'public':
        return
    for attempt in range(_DDL_RETRIES):
        try:
            with psycopg.connect(PG_DSN, connect_timeout=8) as raw:
                raw.execute(f'CREATE SCHEMA IF NOT EXISTS {q(PG_SCHEMA)}')
            return
        except Exception as exc:  # noqa: BLE001  (balapan CREATE SCHEMA antar proses)
            if attempt < _DDL_RETRIES - 1 and _is_ddl_race(exc):
                time.sleep(0.25 * (attempt + 1))
                continue
            raise


def connect(sqlite_path=None):
    if not IS_PG:
        c = sqlite3.connect(sqlite_path)
        c.row_factory = sqlite3.Row
        return c
    kwargs = {'connect_timeout': 8}
    if PG_SCHEMA != 'public':
        kwargs['options'] = f'-c search_path={PG_SCHEMA}'
    return PGConnection(psycopg.connect(PG_DSN, **kwargs))


def health():
    """Cek konektivitas sederhana untuk endpoint status."""
    try:
        with connect(os.getenv('NCK_DB_PATH', '')) as c:
            c.execute('SELECT 1').fetchone()
        return {'ok': True, 'backend': BACKEND}
    except Exception as e:  # pragma: no cover - dipakai endpoint
        return {'ok': False, 'backend': BACKEND, 'error': type(e).__name__ + ': ' + str(e)[:200]}


def identity_status(c):
    """Status sequence identity (hanya PostgreSQL): next_value harus > MAX(kolom), jika tidak INSERT baru bentrok."""
    out = []
    if not IS_PG:
        return out
    cols = c.execute("SELECT table_name, column_name FROM information_schema.columns "
                     "WHERE table_schema=current_schema() AND is_identity='YES' ORDER BY table_name").fetchall()
    for r in cols:
        tn, cn = r['table_name'], r['column_name']
        seq = c.execute('SELECT pg_get_serial_sequence(?,?) AS s', ('"' + tn + '"', cn)).fetchone()['s']
        if not seq:
            continue
        mx = int(c.execute(f'SELECT COALESCE(MAX({q(cn)}),0) AS m FROM {q(tn)}').fetchone()['m'])
        st = c.execute(f'SELECT last_value, is_called FROM {seq}').fetchone()
        nxt = int(st['last_value']) + (1 if st['is_called'] else 0)
        out.append({'table': tn, 'column': cn, 'sequence': seq, 'next_value': nxt, 'max_value': mx, 'ok': nxt > mx})
    return out


def sync_identity_sequences():
    """Naikkan sequence yang tertinggal dari data (mis. setelah restore atau INSERT dengan id eksplisit).
    Tidak pernah menurunkan nilai sequence. Mengembalikan daftar yang diperbaiki."""
    if not IS_PG:
        return []
    fixed = []
    with connect() as c:
        for it in identity_status(c):
            if not it['ok']:
                c.execute('SELECT setval(?,?,true)', (it['sequence'], it['max_value']))
                fixed.append({'table': it['table'], 'column': it['column'], 'set_to': it['max_value']})
    return fixed
