import os, sqlite3, secrets, hashlib, json, time, threading, uuid, socket
import nck_db  # Tahap 33: adapter database (SQLite default, PostgreSQL opt-in)
import nck_ops_v35  # Tahap 35: operasi produksi (ready, readiness, metrik, laporan backup)
from datetime import datetime, timezone
from typing import Optional
import httpx
from fastapi import FastAPI, Header, HTTPException, Depends, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

ROOT=os.path.dirname(os.path.abspath(__file__))
DB=os.getenv("NCK_DB_PATH",os.path.join(ROOT,"nck_enterprise.db"))
SERVICE=os.getenv("NCK_SERVICE_NAME","Nusantara Cyber-Keraton Tahap 35")
def now(): return datetime.now(timezone.utc).isoformat()
nck_db.ensure_schema()
def conn():
    return nck_db.connect(DB)
def init():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS memories(id INTEGER PRIMARY KEY, project_id INTEGER NOT NULL, content TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY(project_id) REFERENCES projects(id));
        CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY, title TEXT NOT NULL, instruction TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, role TEXT NOT NULL, action TEXT NOT NULL, detail TEXT, created_at TEXT NOT NULL);
        """)
def audit(role,action,detail=""):
    with conn() as c:c.execute("INSERT INTO audit(role,action,detail,created_at) VALUES(?,?,?,?)",(role,action,str(detail)[:1500],now()))
_PREV_DIGESTS=set()
def token_map():
    # Store SHA-256 digests in env, never store raw access tokens in DB.
    # Tahap 35: NCK_<PERAN>_TOKEN_PREVIOUS = token LAMA yang masih berlaku sementara (rotasi tanpa putus).
    global _PREV_DIGESTS
    out={}; prev=set()
    for role,var in (("viewer","NCK_VIEWER_TOKEN"),("operator","NCK_OPERATOR_TOKEN"),("admin","NCK_ADMIN_TOKEN")):
        raw=os.getenv(var,"").strip()
        if raw: out[hashlib.sha256(raw.encode()).hexdigest()]=role
    for role,var in (("viewer","NCK_VIEWER_TOKEN_PREVIOUS"),("operator","NCK_OPERATOR_TOKEN_PREVIOUS"),("admin","NCK_ADMIN_TOKEN_PREVIOUS")):
        raw=os.getenv(var,"").strip()
        if raw:
            d=hashlib.sha256(raw.encode()).hexdigest()
            if d not in out:  # token lama tidak boleh menimpa token saat ini milik peran lain
                out[d]=role; prev.add(d)
    _PREV_DIGESTS=prev
    return out
def auth(x_nck_token: Optional[str]=Header(default=None)):
    if not x_nck_token: raise HTTPException(401,"Access token diperlukan.")
    digest=hashlib.sha256(x_nck_token.encode()).hexdigest()
    role=None
    # Constant-time digest comparisons avoid direct timing-sensitive dictionary lookup.
    for known_digest, known_role in token_map().items():
        if secrets.compare_digest(digest, known_digest):
            role=known_role
    if not role: raise HTTPException(403,"Token tidak valid atau belum dikonfigurasi.")
    if digest in _PREV_DIGESTS: nck_ops_v35.note_previous_use(role)
    return role
def require_operator(role=Depends(auth)):
    if role not in ("operator","admin"): raise HTTPException(403,"Hak Operator atau Admin diperlukan.")
    return role
app=FastAPI(title="Nusantara Cyber-Keraton Enterprise API",version="35.0.0")
origins=[x.strip() for x in os.getenv("NCK_CORS_ORIGINS","").split(",") if x.strip()]
app.add_middleware(CORSMiddleware,allow_origins=origins or [],allow_credentials=False,allow_methods=["GET","POST","PATCH","DELETE","OPTIONS"],allow_headers=["Content-Type","X-NCK-Token"])
@app.on_event("startup")
def startup(): init()
class MemoryIn(BaseModel):
    project:str=Field(min_length=1,max_length=120)
    content:str=Field(min_length=1,max_length=10000)
class TaskIn(BaseModel):
    title:str=Field(min_length=1,max_length=200)
    instruction:str=Field(min_length=1,max_length=10000)
class ChatIn(BaseModel):
    provider:str
    message:str=Field(min_length=1,max_length=20000)
@app.get("/health")
def health(): return {"status":"ok","service":SERVICE}
@app.get("/api/v19/status")
def status(role=Depends(auth)): return {"service":SERVICE,"role":role,"database":"sqlite","version":"19.0.0"}
@app.get("/api/v19/overview")
def overview(role=Depends(auth)):
    with conn() as c:
        q=lambda t:c.execute(f"SELECT COUNT(*) n FROM {t}").fetchone()["n"]
        return {"projects":q("projects"),"memories":q("memories"),"tasks":q("tasks"),"audit_events":q("audit"),"database":"SQLite"}
@app.post("/api/v19/memories")
def add_memory(data:MemoryIn,role=Depends(require_operator)):
    with conn() as c:
        row=c.execute("SELECT id FROM projects WHERE name=?",(data.project.strip(),)).fetchone()
        if row: pid=row["id"]
        else: pid=c.execute("INSERT INTO projects(name,created_at) VALUES(?,?)",(data.project.strip(),now())).lastrowid
        cur=c.execute("INSERT INTO memories(project_id,content,created_at) VALUES(?,?,?)",(pid,data.content,now()))
        mid=cur.lastrowid
    audit(role,"memory.create",f"project={data.project}; id={mid}")
    return {"id":mid,"project_id":pid,"status":"stored"}
@app.post("/api/v19/tasks")
def add_task(data:TaskIn,role=Depends(require_operator)):
    with conn() as c:
        cur=c.execute("INSERT INTO tasks(title,instruction,status,created_at) VALUES(?,?,?,?)",(data.title,data.instruction,"open",now()))
        tid=cur.lastrowid
    audit(role,"task.create",f"id={tid}; title={data.title}")
    return {"id":tid,"status":"open"}
@app.get("/api/v19/audit")
def get_audit(role=Depends(auth)):
    with conn() as c: rows=c.execute("SELECT role,action,detail,created_at FROM audit ORDER BY id DESC LIMIT 100").fetchall()
    return {"items":[dict(x) for x in rows]}
@app.post("/api/v19/ai/chat")
async def ai_chat(data:ChatIn,role=Depends(require_operator)):
    provider=data.provider.lower()
    if provider=="openai":
        key=os.getenv("OPENAI_API_KEY",""); model=os.getenv("OPENAI_MODEL","gpt-4.1-mini")
        if not key: raise HTTPException(503,"OPENAI_API_KEY belum dikonfigurasi di environment server.")
        url="https://api.openai.com/v1/chat/completions"
        headers={"Authorization":f"Bearer {key}","Content-Type":"application/json"}
        payload={"model":model,"messages":[{"role":"user","content":data.message}]}
        async with httpx.AsyncClient(timeout=90) as client:
            r=await client.post(url,headers=headers,json=payload)
        if r.status_code>=400: raise HTTPException(502,"Provider OpenAI gagal: "+r.text[:500])
        reply=r.json()["choices"][0]["message"]["content"]
    elif provider=="gemini":
        key=os.getenv("GEMINI_API_KEY",""); model=os.getenv("GEMINI_MODEL","gemini-2.5-flash")
        if not key: raise HTTPException(503,"GEMINI_API_KEY belum dikonfigurasi di environment server.")
        url=f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
        async with httpx.AsyncClient(timeout=90) as client:
            r=await client.post(url,params={"key":key},json={"contents":[{"parts":[{"text":data.message}]}]})
        if r.status_code>=400: raise HTTPException(502,"Provider Gemini gagal: "+r.text[:500])
        obj=r.json(); reply="".join(p.get("text","") for p in obj.get("candidates",[{}])[0].get("content",{}).get("parts",[]))
    else: raise HTTPException(400,"Provider tidak didukung. Gunakan openai atau gemini.")
    audit(role,"ai.chat",f"provider={provider}; input_chars={len(data.message)}")
    return {"provider":provider,"reply":reply}


# ===== Tahap 20: workflow orchestration =====
import asyncio
from fastapi import BackgroundTasks
from pydantic import Field

def init_v20():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS workflows(
          id TEXT PRIMARY KEY, name TEXT NOT NULL, instruction TEXT NOT NULL,
          status TEXT NOT NULL, retries INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL, started_at TEXT, finished_at TEXT
        );
        CREATE TABLE IF NOT EXISTS workflow_steps(
          id INTEGER PRIMARY KEY, workflow_id TEXT NOT NULL, position INTEGER NOT NULL,
          title TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'queued',
          attempts INTEGER NOT NULL DEFAULT 0, result TEXT, error TEXT,
          FOREIGN KEY(workflow_id) REFERENCES workflows(id)
        );
        """)
@app.on_event("startup")
def startup_v20(): init_v20()

class WorkflowIn(BaseModel):
    name:str=Field(min_length=1,max_length=120)
    instruction:str=Field(min_length=1,max_length=10000)
    steps:list[str]=Field(min_length=1,max_length=30)
    retries:int=Field(default=1,ge=0,le=3)

def workflow_view(wid):
    with conn() as c:
        w=c.execute("SELECT * FROM workflows WHERE id=?",(wid,)).fetchone()
        if not w: return None
        ss=c.execute("SELECT * FROM workflow_steps WHERE workflow_id=? ORDER BY position",(wid,)).fetchall()
    return {**dict(w),"steps":[dict(s) for s in ss]}

@app.get("/api/v20/status")
def v20_status(role=Depends(auth)):
    return {"service":SERVICE,"workflow_engine":"enabled","database":"sqlite","version":"20.0.0"}

@app.post("/api/v20/workflows")
def v20_create(data:WorkflowIn,role=Depends(require_operator)):
    wid="WF20-"+secrets.token_hex(6).upper()
    with conn() as c:
        c.execute("INSERT INTO workflows(id,name,instruction,status,retries,created_at) VALUES(?,?,?,?,?,?)",
                  (wid,data.name.strip(),data.instruction.strip(),"pending_approval",data.retries,now()))
        for i,title in enumerate(data.steps,1):
            title=title.strip()
            if not title: continue
            c.execute("INSERT INTO workflow_steps(workflow_id,position,title) VALUES(?,?,?)",(wid,i,title[:500]))
    audit(role,"workflow.create",f"id={wid}; steps={len(data.steps)}")
    return {"id":wid,"status":"pending_approval","steps":len(data.steps)}

async def execute_workflow(wid):
    with conn() as c:
        w=c.execute("SELECT * FROM workflows WHERE id=?",(wid,)).fetchone()
        if not w:return
        c.execute("UPDATE workflows SET status='running',started_at=? WHERE id=?",(now(),wid))
        rows=c.execute("SELECT * FROM workflow_steps WHERE workflow_id=? ORDER BY position",(wid,)).fetchall()
    failed=False
    for step in rows:
        success=False; last_error=""
        for attempt in range(int(w["retries"])+1):
            with conn() as c:
                c.execute("UPDATE workflow_steps SET status='running',attempts=? WHERE id=?",(attempt+1,step["id"]))
            try:
                # A controlled orchestration checkpoint: records the work item and its instruction.
                # No arbitrary shell/code execution is performed.
                result=f"Langkah tercatat dan diproses oleh workflow engine: {step['title']}. Instruksi induk: {w['instruction'][:1200]}"
                with conn() as c:
                    c.execute("UPDATE workflow_steps SET status='completed',result=?,error=NULL WHERE id=?",(result,step["id"]))
                success=True; break
            except Exception as exc:
                last_error=str(exc)
                with conn() as c:c.execute("UPDATE workflow_steps SET error=? WHERE id=?",(last_error[:1500],step["id"]))
                await asyncio.sleep(min(2**attempt,5))
        if not success:
            failed=True
            with conn() as c:c.execute("UPDATE workflow_steps SET status='failed',error=? WHERE id=?",(last_error[:1500],step["id"]))
            break
    final="failed" if failed else "completed"
    with conn() as c:c.execute("UPDATE workflows SET status=?,finished_at=? WHERE id=?",(final,now(),wid))
    audit("system","workflow.finish",f"id={wid}; status={final}")

@app.post("/api/v20/workflows/{wid}/approve")
async def v20_approve(wid:str,background_tasks:BackgroundTasks,role=Depends(require_operator)):
    with conn() as c:
        w=c.execute("SELECT status FROM workflows WHERE id=?",(wid,)).fetchone()
        if not w:raise HTTPException(404,"Workflow tidak ditemukan.")
        if w["status"]!="pending_approval":raise HTTPException(409,"Workflow tidak sedang menunggu persetujuan.")
        c.execute("UPDATE workflows SET status='queued' WHERE id=?",(wid,))
    audit(role,"workflow.approve",wid)
    background_tasks.add_task(execute_workflow,wid)
    return {"id":wid,"status":"queued"}

@app.get("/api/v20/workflows")
def v20_list(status:Optional[str]=None,role=Depends(auth)):
    with conn() as c:
        if status:
            rows=c.execute("SELECT w.*,COUNT(s.id) steps FROM workflows w LEFT JOIN workflow_steps s ON s.workflow_id=w.id WHERE w.status=? GROUP BY w.id ORDER BY w.created_at DESC LIMIT 100",(status,)).fetchall()
        else:
            rows=c.execute("SELECT w.*,COUNT(s.id) steps FROM workflows w LEFT JOIN workflow_steps s ON s.workflow_id=w.id GROUP BY w.id ORDER BY w.created_at DESC LIMIT 100").fetchall()
    return {"items":[dict(x) for x in rows]}

@app.get("/api/v20/workflows/{wid}")
def v20_get(wid:str,role=Depends(auth)):
    d=workflow_view(wid)
    if not d:raise HTTPException(404,"Workflow tidak ditemukan.")
    return d


# ===== Tahap 21: real AI agent execution, collaboration, review, parallel DAG =====
import re as _re
from typing import Literal

AGENTS_V21 = [
    {"id":"ki_suradiraksa","number":"01","name":"Ki Suradiraksa","role":"Sutradara AI & Video Director","division":"Kreatif, Visual, & Video","system":"Anda adalah sutradara AI dan video director. Rancang konsep, urutan adegan, arahan visual, dan keputusan produksi secara terstruktur."},
    {"id":"ki_mandra","number":"02","name":"Ki Mandra","role":"Desain Grafis & Brand Visual","division":"Kreatif, Visual, & Video","system":"Anda adalah desainer grafis dan brand visual. Berikan arahan visual, komposisi, tipografi, warna, dan sistem identitas yang dapat diterapkan."},
    {"id":"ki_juru_tulis","number":"03","name":"Ki Juru Tulis","role":"Penulis Naskah & Storytelling","division":"Kreatif, Visual, & Video","system":"Anda adalah penulis naskah dan storyteller. Hasilkan tulisan yang runtut, orisinal, sesuai audiens, dan siap digunakan."},
    {"id":"ki_sutedjo","number":"04","name":"Ki Sutedjo","role":"Editing Video & Post Production","division":"Kreatif, Visual, & Video","system":"Anda adalah editor video dan spesialis post-production. Susun workflow editing, pacing, transisi, audio, dan spesifikasi hasil akhir."},
    {"id":"nyai_carita","number":"05","name":"Nyai Carita","role":"Narasi & Konten Kreatif","division":"Kreatif, Visual, & Video","system":"Anda adalah spesialis narasi dan konten kreatif. Buat narasi yang kuat, jelas, menarik, dan sesuai tujuan komunikasi."},
    {"id":"ki_rupa","number":"06","name":"Ki Rupa","role":"Ilustrasi & Concept Art","division":"Kreatif, Visual, & Video","system":"Anda adalah ilustrator dan concept artist. Kembangkan konsep ilustrasi, arahan artistik, detail subjek, komposisi, dan prompt visual."},
]
AGENT_BY_ID_V21={a["id"]:a for a in AGENTS_V21}

class Step21In(BaseModel):
    key:str=Field(min_length=1,max_length=40)
    title:str=Field(min_length=1,max_length=200)
    instruction:str=Field(min_length=1,max_length=8000)
    agent_id:str=Field(min_length=1,max_length=80)
    depends_on:list[str]=Field(default_factory=list,max_length=20)

class Workflow21In(BaseModel):
    name:str=Field(min_length=1,max_length=120)
    instruction:str=Field(min_length=1,max_length=10000)
    provider:Literal["openai","gemini"]="openai"
    steps:list[Step21In]=Field(min_length=1,max_length=20)
    retries:int=Field(default=1,ge=0,le=3)
    review_enabled:bool=True
    review_threshold:int=Field(default=75,ge=50,le=100)
    parallel_enabled:bool=True


def init_v21():
    with conn() as c:
        existing={r[1] for r in c.execute("PRAGMA table_info(workflow_steps)").fetchall()}
        additions={
            "step_key":"TEXT", "instruction":"TEXT", "agent_id":"TEXT", "depends_on":"TEXT NOT NULL DEFAULT '[]'",
            "provider":"TEXT", "review_status":"TEXT", "review_score":"INTEGER", "review_feedback":"TEXT",
            "prompt_tokens":"INTEGER NOT NULL DEFAULT 0", "completion_tokens":"INTEGER NOT NULL DEFAULT 0"
        }
        for col,typ in additions.items():
            if col not in existing: c.execute(f"ALTER TABLE workflow_steps ADD COLUMN {col} {typ}")
        wfcols={r[1] for r in c.execute("PRAGMA table_info(workflows)").fetchall()}
        for col,typ in {"provider_v21":"TEXT","review_enabled_v21":"INTEGER NOT NULL DEFAULT 1","review_threshold_v21":"INTEGER NOT NULL DEFAULT 75","parallel_enabled_v21":"INTEGER NOT NULL DEFAULT 1"}.items():
            if col not in wfcols: c.execute(f"ALTER TABLE workflows ADD COLUMN {col} {typ}")
        c.execute("CREATE TABLE IF NOT EXISTS workflow_v21_config(workflow_id TEXT PRIMARY KEY,provider TEXT,review_enabled INTEGER,review_threshold INTEGER,parallel_enabled INTEGER)")
        c.execute("""CREATE TABLE IF NOT EXISTS ai_usage_v21(
            id INTEGER PRIMARY KEY, workflow_id TEXT NOT NULL, step_key TEXT NOT NULL,
            agent_id TEXT NOT NULL, provider TEXT NOT NULL, call_type TEXT NOT NULL,
            prompt_chars INTEGER NOT NULL DEFAULT 0, completion_chars INTEGER NOT NULL DEFAULT 0,
            prompt_tokens INTEGER NOT NULL DEFAULT 0, completion_tokens INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL)""")

@app.on_event("startup")
def startup_v21(): init_v21()

async def llm_call_v21(provider:str, system_prompt:str, user_prompt:str, model:Optional[str]=None):
    """Panggil provider AI. provider: openai (atau custom = kompatibel OpenAI), gemini, ollama. model=None -> default env."""
    if provider=="custom": provider="openai"
    if provider=="openai":
        key=os.getenv("OPENAI_API_KEY",""); model=model or os.getenv("OPENAI_MODEL","gpt-4.1-mini")
        base=os.getenv("OPENAI_BASE_URL","https://api.openai.com/v1").rstrip("/")
        if not key: raise RuntimeError("OPENAI_API_KEY belum dikonfigurasi pada environment backend.")
        payload={"model":model,"messages":[{"role":"system","content":system_prompt},{"role":"user","content":user_prompt}]}
        async with httpx.AsyncClient(timeout=120) as client:
            r=await client.post(base+"/chat/completions",headers={"Authorization":f"Bearer {key}"},json=payload)
        if r.status_code>=400: raise RuntimeError("OpenAI provider error: "+r.text[:400])
        obj=r.json(); reply=obj["choices"][0]["message"].get("content","") or ""
        usage=obj.get("usage",{})
        return reply,{"prompt_tokens":int(usage.get("prompt_tokens",0) or 0),"completion_tokens":int(usage.get("completion_tokens",0) or 0)}
    if provider=="ollama":
        base=os.getenv("NCK_OLLAMA_URL","").strip().rstrip("/"); model=model or os.getenv("OLLAMA_MODEL","llama3.1")
        if not base: raise RuntimeError("NCK_OLLAMA_URL belum dikonfigurasi pada environment backend.")
        payload={"model":model,"stream":False,"messages":[{"role":"system","content":system_prompt},{"role":"user","content":user_prompt}]}
        async with httpx.AsyncClient(timeout=300) as client:
            r=await client.post(base+"/api/chat",json=payload)
        if r.status_code>=400: raise RuntimeError("Ollama provider error: "+r.text[:400])
        obj=r.json(); reply=(obj.get("message") or {}).get("content","") or ""
        return reply,{"prompt_tokens":int(obj.get("prompt_eval_count",0) or 0),"completion_tokens":int(obj.get("eval_count",0) or 0)}
    key=os.getenv("GEMINI_API_KEY",""); model=model or os.getenv("GEMINI_MODEL","gemini-2.5-flash")
    if not key: raise RuntimeError("GEMINI_API_KEY belum dikonfigurasi pada environment backend.")
    payload={"system_instruction":{"parts":[{"text":system_prompt}]},"contents":[{"parts":[{"text":user_prompt}]}]}
    async with httpx.AsyncClient(timeout=120) as client:
        r=await client.post(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",params={"key":key},json=payload)
    if r.status_code>=400: raise RuntimeError("Gemini provider error: "+r.text[:400])
    obj=r.json(); reply="".join(p.get("text","") for p in obj.get("candidates",[{}])[0].get("content",{}).get("parts",[]))
    usage=obj.get("usageMetadata",{})
    return reply,{"prompt_tokens":int(usage.get("promptTokenCount",0) or 0),"completion_tokens":int(usage.get("candidatesTokenCount",0) or 0)}


def record_usage_v21(wid,key,agent,provider,call_type,prompt,reply,usage):
    with conn() as c:
        c.execute("INSERT INTO ai_usage_v21(workflow_id,step_key,agent_id,provider,call_type,prompt_chars,completion_chars,prompt_tokens,completion_tokens,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
          (wid,key,agent,provider,call_type,len(prompt),len(reply),usage.get("prompt_tokens",0),usage.get("completion_tokens",0),now()))
        c.execute("UPDATE workflow_steps SET prompt_tokens=COALESCE(prompt_tokens,0)+?,completion_tokens=COALESCE(completion_tokens,0)+? WHERE workflow_id=? AND step_key=?",
          (usage.get("prompt_tokens",0),usage.get("completion_tokens",0),wid,key))

async def execute_step_v21(wid,w,step,outputs,semaphore):
    agent=AGENT_BY_ID_V21.get(step["agent_id"])
    if not agent: return {"key":step["step_key"],"ok":False,"error":"Agen tidak ditemukan atau belum dikonfigurasi."}
    dep_context="\n\n".join([f"HASIL {k}:\n{outputs.get(k,'')}" for k in json.loads(step["depends_on"] or "[]")])
    system=agent["system"]+" Anda bekerja sebagai bagian dari tim multi-agent. Jangan mengarang fakta; tandai asumsi dan keterbatasan. Berikan hasil yang dapat diteruskan kepada agen lain."
    user=(f"TUJUAN WORKFLOW:\n{w['instruction']}\n\nTUGAS ANDA ({step['step_key']}):\n{step['instruction']}\n\nKONTEKS DARI LANGKAH DEPENDENSI:\n{dep_context or 'Tidak ada dependensi.'}\n\nBerikan hasil konkret, terstruktur, dan langsung menjawab tugas.")
    max_retries=int(w["retries"])
    async with semaphore:
        for attempt in range(max_retries+1):
            with conn() as c:c.execute("UPDATE workflow_steps SET status='running',attempts=?,error=NULL WHERE id=?",(attempt+1,step["id"]))
            try:
                reply,usage=await llm_call_v21(w["provider"],system,user)
                record_usage_v21(wid,step["step_key"],step["agent_id"],w["provider"],"agent",user,reply,usage)
                score=None; feedback="Review dinonaktifkan."; review_status="skipped"
                if w["review_enabled"]:
                    review_prompt=("Nilai hasil kerja agen berikut. Berikan JSON valid saja dengan format {\"score\":0-100,\"feedback\":\"...\"}. Nilai akurasi, kelengkapan, relevansi, dan keterlaksanaan.\n\nTUGAS:\n"+step["instruction"]+"\n\nHASIL:\n"+reply[:12000])
                    reviewer_system="Anda adalah reviewer AI independen yang kritis, adil, dan berbasis bukti. Jangan memberi nilai tinggi tanpa alasan."
                    review_text,review_usage=await llm_call_v21(w["provider"],reviewer_system,review_prompt)
                    record_usage_v21(wid,step["step_key"],"ai_reviewer",w["provider"],"reviewer",review_prompt,review_text,review_usage)
                    match=_re.search(r"\{.*\}",review_text,_re.S)
                    if not match: raise RuntimeError("Reviewer tidak mengembalikan JSON penilaian yang valid.")
                    review=json.loads(match.group(0)); score=max(0,min(100,int(review.get("score",0)))); feedback=str(review.get("feedback", ""))[:2000]; review_status="passed" if score>=int(w["review_threshold"]) else "needs_revision"
                if score is not None and score<int(w["review_threshold"]):
                    with conn() as c:c.execute("UPDATE workflow_steps SET review_status=?,review_score=?,review_feedback=?,result=? WHERE id=?",(review_status,score,feedback,reply,step["id"]))
                    if attempt<max_retries:
                        user += "\n\nREVISI WAJIB BERDASARKAN REVIEW (nilai "+str(score)+"; target minimal "+str(w["review_threshold"])+"): "+feedback+"\nPerbaiki hasil sebelumnya:\n"+reply[:9000]
                        await asyncio.sleep(min(2**attempt,4)); continue
                    raise RuntimeError(f"Hasil tidak lolos review AI: {score}/100. {feedback}")
                with conn() as c:c.execute("UPDATE workflow_steps SET status='completed',result=?,error=NULL,review_status=?,review_score=?,review_feedback=? WHERE id=?",(reply,review_status,score,feedback,step["id"]))
                return {"key":step["step_key"],"ok":True,"result":reply,"score":score}
            except Exception as exc:
                with conn() as c:c.execute("UPDATE workflow_steps SET error=?,review_status=CASE WHEN review_status IS NULL THEN 'error' ELSE review_status END WHERE id=?",(str(exc)[:1800],step["id"]))
                if attempt<max_retries: await asyncio.sleep(min(2**attempt,4)); continue
                with conn() as c:c.execute("UPDATE workflow_steps SET status='failed' WHERE id=?",(step["id"],))
                return {"key":step["step_key"],"ok":False,"error":str(exc)[:1800]}

async def execute_workflow_v21(wid):
    with conn() as c:
        wrow=c.execute("SELECT * FROM workflows WHERE id=?",(wid,)).fetchone()
        rows=c.execute("SELECT * FROM workflow_steps WHERE workflow_id=? ORDER BY position",(wid,)).fetchall()
    if not wrow:return
    w=dict(wrow); steps=[dict(x) for x in rows]
    w["provider"]=w.get("provider_v21") or "openai"
    w["review_enabled"]=bool(w.get("review_enabled_v21",1))
    w["review_threshold"]=int(w.get("review_threshold_v21") or 75)
    w["parallel_enabled"]=bool(w.get("parallel_enabled_v21",1))
    with conn() as c:c.execute("UPDATE workflows SET status='running',started_at=? WHERE id=?",(now(),wid))
    outputs={}; remaining={x["step_key"]:x for x in steps}; failed=False; semaphore=asyncio.Semaphore(4)
    while remaining:
        ready=[x for x in remaining.values() if all(dep in outputs for dep in json.loads(x["depends_on"] or "[]"))]
        if not ready:
            failed=True
            for x in remaining.values():
                with conn() as c:c.execute("UPDATE workflow_steps SET status='blocked',error='Dependensi gagal atau graph tidak dapat dilanjutkan.' WHERE id=?",(x["id"],))
            break
        if w.get("parallel_enabled",1):
            results=await asyncio.gather(*(execute_step_v21(wid,w,x,outputs,semaphore) for x in ready))
        else:
            results=[]
            for x in ready: results.append(await execute_step_v21(wid,w,x,outputs,semaphore))
        for result in results:
            remaining.pop(result["key"],None)
            if result["ok"]: outputs[result["key"]]=result["result"]
            else: failed=True
        if failed:
            # Do not execute dependent work after any failed branch; independent steps already in this batch finish.
            for x in remaining.values():
                with conn() as c:c.execute("UPDATE workflow_steps SET status='blocked',error='Diblokir karena langkah lain gagal.' WHERE id=?",(x["id"],))
            break
    final="failed" if failed else "completed"
    with conn() as c:c.execute("UPDATE workflows SET status=?,finished_at=? WHERE id=?",(final,now(),wid))
    audit("system","workflow.v21.finish",f"id={wid}; status={final}; completed={len(outputs)}/{len(steps)}")

@app.get("/api/v21/status")
def v21_status(role=Depends(auth)):
    return {"service":SERVICE,"version":"21.0.0","engine":"real_multi_agent","providers":{"openai":bool(os.getenv("OPENAI_API_KEY")),"gemini":bool(os.getenv("GEMINI_API_KEY"))},"agents_configured":len(AGENTS_V21),"parallel_limit":4}

@app.get("/api/v21/agents")
def v21_agents(role=Depends(auth)):
    return {"items":[{k:v for k,v in a.items() if k!="system"} for a in AGENTS_V21]}

@app.post("/api/v21/workflows")
def v21_create(data:Workflow21In,role=Depends(require_operator)):
    keys=[x.key.strip() for x in data.steps]
    if len(set(keys))!=len(keys): raise HTTPException(422,"Setiap step key harus unik.")
    known=set(keys)
    for step in data.steps:
        if step.agent_id not in AGENT_BY_ID_V21: raise HTTPException(422,f"Agen belum tersedia: {step.agent_id}")
        if any(dep not in known or dep==step.key for dep in step.depends_on): raise HTTPException(422,f"Dependensi tidak valid pada langkah {step.key}.")
    # Reject cyclic dependency graphs before storing.
    graph={x.key:x.depends_on for x in data.steps}; visited=set(); active=set()
    def visit(k):
        if k in active: raise HTTPException(422,"Dependensi workflow membentuk siklus.")
        if k in visited:return
        active.add(k)
        for dep in graph[k]:visit(dep)
        active.remove(k);visited.add(k)
    for k in graph:visit(k)
    wid="WF21-"+secrets.token_hex(6).upper()
    with conn() as c:
        c.execute("INSERT INTO workflows(id,name,instruction,status,retries,created_at) VALUES(?,?,?,?,?,?)",(wid,data.name.strip(),data.instruction.strip(),"pending_approval",data.retries,now()))
        for i,step in enumerate(data.steps,1):
            c.execute("""INSERT INTO workflow_steps(workflow_id,position,title,status,step_key,instruction,agent_id,depends_on,provider)
                VALUES(?,?,?,'queued',?,?,?,?,?)""",(wid,i,step.title.strip(),step.key.strip(),step.instruction.strip(),step.agent_id,json.dumps(step.depends_on),data.provider))
        # Workflow-level settings stored in audit metadata table for backward compatibility.
        c.execute("CREATE TABLE IF NOT EXISTS workflow_v21_config(workflow_id TEXT PRIMARY KEY,provider TEXT,review_enabled INTEGER,review_threshold INTEGER,parallel_enabled INTEGER)")
        c.execute("INSERT INTO workflow_v21_config VALUES(?,?,?,?,?)",(wid,data.provider,int(data.review_enabled),data.review_threshold,int(data.parallel_enabled)))
    audit(role,"workflow.v21.create",f"id={wid}; steps={len(data.steps)}; provider={data.provider}")
    return {"id":wid,"status":"pending_approval","steps":len(data.steps),"provider":data.provider}

@app.get("/api/v21/workflows")
def v21_list(status:Optional[str]=None,role=Depends(auth)):
    with conn() as c:
        if status: rows=c.execute("SELECT w.*,COUNT(s.id) steps FROM workflows w LEFT JOIN workflow_steps s ON s.workflow_id=w.id WHERE w.status=? AND w.id LIKE 'WF21-%' GROUP BY w.id ORDER BY w.created_at DESC LIMIT 100",(status,)).fetchall()
        else: rows=c.execute("SELECT w.*,COUNT(s.id) steps FROM workflows w LEFT JOIN workflow_steps s ON s.workflow_id=w.id WHERE w.id LIKE 'WF21-%' GROUP BY w.id ORDER BY w.created_at DESC LIMIT 100").fetchall()
    return {"items":[dict(x) for x in rows]}

@app.post("/api/v21/workflows/{wid}/approve")
def v21_approve(wid:str,background_tasks:BackgroundTasks,role=Depends(require_operator)):
    with conn() as c:
        w=c.execute("SELECT status FROM workflows WHERE id=? AND id LIKE 'WF21-%'",(wid,)).fetchone()
        if not w:raise HTTPException(404,"Workflow Tahap 21 tidak ditemukan.")
        if w["status"]!="pending_approval":raise HTTPException(409,"Workflow tidak sedang menunggu persetujuan.")
        c.execute("UPDATE workflows SET status='queued' WHERE id=?",(wid,))
        cfg=c.execute("SELECT * FROM workflow_v21_config WHERE workflow_id=?",(wid,)).fetchone()
    audit(role,"workflow.v21.approve",wid)
    # Attach config to the workflow row at execution time via a small wrapper.
    background_tasks.add_task(run_v21_with_config,wid,dict(cfg) if cfg else {})
    return {"id":wid,"status":"queued"}

async def run_v21_with_config(wid,cfg):
    with conn() as c:
        c.execute("UPDATE workflows SET provider_v21=?,review_enabled_v21=?,review_threshold_v21=?,parallel_enabled_v21=? WHERE id=?",(cfg.get("provider","openai"),cfg.get("review_enabled",1),cfg.get("review_threshold",75),cfg.get("parallel_enabled",1),wid))
    # execute_workflow_v21 reads the v21 settings from the workflow row.
    await execute_workflow_v21(wid)

@app.get("/api/v21/workflows/{wid}")
def v21_get(wid:str,role=Depends(auth)):
    with conn() as c:
        w=c.execute("SELECT * FROM workflows WHERE id=? AND id LIKE 'WF21-%'",(wid,)).fetchone()
        if not w:raise HTTPException(404,"Workflow tidak ditemukan.")
        steps=c.execute("SELECT * FROM workflow_steps WHERE workflow_id=? ORDER BY position",(wid,)).fetchall()
        cfg=c.execute("SELECT * FROM workflow_v21_config WHERE workflow_id=?",(wid,)).fetchone()
    return {**dict(w),"config":dict(cfg) if cfg else {},"steps":[dict(x) for x in steps]}

@app.get("/api/v21/usage")
def v21_usage(role=Depends(auth)):
    with conn() as c:
        total=c.execute("SELECT COUNT(*) calls,COALESCE(SUM(prompt_tokens),0) prompt_tokens,COALESCE(SUM(completion_tokens),0) completion_tokens,COALESCE(SUM(prompt_chars),0) prompt_chars,COALESCE(SUM(completion_chars),0) completion_chars FROM ai_usage_v21").fetchone()
        rows=c.execute("SELECT provider,agent_id,call_type,COUNT(*) calls,COALESCE(SUM(prompt_tokens),0) prompt_tokens,COALESCE(SUM(completion_tokens),0) completion_tokens FROM ai_usage_v21 GROUP BY provider,agent_id,call_type ORDER BY calls DESC LIMIT 50").fetchall()
        recent=c.execute("SELECT workflow_id,step_key,agent_id,provider,call_type,prompt_tokens,completion_tokens,created_at FROM ai_usage_v21 ORDER BY id DESC LIMIT 30").fetchall()
    return {"total":dict(total),"by_agent":[dict(x) for x in rows],"recent":[dict(x) for x in recent]}


# ===== TAHAP 22 — PERSISTENT AGENT INTELLIGENCE & COLLABORATION =====
from pydantic import BaseModel, Field

class Project22In(BaseModel):
    name:str=Field(min_length=2,max_length=120)
    description:str=Field(default="",max_length=4000)

class Knowledge22In(BaseModel):
    project:str=Field(min_length=1,max_length=120)
    title:str=Field(min_length=2,max_length=200)
    content:str=Field(min_length=1,max_length=20000)
    tags:str=Field(default="",max_length=500)

class AgentMemory22In(BaseModel):
    project:str=Field(min_length=1,max_length=120)
    agent_id:str=Field(min_length=1,max_length=80)
    content:str=Field(min_length=1,max_length=12000)
    memory_type:str=Field(default="experience",max_length=40)

class Message22In(BaseModel):
    project:str=Field(min_length=1,max_length=120)
    from_agent:str=Field(min_length=1,max_length=80)
    to_agent:str=Field(min_length=1,max_length=80)
    subject:str=Field(min_length=1,max_length=200)
    message:str=Field(min_length=1,max_length=12000)
    task_id:Optional[int]=None

class Task22In(BaseModel):
    project:str=Field(min_length=1,max_length=120)
    title:str=Field(min_length=2,max_length=200)
    instruction:str=Field(min_length=1,max_length=10000)
    agent_id:str=Field(min_length=1,max_length=80)
    priority:str=Field(default="normal",pattern="^(low|normal|high|urgent)$")

class TaskStatus22In(BaseModel):
    status:str=Field(pattern="^(open|assigned|in_progress|blocked|completed|cancelled)$")
    result:str=Field(default="",max_length=16000)

class Supervisor22In(BaseModel):
    project:str=Field(min_length=1,max_length=120)
    title:str=Field(min_length=2,max_length=200)
    content:str=Field(min_length=1,max_length=16000)
    provider:str=Field(default="openai",pattern="^(openai|gemini)$")
    threshold:int=Field(default=75,ge=50,le=100)


def init_v22():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS projects_v22(
          id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, description TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS knowledge_v22(
          id INTEGER PRIMARY KEY, project TEXT NOT NULL, title TEXT NOT NULL, content TEXT NOT NULL,
          tags TEXT NOT NULL DEFAULT '', created_by TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS agent_memory_v22(
          id INTEGER PRIMARY KEY, project TEXT NOT NULL, agent_id TEXT NOT NULL, memory_type TEXT NOT NULL,
          content TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS agent_messages_v22(
          id INTEGER PRIMARY KEY, project TEXT NOT NULL, from_agent TEXT NOT NULL, to_agent TEXT NOT NULL,
          subject TEXT NOT NULL, message TEXT NOT NULL, task_id INTEGER, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS tasks_v22(
          id INTEGER PRIMARY KEY, project TEXT NOT NULL, title TEXT NOT NULL, instruction TEXT NOT NULL,
          agent_id TEXT NOT NULL, priority TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'assigned',
          result TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS supervisor_v22(
          id INTEGER PRIMARY KEY, project TEXT NOT NULL, title TEXT NOT NULL, provider TEXT NOT NULL,
          score INTEGER NOT NULL, decision TEXT NOT NULL, feedback TEXT NOT NULL, created_at TEXT NOT NULL);
        """)

@app.on_event("startup")
def startup_v22(): init_v22()


def _agent22(agent_id):
    if agent_id not in AGENT_BY_ID_V21: raise HTTPException(422,"ID agen belum terdaftar pada direktori resmi.")
    return AGENT_BY_ID_V21[agent_id]

def _project22(name, description=""):
    name=name.strip()
    with conn() as c:
        row=c.execute("SELECT id FROM projects_v22 WHERE name=?",(name,)).fetchone()
        if row: return row["id"]
        cur=c.execute("INSERT INTO projects_v22(name,description,created_at) VALUES(?,?,?)",(name,description,now()))
        return cur.lastrowid

@app.get("/api/v22/status")
def v22_status(role=Depends(auth)):
    with conn() as c:
        counts={t:c.execute(f"SELECT COUNT(*) n FROM {t}").fetchone()["n"] for t in ("projects_v22","knowledge_v22","agent_memory_v22","agent_messages_v22","tasks_v22","supervisor_v22")}
    return {"version":"22.0.0","service":SERVICE,"modules":counts,"agents_available":len(AGENTS_V21),"providers":{"openai":bool(os.getenv("OPENAI_API_KEY")),"gemini":bool(os.getenv("GEMINI_API_KEY"))}}

@app.get("/api/v22/projects")
def v22_projects(role=Depends(auth)):
    with conn() as c: rows=c.execute("SELECT p.*, (SELECT COUNT(*) FROM knowledge_v22 k WHERE k.project=p.name) knowledge_count, (SELECT COUNT(*) FROM tasks_v22 t WHERE t.project=p.name) task_count FROM projects_v22 p ORDER BY p.created_at DESC LIMIT 100").fetchall()
    return {"items":[dict(x) for x in rows]}

@app.post("/api/v22/projects")
def v22_project_create(data:Project22In,role=Depends(require_operator)):
    try:
        with conn() as c: cur=c.execute("INSERT INTO projects_v22(name,description,created_at) VALUES(?,?,?)",(data.name.strip(),data.description.strip(),now()))
    except nck_db.INTEGRITY_ERRORS: raise HTTPException(409,"Nama proyek sudah tersedia.")
    audit(role,"v22.project.create",data.name)
    return {"id":cur.lastrowid,"name":data.name.strip(),"status":"created"}

@app.post("/api/v22/knowledge")
def v22_knowledge_add(data:Knowledge22In,role=Depends(require_operator)):
    _project22(data.project)
    with conn() as c: cur=c.execute("INSERT INTO knowledge_v22(project,title,content,tags,created_by,created_at) VALUES(?,?,?,?,?,?)",(data.project.strip(),data.title.strip(),data.content.strip(),data.tags.strip(),role,now()))
    audit(role,"v22.knowledge.add",f"id={cur.lastrowid}; project={data.project}")
    return {"id":cur.lastrowid,"status":"stored"}

@app.get("/api/v22/knowledge")
def v22_knowledge_list(project:Optional[str]=None,q:Optional[str]=None,role=Depends(auth)):
    sql="SELECT id,project,title,content,tags,created_by,created_at FROM knowledge_v22 WHERE 1=1"; args=[]
    if project: sql+=" AND project=?"; args.append(project)
    if q:
        like="%"+q[:120]+"%"; sql+=" AND (title LIKE ? OR content LIKE ? OR tags LIKE ?)"; args.extend([like,like,like])
    sql+=" ORDER BY id DESC LIMIT 100"
    with conn() as c: rows=c.execute(sql,args).fetchall()
    return {"items":[dict(x) for x in rows]}

@app.post("/api/v22/memory")
def v22_memory_add(data:AgentMemory22In,role=Depends(require_operator)):
    _agent22(data.agent_id); _project22(data.project)
    with conn() as c: cur=c.execute("INSERT INTO agent_memory_v22(project,agent_id,memory_type,content,created_at) VALUES(?,?,?,?,?)",(data.project.strip(),data.agent_id,data.memory_type.strip(),data.content.strip(),now()))
    audit(role,"v22.agent.memory",f"id={cur.lastrowid}; agent={data.agent_id}")
    return {"id":cur.lastrowid,"status":"stored"}

@app.get("/api/v22/memory")
def v22_memory_list(project:Optional[str]=None,agent_id:Optional[str]=None,q:Optional[str]=None,role=Depends(auth)):
    sql="SELECT * FROM agent_memory_v22 WHERE 1=1"; args=[]
    if project: sql+=" AND project=?"; args.append(project)
    if agent_id: _agent22(agent_id); sql+=" AND agent_id=?"; args.append(agent_id)
    if q: sql+=" AND content LIKE ?"; args.append("%"+q[:120]+"%")
    sql+=" ORDER BY id DESC LIMIT 100"
    with conn() as c: rows=c.execute(sql,args).fetchall()
    return {"items":[dict(x) for x in rows]}

@app.post("/api/v22/messages")
def v22_message_send(data:Message22In,role=Depends(require_operator)):
    _agent22(data.from_agent); _agent22(data.to_agent); _project22(data.project)
    with conn() as c: cur=c.execute("INSERT INTO agent_messages_v22(project,from_agent,to_agent,subject,message,task_id,created_at) VALUES(?,?,?,?,?,?,?)",(data.project.strip(),data.from_agent,data.to_agent,data.subject.strip(),data.message.strip(),data.task_id,now()))
    audit(role,"v22.agent.message.send",f"id={cur.lastrowid}; {data.from_agent}->{data.to_agent}")
    return {"id":cur.lastrowid,"status":"sent"}

@app.get("/api/v22/messages")
def v22_messages(project:Optional[str]=None,agent_id:Optional[str]=None,role=Depends(auth)):
    sql="SELECT * FROM agent_messages_v22 WHERE 1=1"; args=[]
    if project: sql+=" AND project=?"; args.append(project)
    if agent_id:
        _agent22(agent_id); sql+=" AND (from_agent=? OR to_agent=?)"; args.extend([agent_id,agent_id])
    sql+=" ORDER BY id DESC LIMIT 100"
    with conn() as c: rows=c.execute(sql,args).fetchall()
    return {"items":[dict(x) for x in rows]}

@app.post("/api/v22/tasks")
def v22_task_create(data:Task22In,role=Depends(require_operator)):
    _agent22(data.agent_id); _project22(data.project)
    with conn() as c: cur=c.execute("INSERT INTO tasks_v22(project,title,instruction,agent_id,priority,status,created_at,updated_at) VALUES(?,?,?,?,?,'assigned',?,?)",(data.project.strip(),data.title.strip(),data.instruction.strip(),data.agent_id,data.priority,now(),now()))
    audit(role,"v22.task.assign",f"id={cur.lastrowid}; agent={data.agent_id}; priority={data.priority}")
    return {"id":cur.lastrowid,"status":"assigned"}

@app.get("/api/v22/tasks")
def v22_tasks(project:Optional[str]=None,status:Optional[str]=None,agent_id:Optional[str]=None,role=Depends(auth)):
    sql="SELECT * FROM tasks_v22 WHERE 1=1"; args=[]
    if project: sql+=" AND project=?"; args.append(project)
    if status: sql+=" AND status=?"; args.append(status)
    if agent_id: _agent22(agent_id); sql+=" AND agent_id=?"; args.append(agent_id)
    sql+=" ORDER BY CASE priority WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 WHEN 'normal' THEN 2 ELSE 3 END,id DESC LIMIT 150"
    with conn() as c: rows=c.execute(sql,args).fetchall()
    return {"items":[dict(x) for x in rows]}

@app.post("/api/v22/tasks/{task_id}/status")
def v22_task_status(task_id:int,data:TaskStatus22In,role=Depends(require_operator)):
    with conn() as c:
        row=c.execute("SELECT id FROM tasks_v22 WHERE id=?",(task_id,)).fetchone()
        if not row: raise HTTPException(404,"Task tidak ditemukan.")
        c.execute("UPDATE tasks_v22 SET status=?,result=?,updated_at=? WHERE id=?",(data.status,data.result.strip(),now(),task_id))
    audit(role,"v22.task.status",f"id={task_id}; status={data.status}")
    return {"id":task_id,"status":data.status}

@app.post("/api/v22/supervisor/review")
async def v22_supervisor_review(data:Supervisor22In,role=Depends(require_operator)):
    _project22(data.project)
    prompt=("Anda adalah AI Supervisor independen. Evaluasi hasil kerja berikut secara kritis. "
      "Nilai akurasi internal, kelengkapan, konsistensi instruksi, risiko, dan keterlaksanaan. "
      "Kembalikan HANYA JSON valid: {score: integer 0-100, decision: 'approve'|'revise'|'reject', feedback: string, risks: [string]}. "
      f"Judul: {data.title}\nTarget skor persetujuan: {data.threshold}/100\nHasil kerja:\n{data.content}")
    try:
        reply,usage=await llm_call_v21(data.provider,"Anda adalah auditor kualitas dan keselamatan hasil kerja AI.",prompt)
        match=_re.search(r"\{[\s\S]*\}",reply)
        if not match: raise ValueError("Respons supervisor bukan JSON yang dapat dibaca.")
        obj=json.loads(match.group(0)); score=max(0,min(100,int(obj.get("score",0))))
        decision=str(obj.get("decision","revise")).lower()
        if decision not in ("approve","revise","reject"): decision="revise"
        if score<data.threshold and decision=="approve": decision="revise"
        feedback=str(obj.get("feedback",""))[:5000]
        if obj.get("risks"): feedback += "\nRisiko: " + "; ".join(map(str,obj.get("risks",[])[:12]))
    except Exception as exc: raise HTTPException(502,"AI Supervisor gagal: "+str(exc)[:500])
    with conn() as c: cur=c.execute("INSERT INTO supervisor_v22(project,title,provider,score,decision,feedback,created_at) VALUES(?,?,?,?,?,?,?)",(data.project.strip(),data.title.strip(),data.provider,score,decision,feedback,now()))
    audit(role,"v22.supervisor.review",f"id={cur.lastrowid}; score={score}; decision={decision}")
    return {"id":cur.lastrowid,"score":score,"decision":decision,"feedback":feedback,"usage":usage}

@app.get("/api/v22/supervisor/history")
def v22_supervisor_history(project:Optional[str]=None,role=Depends(auth)):
    sql="SELECT * FROM supervisor_v22"; args=[]
    if project: sql+=" WHERE project=?"; args.append(project)
    sql+=" ORDER BY id DESC LIMIT 100"
    with conn() as c: rows=c.execute(sql,args).fetchall()
    return {"items":[dict(x) for x in rows]}


# ===== Tahap 23: Autonomous Agent Operations & Persistent Queue =====
class ExecuteTask23In(BaseModel):
    provider:str=Field(default="openai",pattern="^(openai|gemini)$")
    max_retries:int=Field(default=2,ge=0,le=3)
    review_enabled:bool=True
    review_threshold:int=Field(default=75,ge=50,le=100)

class Dispatch23In(BaseModel):
    provider:str=Field(default="openai",pattern="^(openai|gemini)$")
    max_retries:int=Field(default=2,ge=0,le=3)
    review_enabled:bool=True
    review_threshold:int=Field(default=75,ge=50,le=100)
    limit:int=Field(default=5,ge=1,le=10)


def init_v23():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS task_runs_v23(
          id INTEGER PRIMARY KEY, task_id INTEGER NOT NULL UNIQUE, status TEXT NOT NULL DEFAULT 'queued',
          provider TEXT NOT NULL, max_retries INTEGER NOT NULL DEFAULT 2, review_enabled INTEGER NOT NULL DEFAULT 1,
          review_threshold INTEGER NOT NULL DEFAULT 75, attempt INTEGER NOT NULL DEFAULT 0,
          output TEXT NOT NULL DEFAULT '', review_score INTEGER, review_feedback TEXT NOT NULL DEFAULT '',
          error TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, started_at TEXT, finished_at TEXT,
          FOREIGN KEY(task_id) REFERENCES tasks_v22(id));
        CREATE TABLE IF NOT EXISTS task_events_v23(
          id INTEGER PRIMARY KEY, task_id INTEGER NOT NULL, event TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_task_runs_v23_status ON task_runs_v23(status,created_at);
        CREATE INDEX IF NOT EXISTS idx_task_events_v23_task ON task_events_v23(task_id,id);
        """)
        # Tahap 34: run 'running' TIDAK lagi direset buta saat startup (itu membuat tugas milik worker lain yang masih hidup
        # dijalankan dua kali pada deployment multi-proses). Pemulihan kini berbasis heartbeat: recover_orphans34().

@app.on_event("startup")
def startup_v23(): init_v23()


def _event23(task_id,event,detail=''):
    with conn() as c:
        c.execute("INSERT INTO task_events_v23(task_id,event,detail,created_at) VALUES(?,?,?,?)",(task_id,event,str(detail)[:3000],now()))


def _context23(project,agent_id):
    with conn() as c:
        knowledge=c.execute("SELECT title,content,tags FROM knowledge_v22 WHERE project=? ORDER BY id DESC LIMIT 8",(project,)).fetchall()
        memories=c.execute("SELECT memory_type,content FROM agent_memory_v22 WHERE project=? AND agent_id=? ORDER BY id DESC LIMIT 8",(project,agent_id)).fetchall()
        messages=c.execute("SELECT from_agent,to_agent,subject,message FROM agent_messages_v22 WHERE project=? AND (from_agent=? OR to_agent=?) ORDER BY id DESC LIMIT 6",(project,agent_id,agent_id)).fetchall()
    def pack(rows,fn,cap): return "\n\n".join(fn(dict(r)) for r in rows)[:cap]
    k=pack(knowledge,lambda x:f"[{x['title']}] ({x['tags']})\n{x['content']}",10000)
    m=pack(memories,lambda x:f"[{x['memory_type']}] {x['content']}",7000)
    msg=pack(messages,lambda x:f"{x['from_agent']} -> {x['to_agent']} | {x['subject']}\n{x['message']}",5000)
    return k or 'Belum ada knowledge proyek.',m or 'Belum ada memori khusus agen.',msg or 'Belum ada komunikasi terdahulu.'


# ===== TAHAP 26 — GOVERNANCE ENFORCEMENT & COMMAND CENTER =====
def _policies26(project,agent_id):
    with conn() as c:
        rows=c.execute("""SELECT id,name,scope,project,agent_id,rule,severity
          FROM governance_policies_v25 WHERE active=1 AND
          (scope='global' OR (scope='project' AND project=?) OR (scope='agent' AND agent_id=?))
          ORDER BY CASE severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END,id""",(project,agent_id)).fetchall()
    return [dict(x) for x in rows]

def _alert26(alert_type,severity,title,detail,project=None,task_id=None,agent_id=None):
    with conn() as c:
        cur=c.execute("INSERT INTO command_alerts_v26(alert_type,severity,title,detail,project,task_id,agent_id,status,created_at) VALUES(?,?,?,?,?,?,?,'open',?)",
          (alert_type,severity,title,str(detail)[:5000],project,task_id,agent_id,now()))
        return cur.lastrowid


async def execute_task23(task_id:int):
    with conn() as c:
        run=c.execute("SELECT * FROM task_runs_v23 WHERE task_id=?",(task_id,)).fetchone()
        task=c.execute("SELECT * FROM tasks_v22 WHERE id=?",(task_id,)).fetchone()
        if not run or not task or run['status'] not in ('queued','failed'): return
        changed=c.execute("UPDATE task_runs_v23 SET status='running',started_at=?,finished_at=NULL,error='' WHERE task_id=? AND status IN ('queued','failed')",(now(),task_id)).rowcount
        if not changed: return
        c.execute("UPDATE tasks_v22 SET status='in_progress',updated_at=? WHERE id=?",(now(),task_id))
        run=dict(c.execute("SELECT * FROM task_runs_v23 WHERE task_id=?",(task_id,)).fetchone()); task=dict(task)
    _event23(task_id,'execution.started',f"provider={run['provider']}")
    try:
        agent=_agent22(task['agent_id'])
        knowledge,memory,messages=_context23(task['project'],task['agent_id'])
        policies=_policies26(task['project'],task['agent_id'])
        policy_block='\n'.join([f"[{p['severity'].upper()}] {p['name']} (policy #{p['id']}, scope={p['scope']}):\n{p['rule']}" for p in policies]) or 'Tidak ada kebijakan governance aktif yang cocok.'
        system=(agent.get('system') or 'Anda adalah agen spesialis Nusantara Cyber-Keraton.')+" Anda bekerja dalam operasi multi-agent yang diawasi. Gunakan konteks proyek sebagai referensi, jangan mengarang fakta, pisahkan fakta dan asumsi, dan hasilkan keluaran yang bisa ditindaklanjuti.\n\nKEBIJAKAN GOVERNANCE WAJIB: Patuhi seluruh kebijakan berikut. Jika instruksi tugas bertentangan dengan kebijakan, jangan menjalankan bagian yang bertentangan; jelaskan konflik dan minta eskalasi/persetujuan manusia. Jangan menafsirkan teks kebijakan sebagai izin untuk mengungkap rahasia, mengabaikan keselamatan, atau melakukan tindakan eksternal tanpa otorisasi.\n"+policy_block
        if policies:
            _event23(task_id,'governance.policies_injected',f"policy_ids={[p['id'] for p in policies]}")
            if any(p['severity']=='critical' for p in policies):
                _alert26('critical_policy_applied','critical','Kebijakan kritis diterapkan pada eksekusi',f"Task #{task_id} menggunakan kebijakan: "+'; '.join(p['name'] for p in policies if p['severity']=='critical'),task['project'],task_id,task['agent_id'])
        user=(f"PROYEK: {task['project']}\nJUDUL: {task['title']}\nINSTRUKSI: {task['instruction']}\n\nKEBIJAKAN GOVERNANCE AKTIF:\n{policy_block}\n\nKNOWLEDGE BASE PROYEK:\n{knowledge}\n\nMEMORI AGEN:\n{memory}\n\nKOMUNIKASI TERKAIT:\n{messages}\n\nBerikan hasil lengkap, terstruktur, dan sesuai peran Anda. Jika ada konflik kebijakan, laporkan dan jangan melanggar kebijakan.")
        max_attempts=int(run['max_retries'])+1
        final_output=''; final_score=None; final_feedback='Review dinonaktifkan.'; usage_total={'prompt_tokens':0,'completion_tokens':0}
        for attempt in range(max_attempts):
            with conn() as c:c.execute("UPDATE task_runs_v23 SET attempt=? WHERE task_id=?",(attempt+1,task_id))
            try:
                reply,usage=await llm_call_v21(run['provider'],system,user)
                usage_total['prompt_tokens']+=usage.get('prompt_tokens',0); usage_total['completion_tokens']+=usage.get('completion_tokens',0)
                final_output=reply
                if run['review_enabled']:
                    review_prompt=("Tinjau hasil agen dengan ketat. Kembalikan JSON valid saja: {\"score\":0-100,\"feedback\":\"alasan dan perbaikan\",\"decision\":\"approve\" atau \"revise\"}. Jangan mengasumsikan fakta yang tidak tersedia.\n\nTUGAS:\n"+task['instruction']+"\n\nHASIL:\n"+reply[:12000])
                    review_text,review_usage=await llm_call_v21(run['provider'],"Anda adalah AI Supervisor independen untuk quality assurance.",review_prompt)
                    usage_total['prompt_tokens']+=review_usage.get('prompt_tokens',0); usage_total['completion_tokens']+=review_usage.get('completion_tokens',0)
                    match=_re.search(r"\{[\s\S]*\}",review_text)
                    if not match: raise RuntimeError('Supervisor tidak mengembalikan JSON valid.')
                    obj=json.loads(match.group(0)); final_score=max(0,min(100,int(obj.get('score',0)))); final_feedback=str(obj.get('feedback',''))[:4000]
                    decision='approve' if final_score>=int(run['review_threshold']) else 'revise'
                    with conn() as c:
                        c.execute("INSERT INTO supervisor_v22(project,title,provider,score,decision,feedback,created_at) VALUES(?,?,?,?,?,?,?)",(task['project'],task['title'],run['provider'],final_score,decision,final_feedback,now()))
                    _event23(task_id,'supervisor.review',f"score={final_score}; decision={decision}; {final_feedback[:900]}")
                    if final_score<int(run['review_threshold']):
                        if attempt<max_attempts-1:
                            user += "\n\nPERBAIKI HASIL BERDASARKAN REVIEW SUPERVISOR (skor "+str(final_score)+", target "+str(run['review_threshold'])+"): "+final_feedback+"\nVersi sebelumnya:\n"+reply[:7000]
                            continue
                        raise RuntimeError(f"Tidak lolos quality gate: {final_score}/100. {final_feedback}")
                break
            except Exception as exc:
                if attempt>=max_attempts-1: raise
                user += "\n\nPERBAIKI/ULANGI SETELAH KENDALA: "+str(exc)[:1000]
                await asyncio.sleep(min(2**attempt,4))
        with conn() as c:
            # Tahap 34: hasil hanya dicatat bila eksekusi ini masih pemilik status 'running' (pekerja basi tidak menimpa hasil pekerja lain).
            done=c.execute("UPDATE task_runs_v23 SET status='completed',output=?,review_score=?,review_feedback=?,error='',finished_at=? WHERE task_id=? AND status='running'",(final_output,final_score,final_feedback,now(),task_id)).rowcount
            if done:
                c.execute("UPDATE tasks_v22 SET status='completed',result=?,updated_at=? WHERE id=?",(final_output,now(),task_id))
                c.execute("INSERT INTO agent_memory_v22(project,agent_id,memory_type,content,created_at) VALUES(?,?,?,?,?)",(task['project'],task['agent_id'],'execution_lesson',f"Tugas: {task['title']}\nHasil ringkas: {final_output[:5000]}",now()))
        if not done:
            _event23(task_id,'execution.result_discarded','Status tugas sudah berubah (diambil alih/diantrekan ulang); hasil eksekusi ini tidak dicatat.')
            return
        _event23(task_id,'execution.completed',f"review_score={final_score}; prompt_tokens={usage_total['prompt_tokens']}; completion_tokens={usage_total['completion_tokens']}")
        audit('system','v23.task.completed',f"task={task_id}; agent={task['agent_id']}")
    except Exception as exc:
        err=str(exc)[:3000]
        with conn() as c:
            failed=c.execute("UPDATE task_runs_v23 SET status='failed',error=?,finished_at=? WHERE task_id=? AND status='running'",(err,now(),task_id)).rowcount
            if failed: c.execute("UPDATE tasks_v22 SET status='blocked',result=?,updated_at=? WHERE id=?",(err,now(),task_id))
        if not failed:
            _event23(task_id,'execution.result_discarded','Kegagalan tidak dicatat: status tugas sudah berubah (diambil alih/diantrekan ulang).')
            return
        _event23(task_id,'execution.failed',err)
        _alert26('task_failure','high','Eksekusi agen gagal',err,task.get('project'),task_id,task.get('agent_id'))
        audit('system','v23.task.failed',f"task={task_id}; {err[:500]}")


@app.post('/api/v23/tasks/{task_id}/execute')
def v23_execute(task_id:int,data:ExecuteTask23In,background_tasks:BackgroundTasks,role=Depends(require_operator)):
    with conn() as c:
        task=c.execute("SELECT * FROM tasks_v22 WHERE id=?",(task_id,)).fetchone()
        if not task: raise HTTPException(404,'Task tidak ditemukan.')
        old=c.execute("SELECT * FROM task_runs_v23 WHERE task_id=?",(task_id,)).fetchone()
        if old and old['status'] in ('queued','running','completed'): raise HTTPException(409,f"Task sudah berada pada status operasi {old['status']}.")
        if old:
            c.execute("UPDATE task_runs_v23 SET status='queued',provider=?,max_retries=?,review_enabled=?,review_threshold=?,error='',created_at=?,attempt=0 WHERE task_id=?",(data.provider,data.max_retries,int(data.review_enabled),data.review_threshold,now(),task_id))
        else:
            c.execute("INSERT INTO task_runs_v23(task_id,status,provider,max_retries,review_enabled,review_threshold,created_at) VALUES(?,'queued',?,?,?,?,?)",(task_id,data.provider,data.max_retries,int(data.review_enabled),data.review_threshold,now()))
        c.execute("UPDATE tasks_v22 SET status='assigned',updated_at=? WHERE id=?",(now(),task_id))
    _event23(task_id,'queue.enqueued','Task masuk antrean eksekusi.')
    _wake_workers27()
    audit(role,'v23.task.enqueue',f"task={task_id}; provider={data.provider}")
    return {'task_id':task_id,'status':'queued','message':'Task masuk antrean dan worker lokal akan memprosesnya.'}


@app.post('/api/v23/queue/dispatch')
def v23_dispatch(data:Dispatch23In,background_tasks:BackgroundTasks,role=Depends(require_operator)):
    with conn() as c:
        rows=c.execute("SELECT t.id FROM tasks_v22 t LEFT JOIN task_runs_v23 r ON r.task_id=t.id WHERE (r.task_id IS NULL OR r.status IN ('failed','queued')) AND t.status IN ('assigned','open','blocked') ORDER BY CASE t.priority WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 WHEN 'normal' THEN 2 ELSE 3 END,t.id LIMIT ?",(data.limit,)).fetchall()
        ids=[int(x['id']) for x in rows]
        for tid in ids:
            c.execute("INSERT INTO task_runs_v23(task_id,status,provider,max_retries,review_enabled,review_threshold,created_at) VALUES(?,'queued',?,?,?,?,?) ON CONFLICT(task_id) DO UPDATE SET status='queued',provider=excluded.provider,max_retries=excluded.max_retries,review_enabled=excluded.review_enabled,review_threshold=excluded.review_threshold,error='',attempt=0,created_at=excluded.created_at",(tid,data.provider,data.max_retries,int(data.review_enabled),data.review_threshold,now()))
            c.execute("UPDATE tasks_v22 SET status='assigned',updated_at=? WHERE id=?",(now(),tid))
    for tid in ids:
        _event23(tid,'queue.dispatched','Task diproses melalui dispatch antrean.')
        pass
    _wake_workers27()
    audit(role,'v23.queue.dispatch',f"count={len(ids)}")
    return {'dispatched':len(ids),'task_ids':ids,'status':'queued'}


@app.get('/api/v23/operations')
def v23_operations(status:Optional[str]=None,role=Depends(auth)):
    sql="SELECT r.*,t.project,t.title,t.agent_id,t.priority FROM task_runs_v23 r JOIN tasks_v22 t ON t.id=r.task_id"; args=[]
    if status:
        if status not in ('queued','running','completed','failed'): raise HTTPException(422,'Filter status tidak valid.')
        sql+=' WHERE r.status=?'; args.append(status)
    sql+=' ORDER BY r.id DESC LIMIT 150'
    with conn() as c: rows=c.execute(sql,args).fetchall()
    return {'items':[dict(x) for x in rows]}


@app.get('/api/v23/tasks/{task_id}/execution')
def v23_execution(task_id:int,role=Depends(auth)):
    with conn() as c:
        run=c.execute("SELECT r.*,t.project,t.title,t.agent_id,t.priority FROM task_runs_v23 r JOIN tasks_v22 t ON t.id=r.task_id WHERE r.task_id=?",(task_id,)).fetchone()
        events=c.execute("SELECT event,detail,created_at FROM task_events_v23 WHERE task_id=? ORDER BY id",(task_id,)).fetchall()
    if not run: raise HTTPException(404,'Riwayat eksekusi task belum tersedia.')
    return {'execution':dict(run),'events':[dict(x) for x in events]}


@app.get('/api/v23/status')
def v23_status(role=Depends(auth)):
    with conn() as c:
        counts={x:c.execute('SELECT COUNT(*) n FROM task_runs_v23 WHERE status=?',(x,)).fetchone()['n'] for x in ('queued','running','completed','failed')}
    return {'version':'23.0.0','queue':counts,'worker':'persistent threaded queue worker pool (Tahap 27)','persistent_queue':True,'providers':{'openai':bool(os.getenv('OPENAI_API_KEY')),'gemini':bool(os.getenv('GEMINI_API_KEY'))}}


# ===== Tahap 24: Multi-Agent Intelligence Network & Autonomous Collaboration =====
class CollaborationStep24(BaseModel):
    title:str=Field(min_length=2,max_length=180)
    instruction:str=Field(min_length=5,max_length=8000)
    agent_id:str=Field(min_length=1,max_length=80)

class Collaboration24In(BaseModel):
    project:str=Field(min_length=2,max_length=160)
    goal:str=Field(min_length=5,max_length=8000)
    steps:list[CollaborationStep24]=Field(min_length=2,max_length=8)
    provider:Literal['openai','gemini']='openai'
    review_enabled:bool=True
    review_threshold:int=Field(default=75,ge=50,le=100)


def init_v24():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS collaborations_v24(
          id INTEGER PRIMARY KEY, project TEXT NOT NULL, goal TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'queued',
          provider TEXT NOT NULL, review_enabled INTEGER NOT NULL DEFAULT 1, review_threshold INTEGER NOT NULL DEFAULT 75,
          final_output TEXT NOT NULL DEFAULT '', conflict_report TEXT NOT NULL DEFAULT '', error TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL, started_at TEXT, finished_at TEXT);
        CREATE TABLE IF NOT EXISTS collaboration_steps_v24(
          id INTEGER PRIMARY KEY, collaboration_id INTEGER NOT NULL, sequence_no INTEGER NOT NULL,
          task_id INTEGER NOT NULL, agent_id TEXT NOT NULL, title TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'queued',
          handoff_summary TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL,
          FOREIGN KEY(collaboration_id) REFERENCES collaborations_v24(id), FOREIGN KEY(task_id) REFERENCES tasks_v22(id),
          UNIQUE(collaboration_id,sequence_no));
        CREATE INDEX IF NOT EXISTS idx_collab24_status ON collaborations_v24(status,created_at);
        CREATE INDEX IF NOT EXISTS idx_collab_steps24_run ON collaboration_steps_v24(collaboration_id,sequence_no);
        """)

@app.on_event('startup')
def startup_v24(): init_v24()


def _agent_suggest24(text_value:str):
    q=text_value.lower()
    rules=[
      ('ki_suradiraksa',['sutradara','video','adegan','scene','storyboard','produksi','film','director']),
      ('ki_mandra',['desain','grafis','brand','logo','identitas','visual','tipografi','poster']),
      ('ki_juru_tulis',['naskah','tulis','artikel','copywriting','cerita','storytelling','skrip','caption']),
      ('ki_sutedjo',['edit','editing','post production','transisi','audio','render','montage']),
      ('nyai_carita',['narasi','konten','voice over','promosi','sosial media','komunikasi']),
      ('ki_rupa',['ilustrasi','concept art','gambar','karakter','konsep visual','prompt gambar'])]
    scored=[]
    for aid,words in rules:
        score=sum(1 for w in words if w in q)
        scored.append((score,aid))
    scored.sort(reverse=True)
    return [{'agent_id':aid,'name':AGENT_BY_ID_V21[aid]['name'],'role':AGENT_BY_ID_V21[aid]['role'],'score':score} for score,aid in scored if score>0][:3]


@app.get('/api/v24/status')
def v24_status(role=Depends(auth)):
    with conn() as c:
        counts={st:c.execute('SELECT COUNT(*) n FROM collaborations_v24 WHERE status=?',(st,)).fetchone()['n'] for st in ('queued','running','completed','failed')}
        total=c.execute('SELECT COUNT(*) n FROM collaboration_steps_v24').fetchone()['n']
    return {'version':'24.0.0','collaborations':counts,'steps_recorded':total,'agents_registered':len(AGENTS_V21),'mode':'sequential_handoff','providers':{'openai':bool(os.getenv('OPENAI_API_KEY')),'gemini':bool(os.getenv('GEMINI_API_KEY'))}}

@app.post('/api/v24/agents/recommend')
def v24_recommend(data:dict,role=Depends(auth)):
    brief=str(data.get('brief','')).strip()
    if len(brief)<3: raise HTTPException(422,'Brief minimal 3 karakter.')
    return {'recommendations':_agent_suggest24(brief),'registered_agents':[{'id':a['id'],'name':a['name'],'role':a['role']} for a in AGENTS_V21]}

@app.post('/api/v24/collaborations')
def v24_create(data:Collaboration24In,background_tasks:BackgroundTasks,role=Depends(require_operator)):
    for step in data.steps: _agent22(step.agent_id)
    _project22(data.project)
    with conn() as c:
        cur=c.execute('INSERT INTO collaborations_v24(project,goal,status,provider,review_enabled,review_threshold,created_at) VALUES(?,?,\'queued\',?,?,?,?)',(data.project.strip(),data.goal.strip(),data.provider,int(data.review_enabled),data.review_threshold,now()))
        cid=cur.lastrowid
        for i,step in enumerate(data.steps,1):
            title=step.title.strip()
            instruction=f"TUJUAN KOLABORASI: {data.goal.strip()}\n\nTAHAP {i}/{len(data.steps)}: {title}\nINSTRUKSI: {step.instruction.strip()}"
            cur2=c.execute("INSERT INTO tasks_v22(project,title,instruction,agent_id,priority,status,created_at,updated_at) VALUES(?,?,?,?,?,'assigned',?,?)",(data.project.strip(),title,instruction,step.agent_id,'high' if i==1 else 'normal',now(),now()))
            c.execute('INSERT INTO collaboration_steps_v24(collaboration_id,sequence_no,task_id,agent_id,title,created_at) VALUES(?,?,?,?,?,?)',(cid,i,cur2.lastrowid,step.agent_id,title,now()))
    audit(role,'v24.collaboration.create',f'id={cid}; project={data.project}; steps={len(data.steps)}')
    background_tasks.add_task(run_collaboration24,cid)
    return {'id':cid,'status':'queued','steps':len(data.steps),'message':'Kolaborasi dibuat; agen akan bekerja berurutan dengan handoff hasil.'}


async def run_collaboration24(cid:int):
    with conn() as c:
        coll=c.execute('SELECT * FROM collaborations_v24 WHERE id=?',(cid,)).fetchone()
        steps=[dict(x) for x in c.execute('SELECT * FROM collaboration_steps_v24 WHERE collaboration_id=? ORDER BY sequence_no',(cid,)).fetchall()]
        if not coll or coll['status'] not in ('queued','failed'): return
        c.execute("UPDATE collaborations_v24 SET status='running',started_at=?,error='' WHERE id=?",(now(),cid))
    outputs=[]
    try:
        for step in steps:
            with conn() as c: c.execute("UPDATE collaboration_steps_v24 SET status='running' WHERE id=?",(step['id'],))
            task_id=step['task_id']
            if outputs:
                prior='\n\n'.join(f"HASIL TAHAP {x['sequence']}: {x['agent']}\n{x['output'][:10000]}" for x in outputs)
                handoff=("\n\nKONTEKS HANDOFF DARI AGEN SEBELUMNYA (gunakan sebagai masukan, verifikasi konsistensi, jangan mengulang tanpa nilai tambah):\n"+prior)
                with conn() as c:
                    c.execute('UPDATE tasks_v22 SET instruction=instruction||?,updated_at=? WHERE id=?',(handoff,now(),task_id))
                    prev=outputs[-1]
                    c.execute('INSERT INTO agent_messages_v22(project,from_agent,to_agent,subject,message,task_id,created_at) VALUES(?,?,?,?,?,?,?)',(coll['project'],prev['agent_id'],step['agent_id'],'Handoff kolaborasi #'+str(cid),prev['output'][:10000],task_id,now()))
            with conn() as c:
                c.execute("INSERT INTO task_runs_v23(task_id,status,provider,max_retries,review_enabled,review_threshold,created_at) VALUES(?,'queued',?,1,?,?,?) ON CONFLICT(task_id) DO UPDATE SET status='queued',provider=excluded.provider,max_retries=1,review_enabled=excluded.review_enabled,review_threshold=excluded.review_threshold,error='',attempt=0,created_at=excluded.created_at",(task_id,coll['provider'],coll['review_enabled'],coll['review_threshold'],now()))
            await execute_task23(task_id)
            with conn() as c:
                run=c.execute('SELECT status,output,error FROM task_runs_v23 WHERE task_id=?',(task_id,)).fetchone()
            if not run or run['status']!='completed': raise RuntimeError(f"Tahap {step['sequence_no']} gagal untuk agen {step['agent_id']}: {run['error'] if run else 'hasil tidak ditemukan'}")
            agent=AGENT_BY_ID_V21[step['agent_id']]
            outputs.append({'sequence':step['sequence_no'],'task_id':task_id,'agent_id':step['agent_id'],'agent':agent['name'],'output':run['output']})
            with conn() as c: c.execute("UPDATE collaboration_steps_v24 SET status='completed',handoff_summary=? WHERE id=?",(run['output'][:2500],step['id']))
        combined='\n\n'.join(f"TAHAP {x['sequence']} — {x['agent']}\n{x['output']}" for x in outputs)
        # Supervisor checks cross-agent consistency and flags contradictions without silently rewriting source outputs.
        conflict_report='Pemeriksaan konsistensi tidak diaktifkan.'
        final_output=combined
        if coll['review_enabled']:
            prompt=("""Bandingkan keluaran agen berikut untuk menemukan kontradiksi, duplikasi, asumsi yang tidak didukung, dan celah koordinasi. Jangan mengarang fakta. Kembalikan JSON valid dengan struktur: {"conflicts":[{"topic":"...","agents":["..."],"detail":"...","resolution":"..."}],"overall_assessment":"...","score":0-100}.

"""+combined[:26000])
            review,_=await llm_call_v21(coll['provider'],'Anda adalah AI Supervisor koordinasi lintas-agen.',prompt)
            m=_re.search(r'\{[\s\S]*\}',review)
            if not m: raise RuntimeError('Supervisor kolaborasi tidak mengembalikan JSON valid.')
            obj=json.loads(m.group(0)); conflict_report=json.dumps(obj,ensure_ascii=False,indent=2)[:12000]
            final_output=combined+'\n\nLAPORAN KONSISTENSI AI SUPERVISOR\n'+conflict_report
        with conn() as c: c.execute("UPDATE collaborations_v24 SET status='completed',final_output=?,conflict_report=?,finished_at=? WHERE id=?",(final_output,conflict_report,now(),cid))
        audit('system','v24.collaboration.completed',f'id={cid}; completed_steps={len(outputs)}')
    except Exception as exc:
        err=str(exc)[:3000]
        with conn() as c:
            c.execute("UPDATE collaborations_v24 SET status='failed',error=?,finished_at=? WHERE id=?",(err,now(),cid))
            c.execute("UPDATE collaboration_steps_v24 SET status='blocked' WHERE collaboration_id=? AND status IN ('queued','running')",(cid,))
        audit('system','v24.collaboration.failed',f'id={cid}; {err[:500]}')

@app.get('/api/v24/collaborations')
def v24_list(project:Optional[str]=None,role=Depends(auth)):
    with conn() as c:
        sql='SELECT * FROM collaborations_v24'; args=[]
        if project: sql+=' WHERE project=?'; args.append(project)
        sql+=' ORDER BY id DESC LIMIT 100'
        rows=[dict(x) for x in c.execute(sql,args).fetchall()]
        for x in rows: x['steps']=[dict(y) for y in c.execute('SELECT sequence_no,task_id,agent_id,title,status,handoff_summary FROM collaboration_steps_v24 WHERE collaboration_id=? ORDER BY sequence_no',(x['id'],)).fetchall()]
    return {'items':rows}

@app.get('/api/v24/collaborations/{cid}')
def v24_detail(cid:int,role=Depends(auth)):
    with conn() as c:
        row=c.execute('SELECT * FROM collaborations_v24 WHERE id=?',(cid,)).fetchone()
        steps=[dict(x) for x in c.execute('SELECT s.*,r.status run_status,r.output,r.review_score,r.error FROM collaboration_steps_v24 s LEFT JOIN task_runs_v23 r ON r.task_id=s.task_id WHERE s.collaboration_id=? ORDER BY s.sequence_no',(cid,)).fetchall()]
    if not row: raise HTTPException(404,'Kolaborasi tidak ditemukan.')
    return {'collaboration':dict(row),'steps':steps}


# ===== TAHAP 25 — ENTERPRISE AI GOVERNANCE & SELF-LEARNING INTELLIGENCE =====
class Policy25In(BaseModel):
    name:str=Field(min_length=3,max_length=160)
    scope:str=Field(default="global",pattern="^(global|project|agent)$")
    project:Optional[str]=Field(default=None,max_length=120)
    agent_id:Optional[str]=Field(default=None,max_length=80)
    rule:str=Field(min_length=5,max_length=8000)
    severity:str=Field(default="high",pattern="^(low|medium|high|critical)$")
    active:bool=True

class Approval25In(BaseModel):
    project:str=Field(min_length=1,max_length=120)
    action_type:str=Field(min_length=2,max_length=80)
    title:str=Field(min_length=3,max_length=200)
    description:str=Field(min_length=5,max_length=8000)
    requested_by:str=Field(default="operator",max_length=100)
    risk_level:str=Field(default="medium",pattern="^(low|medium|high|critical)$")

class Evaluation25In(BaseModel):
    agent_id:str=Field(min_length=1,max_length=80)
    project:str=Field(min_length=1,max_length=120)
    task_id:Optional[int]=None
    quality:int=Field(ge=1,le=5)
    accuracy:int=Field(ge=1,le=5)
    instruction_following:int=Field(ge=1,le=5)
    collaboration:int=Field(ge=1,le=5)
    feedback:str=Field(default="",max_length=5000)

class Learning25In(BaseModel):
    agent_id:str=Field(min_length=1,max_length=80)
    project:str=Field(min_length=1,max_length=120)
    lesson:str=Field(min_length=5,max_length=8000)
    source:str=Field(default="operator",max_length=100)


def init_v25():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS governance_policies_v25(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, scope TEXT NOT NULL, project TEXT,
          agent_id TEXT, rule TEXT NOT NULL, severity TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
          created_by TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_policy25_scope ON governance_policies_v25(scope,active);
        CREATE TABLE IF NOT EXISTS approvals_v25(
          id INTEGER PRIMARY KEY, project TEXT NOT NULL, action_type TEXT NOT NULL, title TEXT NOT NULL,
          description TEXT NOT NULL, requested_by TEXT NOT NULL, risk_level TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'pending', decided_by TEXT, decision_note TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL, decided_at TEXT);
        CREATE INDEX IF NOT EXISTS idx_approval25_status ON approvals_v25(status,created_at);
        CREATE TABLE IF NOT EXISTS agent_evaluations_v25(
          id INTEGER PRIMARY KEY, agent_id TEXT NOT NULL, project TEXT NOT NULL, task_id INTEGER,
          quality INTEGER NOT NULL, accuracy INTEGER NOT NULL, instruction_following INTEGER NOT NULL,
          collaboration INTEGER NOT NULL, overall REAL NOT NULL, feedback TEXT NOT NULL DEFAULT '',
          evaluator TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_eval25_agent ON agent_evaluations_v25(agent_id,created_at);
        CREATE TABLE IF NOT EXISTS learning_proposals_v25(
          id INTEGER PRIMARY KEY, agent_id TEXT NOT NULL, project TEXT NOT NULL, lesson TEXT NOT NULL,
          source TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'proposed', created_at TEXT NOT NULL,
          reviewed_by TEXT, reviewed_at TEXT, memory_id INTEGER);
        CREATE INDEX IF NOT EXISTS idx_learning25_status ON learning_proposals_v25(status,created_at);
        """)

@app.on_event("startup")
def startup_v25(): init_v25()

@app.get('/api/v25/status')
def v25_status(role=Depends(auth)):
    with conn() as c:
        count=lambda table,where='1=1':c.execute(f'SELECT COUNT(*) n FROM {table} WHERE {where}').fetchone()['n']
        pending=count('approvals_v25',"status='pending'")
        policies=count('governance_policies_v25','active=1')
        evals=count('agent_evaluations_v25')
        lessons=count('learning_proposals_v25',"status='proposed'")
        tasks=count('task_runs_v23',"status='completed'")
    return {'version':'25.0.0','service':SERVICE,'policies_active':policies,'approvals_pending':pending,'evaluations_recorded':evals,'learning_proposals_pending':lessons,'completed_ai_runs':tasks,'agents_registered':len(AGENTS_V21),'governance':'enabled'}

@app.get('/api/v25/policies')
def v25_policies(active:Optional[bool]=None,role=Depends(auth)):
    with conn() as c:
        sql='SELECT * FROM governance_policies_v25'; args=[]
        if active is not None: sql+=' WHERE active=?'; args.append(int(active))
        sql+=' ORDER BY id DESC LIMIT 200'
        rows=[dict(x) for x in c.execute(sql,args).fetchall()]
    return {'items':rows}

@app.post('/api/v25/policies')
def v25_policy_create(data:Policy25In,role=Depends(require_operator)):
    if data.agent_id: _agent22(data.agent_id)
    if data.scope=='project' and not data.project: raise HTTPException(422,'Kebijakan scope project memerlukan nama project.')
    if data.scope=='agent' and not data.agent_id: raise HTTPException(422,'Kebijakan scope agent memerlukan agent_id resmi.')
    with conn() as c:
        cur=c.execute('INSERT INTO governance_policies_v25(name,scope,project,agent_id,rule,severity,active,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)',(data.name.strip(),data.scope,data.project.strip() if data.project else None,data.agent_id,data.rule.strip(),data.severity,int(data.active),role,now(),now()))
        pid=cur.lastrowid
    audit(role,'v25.policy.create',f'id={pid}; scope={data.scope}; severity={data.severity}')
    return {'id':pid,'status':'created'}

@app.get('/api/v25/approvals')
def v25_approvals(status:Optional[str]=None,role=Depends(auth)):
    if status and status not in ('pending','approved','rejected'): raise HTTPException(422,'Filter status tidak valid.')
    with conn() as c:
        if status: rows=c.execute('SELECT * FROM approvals_v25 WHERE status=? ORDER BY id DESC LIMIT 200',(status,)).fetchall()
        else: rows=c.execute('SELECT * FROM approvals_v25 ORDER BY id DESC LIMIT 200').fetchall()
    return {'items':[dict(x) for x in rows]}

@app.post('/api/v25/approvals')
def v25_approval_create(data:Approval25In,role=Depends(require_operator)):
    with conn() as c:
        cur=c.execute("INSERT INTO approvals_v25(project,action_type,title,description,requested_by,risk_level,status,created_at) VALUES(?,?,?,?,?,?,'pending',?)",(data.project.strip(),data.action_type,data.title.strip(),data.description.strip(),data.requested_by,data.risk_level,now()))
        aid=cur.lastrowid
    audit(role,'v25.approval.request',f'id={aid}; risk={data.risk_level}; type={data.action_type}')
    return {'id':aid,'status':'pending','message':'Permintaan tercatat; tindakan belum dijalankan.'}

@app.post('/api/v25/approvals/{approval_id}/decision')
def v25_approval_decide(approval_id:int,data:dict,role=Depends(require_operator)):
    decision=str(data.get('decision','')).lower(); note=str(data.get('note',''))[:3000]
    if decision not in ('approved','rejected'): raise HTTPException(422,'Decision harus approved atau rejected.')
    with conn() as c:
        row=c.execute('SELECT status,risk_level FROM approvals_v25 WHERE id=?',(approval_id,)).fetchone()
        if not row: raise HTTPException(404,'Permintaan persetujuan tidak ditemukan.')
        if row['status']!='pending': raise HTTPException(409,'Permintaan sudah diputuskan; keputusan tidak dapat ditimpa.')
        if decision=='approved' and row['risk_level']=='critical' and role!='admin': raise HTTPException(403,'Persetujuan tindakan risiko critical hanya dapat diberikan Admin.')
        c.execute('UPDATE approvals_v25 SET status=?,decided_by=?,decision_note=?,decided_at=? WHERE id=?',(decision,role,note,now(),approval_id))
    audit(role,'v25.approval.'+decision,f'id={approval_id}; note={note}')
    return {'id':approval_id,'status':decision,'message':'Keputusan tercatat. Persetujuan ini adalah catatan tata kelola, bukan eksekusi otomatis tindakan eksternal.'}

@app.get('/api/v25/agents/performance')
def v25_performance(role=Depends(auth)):
    results=[]
    with conn() as c:
        for a in AGENTS_V21:
            aid=a['id']
            run=c.execute("""SELECT COUNT(*) total,SUM(CASE WHEN r.status='completed' THEN 1 ELSE 0 END) completed,
                SUM(CASE WHEN r.status='failed' THEN 1 ELSE 0 END) failed,AVG(r.review_score) avg_review
                FROM tasks_v22 t LEFT JOIN task_runs_v23 r ON r.task_id=t.id WHERE t.agent_id=?""",(aid,)).fetchone()
            ev=c.execute('SELECT COUNT(*) n,AVG(overall) avg_score FROM agent_evaluations_v25 WHERE agent_id=?',(aid,)).fetchone()
            results.append({'agent_id':aid,'name':a['name'],'role':a['role'],'runs_total':run['total'] or 0,'completed':run['completed'] or 0,'failed':run['failed'] or 0,'avg_supervisor_score':round(run['avg_review'],1) if run['avg_review'] is not None else None,'evaluations':ev['n'],'avg_human_score':round(ev['avg_score'],2) if ev['avg_score'] is not None else None})
    return {'items':results}

@app.post('/api/v25/evaluations')
def v25_evaluate(data:Evaluation25In,role=Depends(require_operator)):
    _agent22(data.agent_id)
    overall=round((data.quality+data.accuracy+data.instruction_following+data.collaboration)/4,2)
    with conn() as c:
        cur=c.execute('INSERT INTO agent_evaluations_v25(agent_id,project,task_id,quality,accuracy,instruction_following,collaboration,overall,feedback,evaluator,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(data.agent_id,data.project.strip(),data.task_id,data.quality,data.accuracy,data.instruction_following,data.collaboration,overall,data.feedback.strip(),role,now()))
    audit(role,'v25.agent.evaluate',f'id={cur.lastrowid}; agent={data.agent_id}; score={overall}')
    return {'id':cur.lastrowid,'overall':overall,'status':'recorded'}

@app.get('/api/v25/learning')
def v25_learning(status:Optional[str]=None,role=Depends(auth)):
    if status and status not in ('proposed','approved','rejected'): raise HTTPException(422,'Filter status tidak valid.')
    with conn() as c:
        if status: rows=c.execute('SELECT * FROM learning_proposals_v25 WHERE status=? ORDER BY id DESC LIMIT 200',(status,)).fetchall()
        else: rows=c.execute('SELECT * FROM learning_proposals_v25 ORDER BY id DESC LIMIT 200').fetchall()
    return {'items':[dict(x) for x in rows]}

@app.post('/api/v25/learning')
def v25_learning_create(data:Learning25In,role=Depends(require_operator)):
    _agent22(data.agent_id)
    with conn() as c:
        cur=c.execute("INSERT INTO learning_proposals_v25(agent_id,project,lesson,source,status,created_at) VALUES(?,?,?,?,'proposed',?)",(data.agent_id,data.project.strip(),data.lesson.strip(),data.source,now()))
    audit(role,'v25.learning.propose',f'id={cur.lastrowid}; agent={data.agent_id}')
    return {'id':cur.lastrowid,'status':'proposed','message':'Pelajaran menunggu persetujuan sebelum dimasukkan ke memori agen.'}

@app.post('/api/v25/learning/{proposal_id}/decision')
def v25_learning_decide(proposal_id:int,data:dict,role=Depends(require_operator)):
    decision=str(data.get('decision','')).lower()
    if decision not in ('approved','rejected'): raise HTTPException(422,'Decision harus approved atau rejected.')
    with conn() as c:
        row=c.execute('SELECT * FROM learning_proposals_v25 WHERE id=?',(proposal_id,)).fetchone()
        if not row: raise HTTPException(404,'Usulan pembelajaran tidak ditemukan.')
        if row['status']!='proposed': raise HTTPException(409,'Usulan sudah ditinjau.')
        memory_id=None
        if decision=='approved':
            memory_id=c.execute('INSERT INTO agent_memory_v22(project,agent_id,memory_type,content,created_at) VALUES(?,?,?,?,?)',(row['project'],row['agent_id'],'approved_lesson',row['lesson'],now())).lastrowid
        c.execute('UPDATE learning_proposals_v25 SET status=?,reviewed_by=?,reviewed_at=?,memory_id=? WHERE id=?',(decision,role,now(),memory_id,proposal_id))
    audit(role,'v25.learning.'+decision,f'id={proposal_id}; memory_id={memory_id}')
    return {'id':proposal_id,'status':decision,'memory_id':memory_id,'message':'Pelajaran disetujui dan disimpan ke memori agen.' if decision=='approved' else 'Usulan ditolak; memori agen tidak diubah.'}


# ===== TAHAP 26 — AUTONOMOUS ENTERPRISE COMMAND & INTELLIGENCE CENTER =====
class AlertAck26In(BaseModel):
    note:str=Field(default='',max_length=2000)

def init_v26():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS command_alerts_v26(
          id INTEGER PRIMARY KEY, alert_type TEXT NOT NULL, severity TEXT NOT NULL,
          title TEXT NOT NULL, detail TEXT NOT NULL, project TEXT, task_id INTEGER,
          agent_id TEXT, status TEXT NOT NULL DEFAULT 'open', acknowledged_by TEXT,
          acknowledged_at TEXT, acknowledgement_note TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_alert26_status ON command_alerts_v26(status,severity,created_at);
        CREATE INDEX IF NOT EXISTS idx_alert26_task ON command_alerts_v26(task_id);
        """)

@app.on_event('startup')
def startup_v26(): init_v26()

@app.get('/api/v26/status')
def v26_status(role=Depends(auth)):
    with conn() as c:
        def n(sql,args=()): return c.execute(sql,args).fetchone()[0]
        data={
          'version':'26.0.0','service':SERVICE,'agents_registered':len(AGENTS_V21),
          'policies_active':n('SELECT COUNT(*) FROM governance_policies_v25 WHERE active=1'),
          'approvals_pending':n("SELECT COUNT(*) FROM approvals_v25 WHERE status='pending'"),
          'tasks_queued':n("SELECT COUNT(*) FROM task_runs_v23 WHERE status='queued'"),
          'tasks_running':n("SELECT COUNT(*) FROM task_runs_v23 WHERE status='running'"),
          'tasks_completed':n("SELECT COUNT(*) FROM task_runs_v23 WHERE status='completed'"),
          'tasks_failed':n("SELECT COUNT(*) FROM task_runs_v23 WHERE status='failed'"),
          'alerts_open':n("SELECT COUNT(*) FROM command_alerts_v26 WHERE status='open'"),
          'alerts_critical':n("SELECT COUNT(*) FROM command_alerts_v26 WHERE status='open' AND severity='critical'"),
          'governance_enforcement':'active'
        }
    return data

@app.get('/api/v26/command-center')
def v26_command_center(role=Depends(auth)):
    status=v26_status(role)
    with conn() as c:
        recent=[dict(x) for x in c.execute('SELECT id,alert_type,severity,title,project,task_id,agent_id,status,created_at FROM command_alerts_v26 ORDER BY id DESC LIMIT 12').fetchall()]
        pending=[dict(x) for x in c.execute("SELECT id,project,title,risk_level,created_at FROM approvals_v25 WHERE status='pending' ORDER BY id DESC LIMIT 8").fetchall()]
    return {'summary':status,'recent_alerts':recent,'pending_approvals':pending}

@app.get('/api/v26/alerts')
def v26_alerts(status:Optional[str]=None,severity:Optional[str]=None,limit:int=100,role=Depends(auth)):
    if status and status not in ('open','acknowledged'): raise HTTPException(422,'Filter status tidak valid.')
    if severity and severity not in ('low','medium','high','critical'): raise HTTPException(422,'Filter severity tidak valid.')
    limit=max(1,min(limit,250)); clauses=[]; args=[]
    if status: clauses.append('status=?'); args.append(status)
    if severity: clauses.append('severity=?'); args.append(severity)
    sql='SELECT * FROM command_alerts_v26'+((' WHERE '+' AND '.join(clauses)) if clauses else '')+' ORDER BY id DESC LIMIT ?'; args.append(limit)
    with conn() as c: rows=[dict(x) for x in c.execute(sql,args).fetchall()]
    return {'items':rows}

@app.post('/api/v26/alerts/{alert_id}/ack')
def v26_alert_ack(alert_id:int,data:AlertAck26In,role=Depends(require_operator)):
    with conn() as c:
        row=c.execute('SELECT status FROM command_alerts_v26 WHERE id=?',(alert_id,)).fetchone()
        if not row: raise HTTPException(404,'Alert tidak ditemukan.')
        if row['status']=='acknowledged': raise HTTPException(409,'Alert sudah diakui sebelumnya.')
        c.execute("UPDATE command_alerts_v26 SET status='acknowledged',acknowledged_by=?,acknowledged_at=?,acknowledgement_note=? WHERE id=?",(role,now(),data.note,alert_id))
    audit(role,'v26.alert.acknowledged',f'id={alert_id}')
    return {'id':alert_id,'status':'acknowledged'}

@app.get('/api/v26/productivity')
def v26_productivity(role=Depends(auth)):
    items=[]
    with conn() as c:
        for a in AGENTS_V21:
            row=c.execute("""SELECT COUNT(*) total,
              SUM(CASE WHEN r.status='queued' THEN 1 ELSE 0 END) queued,
              SUM(CASE WHEN r.status='running' THEN 1 ELSE 0 END) running,
              SUM(CASE WHEN r.status='completed' THEN 1 ELSE 0 END) completed,
              SUM(CASE WHEN r.status='failed' THEN 1 ELSE 0 END) failed,
              AVG(CASE WHEN r.status='completed' THEN (julianday(r.finished_at)-julianday(r.started_at))*86400 END) avg_seconds
              FROM tasks_v22 t LEFT JOIN task_runs_v23 r ON r.task_id=t.id WHERE t.agent_id=?""",(a['id'],)).fetchone()
            items.append({'agent_id':a['id'],'name':a['name'],'role':a['role'],'total':row['total'] or 0,'queued':row['queued'] or 0,'running':row['running'] or 0,'completed':row['completed'] or 0,'failed':row['failed'] or 0,'avg_duration_seconds':round(row['avg_seconds'],1) if row['avg_seconds'] is not None else None})
    return {'items':items,'scope':'all recorded tasks','note':'Durasi dihitung dari started_at hingga finished_at; nilai kosong berarti belum ada data selesai.'}


# ===== TAHAP 27 — DISTRIBUTED-READY PERSISTENT WORKER INFRASTRUCTURE =====
# SQLite-backed queue leases survive API process restarts. One API process with
# multiple worker threads is supported; multi-process/multi-host deployments
# should move this lease layer to PostgreSQL/Redis before scaling horizontally.
_WORKER_WAKE27=threading.Event()
_WORKER_THREADS27=[]
_WORKER_STOP27=threading.Event()
_WORKER_ID27=f"nck-{os.getpid()}-{uuid.uuid4().hex[:8]}"
_WORKER_CAP27=max(1,min(int(os.getenv('NCK_WORKER_CONCURRENCY','3')),16))

class WorkerControl27In(BaseModel):
    paused:bool
    reason:str=Field(default='',max_length=1000)

class QueueRetry27In(BaseModel):
    task_id:int=Field(ge=1)


def init_v27():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS worker_leases_v27(
          task_id INTEGER PRIMARY KEY, worker_id TEXT NOT NULL, claimed_at TEXT NOT NULL,
          FOREIGN KEY(task_id) REFERENCES tasks_v22(id));
        CREATE TABLE IF NOT EXISTS worker_registry_v27(
          worker_id TEXT PRIMARY KEY, process_id INTEGER NOT NULL, slot INTEGER NOT NULL,
          status TEXT NOT NULL DEFAULT 'idle', current_task_id INTEGER,
          started_at TEXT NOT NULL, heartbeat_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS worker_control_v27(
          id INTEGER PRIMARY KEY CHECK(id=1), paused INTEGER NOT NULL DEFAULT 0,
          reason TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL, updated_by TEXT NOT NULL DEFAULT 'system');
        CREATE TABLE IF NOT EXISTS queue_events_v27(
          id INTEGER PRIMARY KEY, event TEXT NOT NULL, task_id INTEGER, worker_id TEXT,
          detail TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_worker_leases_claimed ON worker_leases_v27(claimed_at);
        CREATE INDEX IF NOT EXISTS idx_queue_events_v27_created ON queue_events_v27(created_at);
        INSERT OR IGNORE INTO worker_control_v27(id,paused,reason,updated_at,updated_by)
          VALUES(1,0,'',CURRENT_TIMESTAMP,'system');
        """)
        # Tahap 34: tidak ada lagi penghapusan registry/lease massal dan tidak ada auto-unpause saat startup, karena proses lain
        # mungkin masih hidup. Worker mati dideteksi lewat heartbeat (recover_orphans34); status pause tetap tersimpan.


def _queue_event27(event,task_id=None,worker_id=None,detail=''):
    with conn() as c:
        c.execute('INSERT INTO queue_events_v27(event,task_id,worker_id,detail,created_at) VALUES(?,?,?,?,?)',
                  (event,task_id,worker_id,str(detail)[:1500],now()))


def _wake_workers27():
    _WORKER_WAKE27.set()


def _claim_task27(worker_id):
    with conn() as c:
        c.execute('BEGIN IMMEDIATE')
        control=c.execute('SELECT paused FROM worker_control_v27 WHERE id=1').fetchone()
        if control and control['paused']:
            c.commit(); return None
        row=c.execute("""SELECT r.task_id FROM task_runs_v23 r
          LEFT JOIN worker_leases_v27 l ON l.task_id=r.task_id
          WHERE r.status='queued' AND l.task_id IS NULL
          ORDER BY r.created_at,r.id LIMIT 1"""+nck_db.SKIP_LOCKED_R).fetchone()
        if not row:
            c.commit(); return None
        tid=int(row['task_id'])
        cur=c.execute('INSERT OR IGNORE INTO worker_leases_v27(task_id,worker_id,claimed_at) VALUES(?,?,?)',(tid,worker_id,now()))
        if not cur.rowcount:
            c.commit(); return None
        c.execute("UPDATE worker_registry_v27 SET status='busy',current_task_id=?,heartbeat_at=? WHERE worker_id=?",(tid,now(),worker_id))
        c.commit()
    _queue_event27('worker.claimed',tid,worker_id,'Task diklaim oleh worker pool persisten.')
    _event23(tid,'queue.worker_claimed',f'worker={worker_id}')
    return tid


def _worker_loop27(slot):
    worker_id=f'{_WORKER_ID27}-{slot}'
    with conn() as c:
        c.execute('INSERT OR REPLACE INTO worker_registry_v27(worker_id,process_id,slot,status,started_at,heartbeat_at) VALUES(?,?,?,\'idle\',?,?)',
                  (worker_id,os.getpid(),slot,now(),now()))
    while not _WORKER_STOP27.is_set():
        tid=_claim_task27(worker_id)
        if tid is None:
            with conn() as c:c.execute("UPDATE worker_registry_v27 SET status='idle',current_task_id=NULL,heartbeat_at=? WHERE worker_id=?",(now(),worker_id))
            _WORKER_WAKE27.wait(timeout=1.5); _WORKER_WAKE27.clear(); continue
        try:
            asyncio.run(execute_task23(tid))
            with conn() as c:
                status=c.execute('SELECT status FROM task_runs_v23 WHERE task_id=?',(tid,)).fetchone()
                final=status['status'] if status else 'unknown'
                lost=c.execute('DELETE FROM worker_leases_v27 WHERE task_id=? AND worker_id=?',(tid,worker_id)).rowcount==0
                c.execute("UPDATE worker_registry_v27 SET status='idle',current_task_id=NULL,heartbeat_at=? WHERE worker_id=?",(now(),worker_id))
            if lost: _queue_event27('worker.lease_lost',tid,worker_id,'Lease sudah diambil alih (worker dianggap mati); tugas mungkin dijalankan ulang oleh worker lain.')
            _queue_event27('worker.finished',tid,worker_id,f'final_status={final}')
        except Exception as exc:
            with conn() as c:
                c.execute('DELETE FROM worker_leases_v27 WHERE task_id=?',(tid,))
                c.execute("UPDATE worker_registry_v27 SET status='error',current_task_id=NULL,heartbeat_at=? WHERE worker_id=?",(now(),worker_id))
            _queue_event27('worker.error',tid,worker_id,str(exc)[:1000])
        _WORKER_WAKE27.set()
    with conn() as c:c.execute('DELETE FROM worker_registry_v27 WHERE worker_id=?',(worker_id,))


def _start_workers27():
    if _WORKER_THREADS27: return
    for slot in range(_WORKER_CAP27):
        t=threading.Thread(target=_worker_loop27,args=(slot+1,),name=f'NCK-Worker-{slot+1}',daemon=True)
        t.start(); _WORKER_THREADS27.append(t)
    _queue_event27('worker_pool.started',None,_WORKER_ID27,f'capacity={_WORKER_CAP27}')
    _wake_workers27()

# ===== TAHAP 34 — EKSEKUSI AI TERDISTRIBUSI (API / WORKER TERPISAH, PEMULIHAN BERBASIS HEARTBEAT) =====
NCK_WORKER_MODE34=os.getenv('NCK_WORKER_MODE','both').strip().lower()
if NCK_WORKER_MODE34 not in ('both','api','worker'): NCK_WORKER_MODE34='both'
NCK_WORKER_STALE34=max(15,min(int(os.getenv('NCK_WORKER_STALE_SECONDS','90')),3600))
NCK_HEARTBEAT34=max(2,min(int(os.getenv('NCK_WORKER_HEARTBEAT_SECONDS','10')),max(2,NCK_WORKER_STALE34//3)))

def _age34(ts):
    try:
        d=datetime.fromisoformat(str(ts).replace('Z','+00:00'))
        if d.tzinfo is None: d=d.replace(tzinfo=timezone.utc)
        return (datetime.now(timezone.utc)-d).total_seconds()
    except Exception:
        return 10**9

def recover_orphans34(stale=None,immediate=False):
    """Kembalikan tugas milik worker yang MATI (heartbeat basi) ke antrean. Aman dipanggil dari banyak proses sekaligus.
    immediate=True: anggap semua worker lama mati (hanya untuk SQLite satu-proses saat startup; perilaku Tahap 27-33)."""
    stale=stale or NCK_WORKER_STALE34
    recovered=[]
    with conn() as c:
        regs={r['worker_id']:r['heartbeat_at'] for r in c.execute('SELECT worker_id,heartbeat_at FROM worker_registry_v27').fetchall()}
        if immediate:
            stale=-1
        dead={w for w,h in regs.items() if _age34(h)>stale}
        for r in c.execute("""SELECT r.task_id,r.started_at,l.worker_id AS lw,l.claimed_at FROM task_runs_v23 r
                              LEFT JOIN worker_leases_v27 l ON l.task_id=r.task_id WHERE r.status='running'""").fetchall():
            wid=r['lw']
            if immediate: orphan=True
            elif wid is None: orphan=_age34(r['started_at'])>stale
            elif wid in dead: orphan=True
            else: orphan=(wid not in regs) and _age34(r['claimed_at'])>stale
            if not orphan: continue
            if c.execute("UPDATE task_runs_v23 SET status='queued',error=? WHERE task_id=? AND status='running'",
                         (f'Worker {wid or "tak dikenal"} tidak merespons ({"restart instance" if immediate else ">"+str(stale)+"s"}); tugas dikembalikan ke antrean.',r['task_id'])).rowcount:
                c.execute('DELETE FROM worker_leases_v27 WHERE task_id=?',(r['task_id'],))
                c.execute("UPDATE tasks_v22 SET status='assigned',updated_at=? WHERE id=? AND status='in_progress'",(now(),r['task_id']))
                recovered.append((int(r['task_id']),wid))
        # lease basi untuk tugas yang tidak berjalan (worker mati antara klaim dan eksekusi)
        for l in c.execute("""SELECT l.task_id,l.claimed_at FROM worker_leases_v27 l JOIN task_runs_v23 r ON r.task_id=l.task_id
                              WHERE r.status!='running'""").fetchall():
            if immediate or _age34(l['claimed_at'])>stale: c.execute('DELETE FROM worker_leases_v27 WHERE task_id=?',(l['task_id'],))
        for w in dead: c.execute('DELETE FROM worker_registry_v27 WHERE worker_id=?',(w,))
    for tid,wid in recovered:
        _queue_event27('worker.orphan_recovered',tid,wid,('restart instance' if immediate else f'heartbeat basi >{stale}s')+'; tugas kembali ke antrean.')
        _event23(tid,'queue.orphan_recovered',f'worker={wid}')
    if recovered: _wake_workers27()
    return recovered

def _maintenance_loop34():
    beat=0
    while not _WORKER_STOP27.wait(NCK_HEARTBEAT34):
        beat+=1
        try:
            with conn() as c:
                c.execute('UPDATE worker_registry_v27 SET heartbeat_at=? WHERE worker_id LIKE ?',(now(),_WORKER_ID27+'-%'))
            if beat%3==0: recover_orphans34()
        except Exception as exc:
            _security_event31('worker.maintenance_error','warning','','',str(exc)[:300])

NCK_SHUTDOWN_GRACE34=max(0,min(int(os.getenv('NCK_SHUTDOWN_GRACE_SECONDS','10')),120))

def release_own_leases34():
    """Shutdown terkendali: tugas yang masih berjalan milik instance ini langsung dikembalikan ke antrean (tanpa menunggu heartbeat basi)."""
    prefix=_WORKER_ID27+'-%'
    released=[]
    with conn() as c:
        for l in c.execute('SELECT task_id,worker_id FROM worker_leases_v27 WHERE worker_id LIKE ?',(prefix,)).fetchall():
            if c.execute("UPDATE task_runs_v23 SET status='queued',error=? WHERE task_id=? AND status='running'",('Instance dimatikan terkendali; tugas dikembalikan ke antrean.',l['task_id'])).rowcount:
                c.execute("UPDATE tasks_v22 SET status='assigned',updated_at=? WHERE id=? AND status='in_progress'",(now(),l['task_id']))
                released.append(int(l['task_id']))
            c.execute('DELETE FROM worker_leases_v27 WHERE task_id=? AND worker_id=?',(l['task_id'],l['worker_id']))
        c.execute('DELETE FROM worker_registry_v27 WHERE worker_id LIKE ?',(prefix,))
    for tid in released: _queue_event27('worker.released_on_shutdown',tid,_WORKER_ID27,'Shutdown terkendali; tugas kembali ke antrean.')
    return released

def graceful_shutdown34(grace=None):
    grace=NCK_SHUTDOWN_GRACE34 if grace is None else grace
    _WORKER_STOP27.set(); _WORKER_WAKE27.set()
    deadline=time.time()+grace
    for t in list(_WORKER_THREADS27): t.join(max(0.0,deadline-time.time()))
    return release_own_leases34()

_MAINT_THREAD34=[]
def _start_maintenance34():
    if _MAINT_THREAD34: return
    t=threading.Thread(target=_maintenance_loop34,name='NCK-Maintenance',daemon=True); t.start(); _MAINT_THREAD34.append(t)

@app.on_event('startup')
def startup_v27():
    init_v27()
    # SQLite + satu proses (mode both): tidak ada proses lain, jadi semua run 'running' lama pasti yatim -> pulihkan segera.
    recover_orphans34(immediate=(not nck_db.IS_PG and NCK_WORKER_MODE34=='both'))
    if NCK_WORKER_MODE34!='api': _start_workers27()
    _start_maintenance34()
    if NCK_WORKER_MODE34!='both' and not nck_db.IS_PG:
        _security_event31('distributed.sqlite_warning','warning','','','Mode '+NCK_WORKER_MODE34+' dengan SQLite: file database harus dibagi antar proses; gunakan PostgreSQL untuk deployment terdistribusi.')

@app.on_event('shutdown')
def shutdown_v34():
    try: graceful_shutdown34()
    except Exception: pass

@app.get('/api/v34/distributed/status')
def v34_distributed_status(role=Depends(auth)):
    with conn() as c:
        workers=[]
        for r in c.execute('SELECT worker_id,slot,status,current_task_id,started_at,heartbeat_at FROM worker_registry_v27 ORDER BY worker_id').fetchall():
            age=_age34(r['heartbeat_at'])
            workers.append({'worker_id':r['worker_id'],'status':r['status'],'current_task_id':r['current_task_id'],'heartbeat_age_seconds':round(age,1),'alive':age<=NCK_WORKER_STALE34})
        counts={x:c.execute('SELECT COUNT(*) FROM task_runs_v23 WHERE status=?',(x,)).fetchone()[0] for x in ('queued','running','completed','failed')}
    alive=sum(1 for w in workers if w['alive'])
    return {'stage':34,'mode':NCK_WORKER_MODE34,'instance_id':_WORKER_ID27,'database':nck_db.BACKEND,
      'multi_process_safe':bool(nck_db.IS_PG),'stale_seconds':NCK_WORKER_STALE34,'heartbeat_seconds':NCK_HEARTBEAT34,
      'workers_alive':alive,'workers_stale':len(workers)-alive,'workers':workers,'queue':counts,
      'delivery_semantics':'at-least-once: worker yang membeku lebih lama dari stale_seconds dapat diambil alih dan tugasnya dijalankan ulang.',
      'warning':None if nck_db.IS_PG or NCK_WORKER_MODE34=='both' else 'Mode terpisah memerlukan database bersama (PostgreSQL).'}

@app.get('/api/v27/status')
def v27_status(role=Depends(auth)):
    with conn() as c:
        control=c.execute('SELECT paused,reason,updated_at,updated_by FROM worker_control_v27 WHERE id=1').fetchone()
        workers=[dict(x) for x in c.execute('SELECT worker_id,slot,status,current_task_id,started_at,heartbeat_at FROM worker_registry_v27 ORDER BY slot').fetchall()]
        counts={x:c.execute('SELECT COUNT(*) FROM task_runs_v23 WHERE status=?',(x,)).fetchone()[0] for x in ('queued','running','completed','failed')}
        leases=c.execute('SELECT COUNT(*) FROM worker_leases_v27').fetchone()[0]
    return {'version':'27.0.0','queue':counts,'worker_pool':{'capacity':_WORKER_CAP27,'active_threads':sum(1 for t in _WORKER_THREADS27 if t.is_alive()),'workers':workers,'paused':bool(control['paused']) if control else False,'pause_reason':control['reason'] if control else '', 'leases':leases},'durability':'SQLite queue + atomic task leases','deployment_mode':'single API process; multiple worker threads'}

@app.get('/api/v27/queue')
def v27_queue(role=Depends(auth)):
    with conn() as c:
        rows=c.execute("SELECT r.task_id,r.status,r.provider,r.attempt,r.created_at,r.started_at,t.title,t.project,t.agent_id,t.priority,l.worker_id,l.claimed_at FROM task_runs_v23 r JOIN tasks_v22 t ON t.id=r.task_id LEFT JOIN worker_leases_v27 l ON l.task_id=r.task_id WHERE r.status IN ('queued','running') ORDER BY CASE t.priority WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 WHEN 'normal' THEN 2 ELSE 3 END,r.created_at LIMIT 200").fetchall()
        events=c.execute('SELECT event,task_id,worker_id,detail,created_at FROM queue_events_v27 ORDER BY id DESC LIMIT 25').fetchall()
    return {'items':[dict(x) for x in rows],'events':[dict(x) for x in events]}

@app.post('/api/v27/workers/control')
def v27_worker_control(data:WorkerControl27In,role=Depends(require_operator)):
    with conn() as c:c.execute('UPDATE worker_control_v27 SET paused=?,reason=?,updated_at=?,updated_by=? WHERE id=1',(int(data.paused),data.reason,now(),role))
    _queue_event27('worker_pool.paused' if data.paused else 'worker_pool.resumed',None,_WORKER_ID27,data.reason or role)
    if not data.paused:_wake_workers27()
    audit(role,'v27.worker.control',f'paused={data.paused}; reason={data.reason}')
    return {'paused':data.paused,'reason':data.reason,'status':'updated'}

@app.post('/api/v27/queue/retry')
def v27_retry(data:QueueRetry27In,role=Depends(require_operator)):
    with conn() as c:
        row=c.execute('SELECT status FROM task_runs_v23 WHERE task_id=?',(data.task_id,)).fetchone()
        if not row: raise HTTPException(404,'Riwayat eksekusi task tidak ditemukan.')
        if row['status'] not in ('failed',): raise HTTPException(409,'Hanya task gagal yang dapat dimasukkan ulang.')
        c.execute("UPDATE task_runs_v23 SET status='queued',error='',attempt=0,created_at=?,started_at=NULL,finished_at=NULL WHERE task_id=?",(now(),data.task_id))
        c.execute("UPDATE tasks_v22 SET status='assigned',updated_at=? WHERE id=?",(now(),data.task_id))
    _event23(data.task_id,'queue.manual_retry',f'operator={role}')
    _queue_event27('queue.manual_retry',data.task_id,_WORKER_ID27,f'operator={role}')
    _wake_workers27(); audit(role,'v27.queue.retry',f'task={data.task_id}')
    return {'task_id':data.task_id,'status':'queued'}

@app.get('/api/v27/events')
def v27_events(limit:int=100,role=Depends(auth)):
    limit=max(1,min(limit,300))
    with conn() as c: rows=[dict(x) for x in c.execute('SELECT * FROM queue_events_v27 ORDER BY id DESC LIMIT ?',(limit,)).fetchall()]
    return {'items':rows}


# ===== TAHAP 28 — CLUSTER INFRASTRUCTURE CONTROL PLANE =====
# This stage adds optional PostgreSQL/Redis connectivity, node registry and
# infrastructure event bus. Core application data/execution remain on the
# Tahap 27 SQLite worker until the dedicated full DB/worker migration stage.
NODE_ID28=os.getenv('NCK_NODE_ID',f'{socket.gethostname()}-{os.getpid()}')[:120]
NODE_ROLE28=os.getenv('NCK_NODE_ROLE','api-worker')[:40]
POSTGRES_DSN28=os.getenv('NCK_POSTGRES_DSN','').strip()
REDIS_URL28=os.getenv('NCK_REDIS_URL','').strip()

class NodeHeartbeat28In(BaseModel):
    node_id:str=Field(min_length=2,max_length=120)
    role:str=Field(default='worker',max_length=40)
    capacity:int=Field(default=1,ge=1,le=128)
    active_tasks:int=Field(default=0,ge=0,le=10000)
    status:str=Field(default='online',pattern='^(online|draining|maintenance)$')
    metadata:dict=Field(default_factory=dict)


def _pg_connect28():
    if not POSTGRES_DSN28: return None
    try:
        import psycopg
        return psycopg.connect(POSTGRES_DSN28,connect_timeout=3)
    except Exception as e:
        raise RuntimeError(f'PostgreSQL unavailable: {str(e)[:300]}')


def _redis_client28():
    if not REDIS_URL28: return None
    try:
        import redis
        client=redis.Redis.from_url(REDIS_URL28,socket_connect_timeout=3,socket_timeout=3,decode_responses=True)
        client.ping()
        return client
    except Exception as e:
        raise RuntimeError(f'Redis unavailable: {str(e)[:300]}')


def init_v28():
    with conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS cluster_nodes_v28(
          node_id TEXT PRIMARY KEY, role TEXT NOT NULL, capacity INTEGER NOT NULL DEFAULT 1,
          active_tasks INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'online',
          metadata TEXT NOT NULL DEFAULT '{}', first_seen TEXT NOT NULL, last_seen TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS infrastructure_events_v28(
          id INTEGER PRIMARY KEY, event_type TEXT NOT NULL, node_id TEXT,
          payload TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_cluster_nodes_seen_v28 ON cluster_nodes_v28(last_seen);
        CREATE INDEX IF NOT EXISTS idx_infra_events_v28 ON infrastructure_events_v28(created_at);
        ''')
    if POSTGRES_DSN28:
        pg=_pg_connect28()
        try:
            with pg.cursor() as cur:
                cur.execute('''CREATE TABLE IF NOT EXISTS nck_cluster_nodes_v28(
                  node_id VARCHAR(120) PRIMARY KEY, role VARCHAR(40) NOT NULL,
                  capacity INTEGER NOT NULL DEFAULT 1, active_tasks INTEGER NOT NULL DEFAULT 0,
                  status VARCHAR(24) NOT NULL DEFAULT 'online', metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
                  first_seen TIMESTAMPTZ NOT NULL, last_seen TIMESTAMPTZ NOT NULL)''')
            pg.commit()
        finally: pg.close()


def _infra_event28(event_type,node_id=None,payload=None):
    payload=payload or {}; stamp=now()
    with conn() as c:
        c.execute('INSERT INTO infrastructure_events_v28(event_type,node_id,payload,created_at) VALUES(?,?,?,?)',
                  (event_type,node_id,json.dumps(payload,ensure_ascii=False)[:4000],stamp))
    if REDIS_URL28:
        try:
            r=_redis_client28(); r.xadd('nck:v28:infra-events',{'type':event_type,'node_id':node_id or '',
              'payload':json.dumps(payload,ensure_ascii=False)[:4000],'created_at':stamp},maxlen=5000, approximate=True)
        except Exception: pass


def _node_heartbeat28(data):
    stamp=now(); meta=json.dumps(data.metadata,ensure_ascii=False)[:4000]
    with conn() as c:
        c.execute('''INSERT INTO cluster_nodes_v28(node_id,role,capacity,active_tasks,status,metadata,first_seen,last_seen)
          VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(node_id) DO UPDATE SET role=excluded.role,capacity=excluded.capacity,
          active_tasks=excluded.active_tasks,status=excluded.status,metadata=excluded.metadata,last_seen=excluded.last_seen''',
          (data.node_id,data.role,data.capacity,data.active_tasks,data.status,meta,stamp,stamp))
    pg_state='not_configured'
    if POSTGRES_DSN28:
        pg=_pg_connect28()
        try:
            with pg.cursor() as cur:
                cur.execute('''INSERT INTO nck_cluster_nodes_v28(node_id,role,capacity,active_tasks,status,metadata,first_seen,last_seen)
                  VALUES(%s,%s,%s,%s,%s,%s::jsonb,%s,%s) ON CONFLICT(node_id) DO UPDATE SET role=EXCLUDED.role,
                  capacity=EXCLUDED.capacity,active_tasks=EXCLUDED.active_tasks,status=EXCLUDED.status,
                  metadata=EXCLUDED.metadata,last_seen=EXCLUDED.last_seen''',
                  (data.node_id,data.role,data.capacity,data.active_tasks,data.status,meta,stamp,stamp))
            pg.commit(); pg_state='registered'
        finally: pg.close()
    redis_state='not_configured'
    if REDIS_URL28:
        r=_redis_client28(); r.setex(f'nck:v28:node:{data.node_id}',45,json.dumps({'node_id':data.node_id,'role':data.role,
          'capacity':data.capacity,'active_tasks':data.active_tasks,'status':data.status,'last_seen':stamp}))
        redis_state='heartbeat_published'
    _infra_event28('cluster.node_heartbeat',data.node_id,{'role':data.role,'status':data.status,'capacity':data.capacity,'active_tasks':data.active_tasks})
    return {'node_id':data.node_id,'last_seen':stamp,'postgres':pg_state,'redis':redis_state}


@app.get('/api/v28/infrastructure/status')
def v28_infrastructure_status(role=Depends(auth)):
    checks={'postgresql':{'configured':bool(POSTGRES_DSN28),'status':'not_configured'},
            'redis':{'configured':bool(REDIS_URL28),'status':'not_configured'}}
    if POSTGRES_DSN28:
        try:
            pg=_pg_connect28()
            try:
                with pg.cursor() as cur: cur.execute('SELECT 1'); cur.fetchone()
            finally: pg.close()
            checks['postgresql']['status']='connected'
        except Exception as e: checks['postgresql'].update(status='error',detail=str(e)[:250])
    if REDIS_URL28:
        try:
            r=_redis_client28(); checks['redis']['status']='connected'
            checks['redis']['stream_length']=r.xlen('nck:v28:infra-events')
        except Exception as e: checks['redis'].update(status='error',detail=str(e)[:250])
    with conn() as c:
        nodes=c.execute('SELECT COUNT(*) FROM cluster_nodes_v28').fetchone()[0]
        events=c.execute('SELECT COUNT(*) FROM infrastructure_events_v28').fetchone()[0]
    return {'version':'28.0.0','node_id':NODE_ID28,'node_role':NODE_ROLE28,'checks':checks,
      'registry':{'known_nodes':nodes,'local_event_records':events},
      'application_data_backend':'SQLite (Tahap 27 compatibility mode)',
      'distributed_execution':'not_enabled_until_full_shared-database_and_worker_migration',
      'next_migration':'Tahap 29: shared PostgreSQL data plane + Redis Streams worker consumers'}


@app.post('/api/v28/cluster/heartbeat')
def v28_cluster_heartbeat(data:NodeHeartbeat28In,role=Depends(require_operator)):
    result=_node_heartbeat28(data); audit(role,'v28.cluster.heartbeat',f"node={data.node_id}; status={data.status}")
    return {'status':'recorded',**result}


@app.get('/api/v28/cluster/nodes')
def v28_cluster_nodes(role=Depends(auth)):
    with conn() as c:
        rows=c.execute('SELECT node_id,role,capacity,active_tasks,status,metadata,first_seen,last_seen FROM cluster_nodes_v28 ORDER BY last_seen DESC').fetchall()
    out=[]
    for x in rows:
        d=dict(x)
        try:d['metadata']=json.loads(d['metadata'] or '{}')
        except Exception:d['metadata']={}
        out.append(d)
    return {'items':out,'source':'local registry mirror; PostgreSQL registry is optional'}


@app.get('/api/v28/infrastructure/events')
def v28_infrastructure_events(limit:int=100,role=Depends(auth)):
    limit=max(1,min(limit,300))
    with conn() as c: rows=c.execute('SELECT * FROM infrastructure_events_v28 ORDER BY id DESC LIMIT ?',(limit,)).fetchall()
    items=[]
    for x in rows:
        d=dict(x)
        try:d['payload']=json.loads(d['payload'] or '{}')
        except Exception:d['payload']={}
        items.append(d)
    return {'items':items}


@app.post('/api/v28/cluster/local-heartbeat')
def v28_local_heartbeat(role=Depends(require_operator)):
    data=NodeHeartbeat28In(node_id=NODE_ID28,role=NODE_ROLE28,capacity=int(os.getenv('NCK_WORKER_CONCURRENCY','3')),
      active_tasks=0,status='online',metadata={'host':socket.gethostname(),'pid':os.getpid(),'stage27_worker_threads':sum(1 for t in _WORKER_THREADS27 if t.is_alive())})
    result=_node_heartbeat28(data); return {'status':'recorded',**result}

@app.on_event('startup')
def startup_v28():
    init_v28()
    try:
        _node_heartbeat28(NodeHeartbeat28In(node_id=NODE_ID28,role=NODE_ROLE28,
          capacity=int(os.getenv('NCK_WORKER_CONCURRENCY','3')),active_tasks=0,status='online',
          metadata={'host':socket.gethostname(),'pid':os.getpid()}))
    except Exception as e:
        _infra_event28('cluster.startup_dependency_warning',NODE_ID28,{'detail':str(e)[:250]})


# ===== TAHAP 29 — DATABASE MIGRATION + SHARED QUEUE FOUNDATION =====
# Core SQLite execution remains the compatibility path until migration verification
# and a dedicated task-executor adapter are deployed. Redis queue publishing is opt-in.
import base64
V29_STREAM=os.getenv('NCK_V29_REDIS_STREAM','nck:v29:task-dispatch')
V29_GROUP=os.getenv('NCK_V29_REDIS_GROUP','nck-workers-v29')
V29_QUEUE_ENABLED=os.getenv('NCK_V29_QUEUE_ENABLED','0').lower() in ('1','true','yes','on')

class Dispatch29In(BaseModel):
    task_id:int=Field(ge=1)
    executor:str=Field(default='default',min_length=1,max_length=80)
    payload:dict=Field(default_factory=dict)

@app.get('/api/v29/migration/status')
def v29_migration_status(role=Depends(auth)):
    with conn() as c:
        tables=[x['name'] for x in c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()]
        dbfile=DB
        size=os.path.getsize(dbfile) if os.path.exists(dbfile) else 0
    return {'version':'29.0.0','source_database':'sqlite','source_path_configured':bool(dbfile),
      'source_size_bytes':size,'source_table_count':len(tables),'source_tables':tables,
      'postgres_target_configured':bool(POSTGRES_DSN28),'redis_configured':bool(REDIS_URL28),
      'distributed_dispatch_enabled':V29_QUEUE_ENABLED,
      'application_execution':'SQLite compatibility worker pool; not yet cut over to PostgreSQL',
      'migration_tool':'tools/migrate_sqlite_to_postgres.py','worker_service':'worker_service_v29.py'}

@app.post('/api/v29/dispatch')
def v29_dispatch(data:Dispatch29In,role=Depends(require_operator)):
    if not V29_QUEUE_ENABLED: raise HTTPException(503,'Redis dispatch dinonaktifkan. Set NCK_V29_QUEUE_ENABLED=1 setelah Redis dan worker adapter siap.')
    if not REDIS_URL28: raise HTTPException(503,'NCK_REDIS_URL belum dikonfigurasi.')
    with conn() as c:
        row=c.execute('SELECT status FROM task_runs_v23 WHERE task_id=?',(data.task_id,)).fetchone()
    if not row: raise HTTPException(404,'Task execution tidak ditemukan.')
    if row['status'] not in ('queued','failed'): raise HTTPException(409,'Hanya task queued/failed yang dapat didispatch.')
    try:
        r=_redis_client28()
        message={'task_id':str(data.task_id),'executor':data.executor,'payload':json.dumps(data.payload)[:12000],
          'submitted_at':now(),'submitted_by':role,'dispatch_id':uuid.uuid4().hex}
        mid=r.xadd(V29_STREAM,message)
    except Exception as e: raise HTTPException(503,'Redis dispatch gagal: '+str(e)[:200])
    audit(role,'v29.dispatch',f'task={data.task_id}; stream_id={mid}')
    return {'status':'published','task_id':data.task_id,'stream':V29_STREAM,'message_id':mid,'note':'Message tersedia untuk consumer; eksekusi AI belum dialihkan otomatis dari SQLite worker.'}

@app.get('/api/v29/queue/status')
def v29_queue_status(role=Depends(auth)):
    if not REDIS_URL28: return {'configured':False,'enabled':V29_QUEUE_ENABLED,'stream':V29_STREAM,'length':None,'consumer_groups':[]}
    try:
        r=_redis_client28(); length=r.xlen(V29_STREAM)
        try: groups=r.xinfo_groups(V29_STREAM)
        except Exception: groups=[]
        return {'configured':True,'enabled':V29_QUEUE_ENABLED,'stream':V29_STREAM,'length':length,'consumer_groups':groups}
    except Exception as e: return {'configured':True,'enabled':V29_QUEUE_ENABLED,'stream':V29_STREAM,'error':str(e)[:250]}

@app.get('/api/v29/status')
def v29_status(role=Depends(auth)):
    return {'version':'29.0.0','migration':'tooling_ready; production_cutover_requires_postgres_validation',
      'queue':'redis_stream_dispatch_foundation' if V29_QUEUE_ENABLED else 'disabled',
      'execution':'sqlite_compatibility_mode','multi_host_ai_execution':'not_enabled',
      'six_official_agents':[a['id'] for a in AGENTS_V21]}


# ===== TAHAP 30 — RELEASE RELIABILITY, BACKUP & READINESS =====
# This stage hardens the existing SQLite-compatible production path. It does NOT
# silently switch application data to PostgreSQL or claim multi-host AI execution.
from pathlib import Path as _Path30
from datetime import timedelta as _td30
V30_BACKUP_DIR=os.getenv('NCK_BACKUP_DIR',os.path.join(ROOT,'backups'))
V30_BACKUP_KEEP=max(1,min(int(os.getenv('NCK_BACKUP_KEEP','14')),90))

@app.get('/api/v30/health/ready')
def v30_ready(role=Depends(auth)):
    checks={}
    try:
        with conn() as c:
            c.execute('SELECT 1').fetchone()
            tables={x['name'] for x in c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        required={'tasks_v22','task_runs_v23','worker_leases_v27'}
        checks['application_database']={'ok':True,'engine':nck_db.BACKEND,'required_tables_present':sorted(required & tables),'required_tables_missing':sorted(required-tables)}
        checks['application_database']['ok']=not bool(required-tables)
    except Exception as e: checks['application_database']={'ok':False,'error':str(e)[:240]}
    checks['postgresql']={'configured':bool(os.getenv('NCK_POSTGRES_DSN')),'active_for_application_data':nck_db.IS_PG,'note':'Database utama aplikasi.' if nck_db.IS_PG else 'Belum menjadi database utama aplikasi (NCK_DB_BACKEND=sqlite).'}
    checks['redis']={'configured':bool(REDIS_URL28),'dispatch_enabled':V29_QUEUE_ENABLED}
    checks['ai_provider']={'openai_configured':bool(os.getenv('OPENAI_API_KEY')),'gemini_configured':bool(os.getenv('GEMINI_API_KEY'))}
    ready=checks['application_database']['ok']
    return {'version':'30.0.0','ready':ready,'mode':'sqlite_compatibility_release_candidate','checks':checks,'production_cutover_complete':False,'multi_host_ai_execution_active':False}

@app.get('/api/v30/ops/diagnostics')
def v30_diagnostics(role=Depends(require_operator)):
    with conn() as c:
        table_rows=c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()
        counts={}
        for row in table_rows:
            name=row['name']
            # Table names originate from sqlite_master, but quote safely.
            counts[name]=c.execute('SELECT COUNT(*) FROM "'+name.replace('"','""')+'"').fetchone()[0]
        run_counts={x:c.execute('SELECT COUNT(*) FROM task_runs_v23 WHERE status=?',(x,)).fetchone()[0] for x in ('queued','running','completed','failed')}
        agent_count=len(AGENTS_V21)
    return {'version':'30.0.0','database':nck_db.BACKEND,'table_count':len(counts),'row_counts':counts,'task_runs':run_counts,'official_agents_registered':agent_count,'backup_directory_configured':bool(V30_BACKUP_DIR),'backup_retention':V30_BACKUP_KEEP,'generated_at':now()}

@app.post('/api/v30/backup/create')
def v30_backup_create(role=Depends(require_operator)):
    if nck_db.IS_PG: raise HTTPException(501,'Backup SQLite tidak berlaku untuk PostgreSQL. Gunakan pg_dump / snapshot managed database dan uji restore-nya.')
    os.makedirs(V30_BACKUP_DIR,mode=0o700,exist_ok=True)
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    target=os.path.join(V30_BACKUP_DIR,f'nck_sqlite_{stamp}_{uuid.uuid4().hex[:8]}.db')
    source=conn(); dest=sqlite3.connect(target)
    try:
        source.backup(dest); dest.commit()
        check=dest.execute('PRAGMA integrity_check').fetchone()[0]
        if check!='ok': raise RuntimeError('SQLite integrity_check gagal: '+str(check))
    except Exception:
        dest.close(); source.close()
        try: os.remove(target)
        except OSError: pass
        raise HTTPException(500,'Backup gagal; file tidak dipertahankan.')
    finally:
        try: dest.close()
        except Exception: pass
        try: source.close()
        except Exception: pass
    digest=hashlib.sha256()
    with open(target,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): digest.update(chunk)
    size=os.path.getsize(target)
    files=sorted([os.path.join(V30_BACKUP_DIR,x) for x in os.listdir(V30_BACKUP_DIR) if x.startswith('nck_sqlite_') and x.endswith('.db')],key=os.path.getmtime,reverse=True)
    removed=[]
    for old in files[V30_BACKUP_KEEP:]:
        try: os.remove(old); removed.append(os.path.basename(old))
        except OSError: pass
    audit(role,'v30.backup.create',f'file={os.path.basename(target)}; bytes={size}; sha256={digest.hexdigest()}')
    return {'status':'created','filename':os.path.basename(target),'size_bytes':size,'sha256':digest.hexdigest(),'integrity_check':'ok','retention_keep':V30_BACKUP_KEEP,'old_backups_removed':len(removed),'created_at':now()}

@app.get('/api/v30/backup/list')
def v30_backup_list(role=Depends(require_operator)):
    if not os.path.isdir(V30_BACKUP_DIR): return {'items':[],'retention_keep':V30_BACKUP_KEEP}
    items=[]
    for name in sorted(os.listdir(V30_BACKUP_DIR),reverse=True):
        path=os.path.join(V30_BACKUP_DIR,name)
        if name.startswith('nck_sqlite_') and name.endswith('.db') and os.path.isfile(path):
            items.append({'filename':name,'size_bytes':os.path.getsize(path),'modified_at':datetime.fromtimestamp(os.path.getmtime(path),timezone.utc).isoformat()})
    return {'items':items[:100],'retention_keep':V30_BACKUP_KEEP}

@app.get('/api/v30/status')
def v30_status(role=Depends(auth)):
    return {'version':'30.0.0','release':'reliability_candidate','database_mode':'sqlite_compatibility','backup_api':True,'readiness_api':True,'postgres_application_cutover':False,'redis_multi_host_ai_execution':False,'official_agents':[a['id'] for a in AGENTS_V21]}


# ===== TAHAP 31 — SECURITY HARDENING & AUDIT CONTROLS =====
from collections import defaultdict, deque
from starlette.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

NCK_ENV31=os.getenv('NCK_ENV','development').strip().lower()
NCK_RATE_WINDOW31=max(10,min(int(os.getenv('NCK_RATE_WINDOW_SECONDS','60')),600))
NCK_RATE_LIMIT31=max(20,min(int(os.getenv('NCK_RATE_LIMIT','180')),3000))
NCK_EXPENSIVE_LIMIT31=max(2,min(int(os.getenv('NCK_EXPENSIVE_RATE_LIMIT','12')),300))
NCK_MAX_BODY31=max(1024,min(int(os.getenv('NCK_MAX_BODY_BYTES','1048576')),10485760))
_RATE_BUCKETS31=defaultdict(deque)
_RATE_LOCK31=threading.Lock()
_EXPENSIVE_PATHS31=('/api/orchestrate','/api/chat','/api/autonomous/run','/api/collaboration/run','/api/documents/upload','/api/intelligence/compare',
  '/api/v14/launch-approved','/api/v21/','/api/v23/','/api/v24/','/api/v29/','/api/v30/backup/create')
NCK_UPLOAD_MAX31=max(NCK_MAX_BODY31,min(int(os.getenv('NCK_UPLOAD_MAX_BYTES','12582912')),26214400))
_BIG_BODY_PATHS31=('/api/documents/upload','/api/v13/restore')

with conn() as _c31:
    _c31.execute("""CREATE TABLE IF NOT EXISTS security_events_v31(
      id INTEGER PRIMARY KEY AUTOINCREMENT, event TEXT NOT NULL, severity TEXT NOT NULL,
      client TEXT, path TEXT, detail TEXT, created_at TEXT NOT NULL)""")

def _security_event31(event,severity='info',client='',path='',detail=''):
    try:
        with conn() as c:
            c.execute('INSERT INTO security_events_v31(event,severity,client,path,detail,created_at) VALUES(?,?,?,?,?,?)',
                      (event,severity,str(client)[:120],str(path)[:240],str(detail)[:800],now()))
    except Exception:
        pass

def _rate_allowed31(key,limit):
    t=time.monotonic(); cutoff=t-NCK_RATE_WINDOW31
    with _RATE_LOCK31:
        q=_RATE_BUCKETS31[key]
        while q and q[0] < cutoff: q.popleft()
        if len(q)>=limit: return False, max(1,int(NCK_RATE_WINDOW31-(t-q[0])))
        q.append(t)
        # Bound memory for long-running dev instances.
        if len(_RATE_BUCKETS31)>10000:
            for k in list(_RATE_BUCKETS31)[:2000]:
                if not _RATE_BUCKETS31[k]: _RATE_BUCKETS31.pop(k,None)
        return True,0

@app.middleware('http')
async def nck_security_middleware31(request,call_next):
    client=request.client.host if request.client else 'unknown'
    path=request.url.path
    # Do not trust forwarded headers unless a trusted-proxy layer is explicitly deployed.
    content_length=request.headers.get('content-length')
    if content_length:
        try:
            if int(content_length)>(NCK_UPLOAD_MAX31+65536 if path in _BIG_BODY_PATHS31 else NCK_MAX_BODY31):
                return JSONResponse({'detail':'Ukuran request melewati batas.'},status_code=413)
        except ValueError:
            return JSONResponse({'detail':'Content-Length tidak valid.'},status_code=400)
    limit=NCK_EXPENSIVE_LIMIT31 if (any(path.startswith(p) for p in _EXPENSIVE_PATHS31) or path.endswith('/summarize')) else NCK_RATE_LIMIT31
    allowed,retry=_rate_allowed31((client,'expensive' if limit==NCK_EXPENSIVE_LIMIT31 else 'general'),limit)
    if not allowed:
        _security_event31('rate_limit.exceeded','warning',client,path,f'limit={limit}; window={NCK_RATE_WINDOW31}s')
        return JSONResponse({'detail':'Terlalu banyak permintaan. Coba kembali setelah jeda.'},status_code=429,headers={'Retry-After':str(retry)})
    try:
        response=await call_next(request)
    except Exception:
        _security_event31('request.exception','error',client,path,'Unhandled request exception')
        raise
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['X-Frame-Options']='DENY'
    response.headers['Referrer-Policy']='no-referrer'
    response.headers['Permissions-Policy']='camera=(), microphone=(), geolocation=()'
    response.headers['Cross-Origin-Resource-Policy']='same-site'
    response.headers['Cache-Control']='no-store' if path.startswith('/api/') else response.headers.get('Cache-Control','no-cache')
    response.headers['X-Request-ID']=request.headers.get('X-Request-ID',uuid.uuid4().hex)
    if request.url.scheme=='https' or os.getenv('NCK_FORCE_HTTPS','0')=='1':
        response.headers['Strict-Transport-Security']='max-age=31536000; includeSubDomains'
    return response

@app.on_event('startup')
def v31_security_startup():
    # Fail closed in production for weak/default role tokens and wildcard CORS.
    if NCK_ENV31=='production':
        problems=[]
        for var in ('NCK_VIEWER_TOKEN','NCK_OPERATOR_TOKEN','NCK_ADMIN_TOKEN'):
            val=os.getenv(var,'').strip()
            if len(val)<32 or val.lower().startswith('replace_with_'):
                problems.append(var+' must be a unique random secret of at least 32 characters')
        cors=[x.strip() for x in os.getenv('NCK_CORS_ORIGINS','').split(',') if x.strip()]
        if not cors or '*' in cors: problems.append('NCK_CORS_ORIGINS must contain exact trusted origins; wildcard is forbidden')
        if len({os.getenv(x,'').strip() for x in ('NCK_VIEWER_TOKEN','NCK_OPERATOR_TOKEN','NCK_ADMIN_TOKEN') if os.getenv(x,'').strip()})<3:
            problems.append('viewer/operator/admin tokens must all be distinct')
        # Tahap 35: token lama (rotasi) harus sama kuatnya dan tidak boleh sama dengan token saat ini peran mana pun.
        current={os.getenv(x,'').strip() for x in ('NCK_VIEWER_TOKEN','NCK_OPERATOR_TOKEN','NCK_ADMIN_TOKEN')}
        for var in ('NCK_VIEWER_TOKEN_PREVIOUS','NCK_OPERATOR_TOKEN_PREVIOUS','NCK_ADMIN_TOKEN_PREVIOUS'):
            val=os.getenv(var,'').strip()
            if val and len(val)<32: problems.append(var+' must be at least 32 characters (or be removed)')
            elif val and val in current: problems.append(var+' must differ from the current role tokens (remove it once rotation is finished)')
        if problems:
            raise RuntimeError('NCK production security configuration invalid: '+'; '.join(problems))
    _security_event31('security.startup','info','', '',f'env={NCK_ENV31}; rate_limit={NCK_RATE_LIMIT31}/{NCK_RATE_WINDOW31}s')

@app.get('/api/v31/security/status')
def v31_security_status(role=Depends(auth)):
    cors=[x.strip() for x in os.getenv('NCK_CORS_ORIGINS','').split(',') if x.strip()]
    token_status={name:bool(os.getenv(name,'')) for name in ('NCK_VIEWER_TOKEN','NCK_OPERATOR_TOKEN','NCK_ADMIN_TOKEN')}
    return {'version':'31.0.0','environment':NCK_ENV31,'security_controls':{
      'token_digest_comparison':'constant_time','role_tokens_configured':token_status,
      'cors_exact_allowlist':bool(cors) and '*' not in cors,'cors_origin_count':len(cors),
      'request_rate_limit':NCK_RATE_LIMIT31,'rate_window_seconds':NCK_RATE_WINDOW31,
      'expensive_route_limit':NCK_EXPENSIVE_LIMIT31,'max_body_bytes':NCK_MAX_BODY31,
      'security_headers':True,'hsts':'https_or_force_https','rate_limit_storage':'in_process_memory'},
      'production_config_validated_at_startup':NCK_ENV31=='production',
      'limitations':['Rate limiting is per process; deploy shared gateway/WAF or Redis limiter for multi-instance production.','TLS must terminate at a trusted reverse proxy/load balancer.','Access tokens remain environment-managed; rotate them through deployment secret management.']}

@app.get('/api/v31/security/events')
def v31_security_events(limit:int=50,role=Depends(auth)):
    if role!='admin': raise HTTPException(403,'Hak Admin diperlukan untuk membaca event keamanan.')
    limit=max(1,min(limit,200))
    with conn() as c:
        rows=c.execute('SELECT event,severity,client,path,detail,created_at FROM security_events_v31 ORDER BY id DESC LIMIT ?', (limit,)).fetchall()
    return {'items':[dict(x) for x in rows]}

@app.post('/api/v31/security/test-event')
def v31_security_test_event(role=Depends(require_operator)):
    audit(role,'v31.security.test_event','Operator initiated security audit test')
    _security_event31('security.test_event','info','operator','/api/v31/security/test-event','Manual audit test')
    return {'status':'recorded','event':'security.test_event'}

@app.get('/api/v31/status')
def v31_status(role=Depends(auth)):
    return {'version':'31.0.0','stage':'security_hardening','status':'implemented_local_controls',
      'security_status_endpoint':'/api/v31/security/status','admin_security_events_endpoint':'/api/v31/security/events',
      'production_ready':False,'reason':'Shared rate limiter, production TLS/WAF, external pentest and secret rotation drills remain deployment tasks.'}


# ===== TAHAP 32 — POSTGRESQL MIGRATION READINESS & CONTROLLED CUTOVER GATES =====
@app.get('/api/v32/status')
def v32_status(role=Depends(auth)):
    return {'stage':32,'module':'postgresql_migration_readiness','application_database':nck_db.BACKEND,'postgres_cutover':'enabled' if nck_db.IS_PG else 'not_enabled','safe_to_cutover':False}

@app.get('/api/v32/database/readiness')
def v32_database_readiness(role=Depends(require_operator)):
    # Read-only diagnostics; this endpoint never changes DATABASE_URL or switches storage.
    if nck_db.IS_PG: return v33_database_adapter(role)
    with conn() as c:
        tables=[r['name'] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()]
        counts={}
        for name in tables:
            safe=name.replace('"','""')
            counts[name]=c.execute(f'SELECT COUNT(*) n FROM "{safe}"').fetchone()['n']
        fk_issues=[dict(x) for x in c.execute('PRAGMA foreign_key_check').fetchall()]
        integrity=c.execute('PRAGMA integrity_check').fetchone()[0]
    pg={'configured':bool(os.getenv('NCK_POSTGRES_DSN','').strip()),'reachable':False,'schema':'public','tables':{},'error':None}
    dsn=os.getenv('NCK_POSTGRES_DSN','').strip()
    if dsn:
        try:
            import psycopg
            with psycopg.connect(dsn,connect_timeout=3) as p:
                with p.cursor() as cur:
                    cur.execute('SELECT current_database(), current_schema(), version()')
                    row=cur.fetchone(); pg.update({'reachable':True,'database':row[0],'schema':row[1],'server_version':row[2].split(',')[0]})
                    cur.execute("SELECT table_name FROM information_schema.tables WHERE table_schema=current_schema() AND table_type='BASE TABLE' AND table_name NOT LIKE 'pg_%' AND table_name <> 'sql_features' ORDER BY table_name")
                    for (name,) in cur.fetchall():
                        cur.execute('SELECT COUNT(*) FROM '+('"'+name.replace('"','""')+'"'))
                        pg['tables'][name]=cur.fetchone()[0]
        except Exception as e: pg['error']=type(e).__name__+': '+str(e)[:240]
    else: pg['error']='NCK_POSTGRES_DSN belum dikonfigurasi.'
    return {'stage':32,'sqlite':{'path':DB,'integrity':integrity,'tables':counts,'foreign_key_issues':fk_issues},'postgres':pg,
      'migration_gate':{'source_integrity_ok':integrity=='ok','source_foreign_keys_ok':len(fk_issues)==0,'postgres_reachable':pg['reachable'],'cutover_enabled':False,
        'reason':'Aplikasi masih memakai adapter SQLite. Cutover ditahan sampai adapter PostgreSQL seluruh modul lulus regression test dan proses migrasi diverifikasi.'}}


# ===== TAHAP 34 — BACKEND PANEL LAMA (TAHAP 6-15), 50 AGEN, DOKUMEN, KNOWLEDGE, COMMAND CENTER =====
import nck_legacy_v34
nck_legacy_v34.register(app,conn=conn,auth=auth,require_operator=require_operator,audit=audit,now=now,llm=llm_call_v21,
  systems_by_number={a["number"]:a["system"] for a in AGENTS_V21},service=SERVICE)

# ===== TAHAP 33 — ADAPTER DATABASE RUNTIME (SQLITE DEFAULT, POSTGRESQL OPT-IN) =====
@app.get('/api/v33/status')
def v33_status(role=Depends(auth)):
    return {'stage':33,'module':'postgresql_runtime_adapter','application_database':nck_db.BACKEND,
      'default_backend':'sqlite','postgres_runtime_enabled':nck_db.IS_PG,'postgres_dsn_configured':bool(os.getenv('NCK_POSTGRES_DSN','').strip()),
      'postgres_schema':nck_db.PG_SCHEMA if nck_db.IS_PG else None,'production_ready':False,
      'reason':'Adapter diuji pada PostgreSQL 16 lokal; uji beban, konkurensi multi-worker, failover, dan restore backup PostgreSQL masih wajib sebelum produksi.'}

@app.get('/api/v33/database/adapter')
def v33_database_adapter(role=Depends(require_operator)):
    out={'stage':33,'backend':nck_db.BACKEND,'health':nck_db.health(),'tables':{},'identity_sequences':[]}
    with conn() as c:
        names=[r['name'] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()]
        for n in names: out['tables'][n]=c.execute('SELECT COUNT(*) FROM "'+n.replace('"','""')+'"').fetchone()[0]
        out['identity_sequences']=nck_db.identity_status(c)
    out['identity_sequences_ok']=all(x['ok'] for x in out['identity_sequences'])
    out['note']='Pada SQLite, identity_sequences kosong (rowid otomatis). Pada PostgreSQL, ok=false berarti sequence tertinggal dari data dan INSERT baru akan bentrok.'
    return out

@app.on_event('startup')
def startup_v33_sync_sequences():
    # Jaring pengaman: sequence identity yang tertinggal dari data dinaikkan (tidak pernah diturunkan).
    fixed=nck_db.sync_identity_sequences()
    if fixed: _security_event31('db.identity_sequence_synced','info','','',json.dumps(fixed)[:700])


# ===== TAHAP 35 — OPERASI PRODUKSI (READY, KESIAPAN, METRIK, LAPORAN BACKUP) =====
nck_ops_v35.register(app,conn=conn,auth=auth,require_operator=require_operator,audit=audit,now=now,backend=nck_db.BACKEND,service=SERVICE)
