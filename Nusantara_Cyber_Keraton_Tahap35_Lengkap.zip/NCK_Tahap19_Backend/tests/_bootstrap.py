"""Bootstrap uji: pakai paket asli bila terpasang; jika tidak (sandbox tanpa internet), pakai stub/shim.
Di CI (requirements.txt terpasang) tidak ada stub yang dipakai: FastAPI dan psycopg ASLI."""
import os
import sys
import types

HERE = os.path.dirname(os.path.abspath(__file__))
BACK = os.path.dirname(HERE)
USING = {'fastapi': 'asli', 'httpx': 'asli', 'psycopg': 'asli'}


def _stub_fastapi():
    class HTTPException(Exception):
        def __init__(self, status_code, detail=None):
            super().__init__(detail)
            self.status_code, self.detail = status_code, detail

    class _Router:
        """Meniru Starlette: lifespan_context menjalankan handler startup lalu (saat keluar) handler shutdown."""
        def __init__(self, app):
            self._app = app

        def lifespan_context(self, app):
            import inspect
            outer = self

            class _Ctx:
                async def __aenter__(self_):
                    for h in list(outer._app.startup):
                        r = h()
                        if inspect.isawaitable(r):
                            await r
                    return self_

                async def __aexit__(self_, *exc):
                    for h in list(outer._app.shutdown):
                        r = h()
                        if inspect.isawaitable(r):
                            await r
            return _Ctx()

    class FastAPI:
        def __init__(self, *a, **k):
            self.startup, self.shutdown, self.routes = [], [], {}
            self.router = _Router(self)

        def on_event(self, name):
            def d(f):
                (self.startup if name == 'startup' else self.shutdown).append(f)
                return f
            return d

        def middleware(self, t):
            return lambda f: f

        def add_middleware(self, *a, **k):
            pass

        def _r(m):
            def r(self, path, **k):
                def d(f):
                    self.routes[(m, path)] = f
                    return f
                return d
            return r
        get, post, put, delete, patch = _r('GET'), _r('POST'), _r('PUT'), _r('DELETE'), _r('PATCH')

    fa = types.ModuleType('fastapi')
    fa.FastAPI, fa.HTTPException = FastAPI, HTTPException
    fa.Header = lambda default=None, **k: default
    fa.Depends = lambda f=None: f
    fa.BackgroundTasks = type('BackgroundTasks', (), {})
    fa.Request = type('Request', (), {})
    cors = types.ModuleType('fastapi.middleware.cors')
    cors.CORSMiddleware = object
    sys.modules.update({'fastapi': fa, 'fastapi.middleware': types.ModuleType('fastapi.middleware'),
                        'fastapi.middleware.cors': cors})


def install():
    sys.path.insert(0, BACK)
    try:
        import fastapi  # noqa: F401
    except ImportError:
        _stub_fastapi()
        USING['fastapi'] = 'STUB (handler dipanggil langsung)'
    try:
        import httpx  # noqa: F401
    except ImportError:
        sys.modules['httpx'] = types.ModuleType('httpx')
        USING['httpx'] = 'STUB'
    try:
        import psycopg  # noqa: F401
    except ImportError:
        sys.path.insert(0, HERE + '/pg_shim')
        USING['psycopg'] = 'SHIM psql (bukan driver produksi)'
    return USING


def pythonpath_for_children():
    """PYTHONPATH untuk subprocess (CLI migrasi) agar memakai shim bila psycopg asli tidak ada."""
    try:
        import psycopg  # noqa: F401
        if 'shim' in (getattr(psycopg, '__file__', '') or ''):
            return HERE + '/pg_shim'
        return ''
    except ImportError:
        return HERE + '/pg_shim'


def endpoint(M, method, path):
    """Ambil fungsi endpoint dari app (stub atau FastAPI asli)."""
    routes = M.app.routes
    if isinstance(routes, dict):
        return routes[(method, path)]
    for r in routes:
        if getattr(r, 'path', None) == path and method in getattr(r, 'methods', ()):
            return r.endpoint
    raise KeyError((method, path))


def startup_handlers(M):
    if hasattr(M.app, 'startup'):
        return list(M.app.startup)
    return [h for h in M.app.router.on_startup]
