"""Uji eksekusi AI terdistribusi (Tahap 34) — PROSES OS NYATA berbagi satu PostgreSQL.

Skenario (tiap tahap memakai proses terpisah `worker_service_v34.py` + LLM palsu yang menulis jejak panggilan):
  P0  dua worker start serentak pada skema KOSONG (balapan pembuatan skema + retry startup)
  P1  20 tugas diperebutkan 4 slot lintas 2 proses -> tiap tugas diklaim & dieksekusi tepat sekali
  P2  shutdown terkendali (SIGTERM) di tengah tugas -> tugas langsung kembali ke antrean, worker lain menuntaskan
  P3a eksekusi LEBIH LAMA dari ambang basi -> heartbeat menjaga lease; worker lain TIDAK boleh mencuri
  P3b kill -9 di tengah tugas -> worker lain memulihkan setelah heartbeat basi, tugas selesai (at-least-once)

Butuh PostgreSQL: env NCK_TEST_PG_DSN (default shim lokal: postgresql://postgres@/nck_test).
Waktu jalan: sekitar 2-3 menit. Keluar dengan kode 1 bila ada cek gagal."""
import asyncio
import json
import os
import re
import signal
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
BACK = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import _bootstrap  # noqa: E402

DSN = os.environ.get('NCK_TEST_PG_DSN', 'postgresql://postgres@/nck_test')
S = 'nck_t34_dist'
STALE = 15
BEAT = 2


# ------------------------------------------------------------------ anak: worker / seed / status
def _base_env_inplace():
    for k in ('OPENAI_API_KEY', 'GEMINI_API_KEY'):
        os.environ.pop(k, None)


def child_worker(label):
    _base_env_inplace()
    _bootstrap.install()
    import worker_service_v34 as W
    calls = os.environ['NCK_TEST_CALLS']
    delay = float(os.environ.get('NCK_TEST_DELAY', '0.3'))

    async def fake(provider, system, user, model=None):
        m = re.search(r'JUDUL: (.*)', user)
        title = m.group(1).strip() if m else '?'
        fd = os.open(calls, os.O_WRONLY | os.O_APPEND | os.O_CREAT)
        os.write(fd, f'{os.getpid()}\t{label}\t{title}\n'.encode())
        os.close(fd)
        await asyncio.sleep(delay)
        return 'HASIL ' + title, {'prompt_tokens': 1, 'completion_tokens': 1}
    W.main.llm_call_v21 = fake
    W.run()


def child_seed(n, prefix):
    _base_env_inplace()
    _bootstrap.install()
    import main as M
    ep = lambda m, p: _bootstrap.endpoint(M, m, p)  # noqa: E731

    for h in _bootstrap.startup_handlers(M):
        h()
    try:
        ep('POST', '/api/v22/projects')(data=M.Project22In(name='Alpha', description='Proyek'), role='admin')
    except M.HTTPException:
        pass
    for i in range(1, n + 1):
        ep('POST', '/api/v22/tasks')(data=M.Task22In(project='Alpha', title=f'{prefix}-{i}', instruction=f'Instruksi {prefix}-{i}',
                                                      agent_id='ki_mandra', priority='normal'), role='admin')
    # antrekan semua tugas sekaligus dalam SATU transaksi (dispatch API dibatasi 10 per panggilan; yang diuji di sini perebutan antrean)
    with M.conn() as c:
        ids = [r['id'] for r in c.execute('SELECT id FROM tasks_v22 WHERE title LIKE ? ORDER BY id', (prefix + '-%',)).fetchall()]
        for tid in ids:
            c.execute("INSERT INTO task_runs_v23(task_id,status,provider,max_retries,review_enabled,review_threshold,created_at) "
                      "VALUES(?,'queued','openai',0,0,75,?)", (tid, M.now()))
            c.execute("UPDATE tasks_v22 SET status='assigned',updated_at=? WHERE id=?", (M.now(), tid))
    r = {'dispatched': len(ids)}
    print('RESULT:' + json.dumps({'dispatched': r['dispatched']}))
    sys.stdout.flush()
    os._exit(0)


def child_status():
    _base_env_inplace()
    _bootstrap.install()
    import main as M
    st = _bootstrap.endpoint(M, 'GET', '/api/v34/distributed/status')(role='viewer')
    print('RESULT:' + json.dumps(st, default=str))
    sys.stdout.flush()
    os._exit(0)


# ------------------------------------------------------------------ orkestrator
RESULTS = []
PROCS = {}
WORK = tempfile.mkdtemp(prefix='nck_dist_')
CALLS = os.path.join(WORK, 'calls.log')


def check(name, cond, detail=''):
    RESULTS.append((name, bool(cond), detail))
    print(('PASS  ' if cond else 'FAIL  ') + name + ('' if cond else '   :: ' + str(detail)[:300]), flush=True)


def env_for(extra=None):
    env = dict(os.environ)
    pp = _bootstrap.pythonpath_for_children()
    if pp:
        env['PYTHONPATH'] = pp + os.pathsep + env.get('PYTHONPATH', '')
    env.update({'NCK_DB_BACKEND': 'postgres', 'NCK_POSTGRES_DSN': DSN, 'NCK_POSTGRES_SCHEMA': S,
                'NCK_DB_PATH': WORK + '/unused.db', 'NCK_BACKUP_DIR': WORK + '/b', 'NCK_TEST_PG_DSN': DSN,
                'NCK_WORKER_STALE_SECONDS': str(STALE), 'NCK_WORKER_HEARTBEAT_SECONDS': str(BEAT),
                'NCK_SHUTDOWN_GRACE_SECONDS': '2', 'NCK_TEST_CALLS': CALLS, 'PYTHONUNBUFFERED': '1'})
    env.update(extra or {})
    return env


def start_worker(label, delay=0.3, conc=2):
    log = open(os.path.join(WORK, f'{label}.log'), 'w')
    p = subprocess.Popen([sys.executable, __file__, '--child', 'worker', label], stdout=log, stderr=subprocess.STDOUT,
                         env=env_for({'NCK_TEST_DELAY': str(delay), 'NCK_WORKER_CONCURRENCY': str(conc)}))
    PROCS[label] = p
    return p


def run_child(args, mode='api', timeout=180):
    p = subprocess.run([sys.executable, __file__, '--child'] + args, capture_output=True, text=True, timeout=timeout,
                       env=env_for({'NCK_WORKER_MODE': mode, 'NCK_WORKER_CONCURRENCY': '1'}))
    for line in reversed(p.stdout.splitlines()):
        if line.startswith('RESULT:'):
            return json.loads(line[7:]), p
    return None, p


def stop(label, sig=signal.SIGTERM, timeout=25):
    p = PROCS[label]
    if p.poll() is None:
        p.send_signal(sig)
    t0 = time.time()
    try:
        p.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        p.kill()
        p.wait()
    return p.returncode, time.time() - t0


def pg(sql, params=None):
    import psycopg
    with psycopg.connect(DSN) as c:
        cur = c.cursor()
        cur.execute(sql, params)
        try:
            return cur.fetchall()
        except Exception:  # noqa: BLE001
            return None


def wait_for(fn, timeout, interval=0.5):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            v = fn()
        except Exception:  # noqa: BLE001
            v = None
        if v:
            return v
        time.sleep(interval)
    return None


def calls_for(prefix):
    if not os.path.exists(CALLS):
        return []
    out = []
    for line in open(CALLS):
        pid, label, title = line.rstrip('\n').split('\t')
        if title.startswith(prefix):
            out.append((int(pid), label, title))
    return out


def counts():
    rows = pg(f'SELECT status, COUNT(*) FROM {S}.task_runs_v23 GROUP BY status')
    return {r[0]: r[1] for r in rows}


def run_of(title):
    rows = pg(f'SELECT r.task_id, r.status, r.output FROM {S}.task_runs_v23 r JOIN {S}.tasks_v22 t ON t.id=r.task_id WHERE t.title=%s', (title,))
    return rows[0] if rows else None


def lease_owner(task_id):
    rows = pg(f'SELECT worker_id FROM {S}.worker_leases_v27 WHERE task_id=%s', (task_id,))
    return rows[0][0] if rows else None


def events(event, task_id=None):
    if task_id is None:
        return pg(f'SELECT task_id, worker_id, detail FROM {S}.queue_events_v27 WHERE event=%s', (event,))
    return pg(f'SELECT task_id, worker_id, detail FROM {S}.queue_events_v27 WHERE event=%s AND task_id=%s', (event, task_id))


def scenario():
    pg(f'DROP SCHEMA IF EXISTS {S} CASCADE')
    # ---------- P0: start serentak pada skema kosong
    start_worker('A')
    start_worker('B')
    ok = wait_for(lambda: len(pg(f'SELECT worker_id FROM {S}.worker_registry_v27')) >= 4, 120, 1)
    check('P0 dua worker start serentak pada skema kosong (4 slot terdaftar)', ok, open(WORK + '/A.log').read()[-300:] + open(WORK + '/B.log').read()[-300:])
    check('P0 kedua proses tetap hidup', PROCS['A'].poll() is None and PROCS['B'].poll() is None)

    # ---------- P1: perebutan antrean
    res, p = run_child(['seed', '20', 'P1'])
    check('P1 seed 20 tugas masuk antrean', res and res['dispatched'] == 20, p.stderr[-300:])
    done = wait_for(lambda: counts().get('completed', 0) >= 20, 120, 1)
    check('P1 semua 20 tugas selesai', done, counts())
    c1 = calls_for('P1-')
    titles = [t for _, _, t in c1]
    check('P1 tiap tugas dieksekusi tepat sekali', len(titles) == 20 and len(set(titles)) == 20, f'{len(titles)} panggilan, {len(set(titles))} unik')
    check('P1 kedua proses ikut bekerja (pembagian beban)', len({pid for pid, _, _ in c1}) == 2, {pid for pid, _, _ in c1})
    cl = {r[0]: r[1] for r in pg(f"SELECT task_id, COUNT(*) FROM {S}.queue_events_v27 WHERE event='worker.claimed' GROUP BY task_id")}
    check('P1 tiap tugas diklaim tepat satu kali', len(cl) == 20 and all(v == 1 for v in cl.values()), cl)
    check('P1 lease bersih setelah selesai', pg(f'SELECT COUNT(*) FROM {S}.worker_leases_v27')[0][0] == 0)
    check('P1 tak ada pemulihan yatim palsu', len(events('worker.orphan_recovered')) == 0, events('worker.orphan_recovered'))
    st, p = run_child(['status'])
    check('P1 status terdistribusi: 4 worker hidup, mode api, aman multi-proses',
          st and st['workers_alive'] == 4 and st['mode'] == 'api' and st['multi_process_safe'] is True and st['queue']['completed'] >= 20, st)

    # ---------- P2: shutdown terkendali saat idle, lalu di tengah tugas
    rcA, _ = stop('A')
    rcB, _ = stop('B')
    check('P2 shutdown terkendali saat idle: kode keluar 0', rcA == 0 and rcB == 0, (rcA, rcB))
    check('P2 registry kosong setelah worker berhenti', pg(f'SELECT COUNT(*) FROM {S}.worker_registry_v27')[0][0] == 0)
    start_worker('G', delay=30, conc=1)
    wait_for(lambda: len(pg(f'SELECT worker_id FROM {S}.worker_registry_v27')) >= 1, 60, 1)
    res, p = run_child(['seed', '1', 'P2'])
    r2 = wait_for(lambda: (lambda r: r if r and r[1] == 'running' else None)(run_of('P2-1')), 60, 0.5)
    check('P2 tugas berjalan di worker G', r2, run_of('P2-1'))
    tid2 = r2[0] if r2 else -1
    wait_for(lambda: any(x[1] == 'G' for x in calls_for('P2-1')), 60, 0.2)  # pastikan G benar-benar sudah memanggil LLM
    rcG, dt = stop('G')
    check('P2 worker G keluar terkendali (kode 0) dalam batas grace', rcG == 0 and dt < 20, (rcG, round(dt, 1)))
    after = run_of('P2-1')
    check('P2 tugas segera kembali ke antrean (queued)', after and after[1] == 'queued', after)
    check('P2 kejadian released_on_shutdown tercatat', len(events('worker.released_on_shutdown', tid2)) == 1, events('worker.released_on_shutdown'))
    check('P2 lease milik G dilepas', lease_owner(tid2) is None)
    start_worker('H', delay=0.3, conc=2)
    done = wait_for(lambda: (lambda r: r and r[1] == 'completed')(run_of('P2-1')), 90, 1)
    check('P2 tugas dituntaskan worker lain (H)', done, run_of('P2-1'))
    c2 = calls_for('P2-1')
    check('P2 dieksekusi dua kali (G lalu H) — semantik at-least-once', len(c2) == 2 and c2[0][1] == 'G' and c2[1][1] == 'H', c2)
    check('P2 hasil tercatat dari H', (run_of('P2-1') or [0, 0, ''])[2] == 'HASIL P2-1')

    # ---------- P3a: eksekusi lebih lama dari ambang basi tidak boleh dicuri
    stop('H')
    start_worker('C', delay=STALE + 5, conc=1)
    wait_for(lambda: len(pg(f'SELECT worker_id FROM {S}.worker_registry_v27')) >= 1, 60, 1)
    res, p = run_child(['seed', '1', 'P3a'])
    r3 = wait_for(lambda: (lambda r: r if r and r[1] == 'running' else None)(run_of('P3a-1')), 60, 0.5)
    check('P3a tugas berjalan di worker C', r3, run_of('P3a-1'))
    t_run = time.time()
    start_worker('D', delay=0.3, conc=1)
    done = wait_for(lambda: (lambda r: r and r[1] == 'completed')(run_of('P3a-1')), 120, 1)
    el = time.time() - t_run
    check('P3a tugas selesai', done, run_of('P3a-1'))
    check('P3a eksekusi benar-benar lebih lama dari ambang basi', el > STALE + 1, round(el, 1))
    check('P3a TIDAK dicuri worker lain: dieksekusi sekali oleh C', [x[1] for x in calls_for('P3a-1')] == ['C'], calls_for('P3a-1'))
    check('P3a tak ada kejadian orphan_recovered untuk tugas ini', len(events('worker.orphan_recovered', r3[0] if r3 else -1)) == 0)
    check('P3a C dan D masih hidup', PROCS['C'].poll() is None and PROCS['D'].poll() is None)

    # ---------- P3b: kill -9 di tengah tugas
    stop('D')
    res, p = run_child(['seed', '1', 'P3b'])
    r4 = wait_for(lambda: (lambda r: r if r and r[1] == 'running' else None)(run_of('P3b-1')), 60, 0.5)
    check('P3b tugas berjalan di worker C', r4, run_of('P3b-1'))
    tid4 = r4[0] if r4 else -1
    wait_for(lambda: any(x[1] == 'C' for x in calls_for('P3b-1')), 60, 0.2)  # pastikan C sudah memanggil LLM sebelum dibunuh
    owner = lease_owner(tid4)
    PROCS['C'].send_signal(signal.SIGKILL)
    PROCS['C'].wait()
    t_kill = time.time()
    check('P3b C dimatikan paksa (kill -9)', PROCS['C'].returncode == -signal.SIGKILL, PROCS['C'].returncode)
    check('P3b tepat setelah kill: tugas masih tercatat running (belum langsung dicuri)', (run_of('P3b-1') or [0, ''])[1] == 'running')
    start_worker('E', delay=0.3, conc=2)
    done = wait_for(lambda: (lambda r: r and r[1] == 'completed')(run_of('P3b-1')), 150, 1)
    rec = time.time() - t_kill
    check('P3b tugas dipulihkan dan selesai oleh worker lain', done, run_of('P3b-1'))
    check('P3b tidak dipulihkan sebelum heartbeat basi', rec > STALE - 5, round(rec, 1))
    ev = events('worker.orphan_recovered', tid4)
    check('P3b kejadian orphan_recovered mencatat worker yang mati', len(ev) == 1 and ev[0][1] == owner, (ev, owner))
    c4 = calls_for('P3b-1')
    check('P3b dieksekusi dua kali: C (mati) lalu E', len(c4) == 2 and c4[0][1] == 'C' and c4[1][1] == 'E', c4)
    check('P3b registry worker mati dibersihkan', pg(f'SELECT COUNT(*) FROM {S}.worker_registry_v27 WHERE worker_id LIKE %s', (owner.rsplit('-', 1)[0] + '-%',))[0][0] == 0 if owner else False)
    check('P3b tidak ada run menggantung', counts().get('running', 0) == 0 and counts().get('queued', 0) == 0, counts())
    check('P3b lease bersih', pg(f'SELECT COUNT(*) FROM {S}.worker_leases_v27')[0][0] == 0)
    stop('E')


def main():
    using = _bootstrap.install()
    print('Pustaka uji:', using, '\nDSN:', DSN.split('@')[-1], '\n', flush=True)
    t0 = time.time()
    try:
        scenario()
    finally:
        for lbl, p in PROCS.items():
            if p.poll() is None:
                p.kill()
        bad = [r for r in RESULTS if not r[1]]
        if bad:
            for f in sorted(os.listdir(WORK)):
                if f.endswith('.log') and f != 'calls.log':
                    print(f'--- {f} (ekor) ---\n' + open(os.path.join(WORK, f)).read()[-900:], flush=True)
        try:
            pg(f'DROP SCHEMA IF EXISTS {S} CASCADE')
        except Exception:  # noqa: BLE001
            pass
    ok = sum(1 for r in RESULTS if r[1])
    print(f'\nRINGKAS: {ok}/{len(RESULTS)} lulus ({time.time() - t0:.0f} dtk)', flush=True)
    sys.exit(0 if ok == len(RESULTS) else 1)


if __name__ == '__main__':
    if len(sys.argv) > 2 and sys.argv[1] == '--child':
        m = sys.argv[2]
        if m == 'worker':
            child_worker(sys.argv[3])
        elif m == 'seed':
            child_seed(int(sys.argv[3]), sys.argv[4])
        elif m == 'status':
            child_status()
    else:
        main()
