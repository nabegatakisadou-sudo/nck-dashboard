"""Uji backend panel lama Tahap 34 pada SQLite dan (bila tersedia) PostgreSQL.

LLM diganti fungsi palsu deterministik HANYA di tes ini; tidak ada panggilan jaringan.
Jalankan dari NCK_Tahap19_Backend:  python tests/test_legacy_v34.py
PostgreSQL: set NCK_TEST_PG_DSN (schema nck_t34_* dibuat lalu dihapus). Tanpa itu hanya SQLite.
"""
import asyncio
import io
import json
import os
import subprocess
import sys
import tempfile
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import _bootstrap  # noqa: E402

DSN = os.environ.get('NCK_TEST_PG_DSN', '')


# ------------------------------------------------------------------ anak: satu backend penuh
def child(backend, schema):
    work = tempfile.mkdtemp()
    for k in ('OPENAI_API_KEY', 'GEMINI_API_KEY'):
        os.environ.pop(k, None)
    env = {'NCK_DB_BACKEND': backend, 'NCK_DB_PATH': work + '/t.db', 'NCK_BACKUP_DIR': work + '/b', 'NCK_WORKER_CONCURRENCY': '1',
           'NCK_ADMIN_TOKEN': 'a' * 40, 'NCK_OPERATOR_TOKEN': 'o' * 40, 'NCK_VIEWER_TOKEN': 'v' * 40}
    if backend == 'postgres':
        env.update({'NCK_POSTGRES_DSN': DSN, 'NCK_POSTGRES_SCHEMA': schema})
    os.environ.update(env)
    _bootstrap.install()
    import main as M
    import nck_legacy_v34 as L
    from fastapi import HTTPException
    for h in _bootstrap.startup_handlers(M):
        h()
    out = {}
    ep = lambda m, p: _bootstrap.endpoint(M, m, p)  # noqa: E731

    def chk(name, cond):
        out[name] = bool(cond)

    def raises(code, fn, *a, **k):
        try:
            fn(*a, **k)
            return False
        except HTTPException as e:
            return e.status_code == code

    async def araises(code, coro):
        try:
            await coro
            return False
        except HTTPException as e:
            return e.status_code == code

    # ---- LLM palsu
    CALLS, FAIL = [], {'agents': set(), 'once': set(), 'unconfigured': False, 'review': [], 'seen': set()}

    async def fake_llm(provider, system, user, model=None):
        CALLS.append((provider, model))
        if FAIL['unconfigured']:
            raise RuntimeError('GEMINI_API_KEY belum dikonfigurasi pada environment backend.')
        if 'reviewer AI independen' in system:
            sc = FAIL['review'].pop(0) if FAIL['review'] else 90
            return json.dumps({'score': sc, 'feedback': 'umpan balik uji'}), {'prompt_tokens': 11, 'completion_tokens': 7}
        for nm in FAIL['agents']:
            if nm in system:
                raise RuntimeError('simulasi kegagalan ' + nm)
        for nm in list(FAIL['once']):
            if nm in system and nm not in FAIL['seen']:
                FAIL['seen'].add(nm)
                raise RuntimeError('gagal sekali ' + nm)
        return f'HASIL[{provider}|{model}] ' + user[-30:].replace('\n', ' '), {'prompt_tokens': 0, 'completion_tokens': 0}
    L.STATE['llm'] = fake_llm

    class BG:
        def __init__(self):
            self.jobs = []

        def add_task(self, fn, *a, **k):
            self.jobs.append((fn, a, k))

        async def run(self):
            for fn, a, k in self.jobs:
                await fn(*a, **k)
            self.jobs = []

    class Req:
        def __init__(self, body, ctype, clen=None):
            self.body = body
            self.headers = {'content-type': ctype, 'content-length': str(len(body) if clen is None else clen)}

        async def stream(self):
            for i in range(0, len(self.body), 65536):
                yield self.body[i:i + 65536]

    def multipart(fields, fname, data):
        b = b'UJI1234xyz'
        parts = []
        for k, v in fields.items():
            parts.append(b'--' + b + b'\r\nContent-Disposition: form-data; name="' + k.encode() + b'"\r\n\r\n' + v.encode() + b'\r\n')
        parts.append(b'--' + b + b'\r\nContent-Disposition: form-data; name="file"; filename="' + fname.encode() + b'"\r\nContent-Type: application/octet-stream\r\n\r\n' + data + b'\r\n')
        parts.append(b'--' + b + b'--\r\n')
        return b''.join(parts), 'multipart/form-data; boundary=UJI1234xyz'

    def make_docx(text):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w') as z:
            z.writestr('word/document.xml', '<w:document><w:body>' + ''.join(f'<w:p><w:r><w:t>{ln}</w:t></w:r></w:p>' for ln in text.split('\n')) + '</w:body></w:document>')
        return buf.getvalue()

    def make_pdf(text):
        objs = ['<< /Type /Catalog /Pages 2 0 R >>', '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
                '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 144] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>']
        stream = f'BT /F1 18 Tf 20 80 Td ({text}) Tj ET'
        objs.append(f'<< /Length {len(stream)} >>\nstream\n{stream}\nendstream')
        objs.append('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>')
        pdf, offs = '%PDF-1.4\n', []
        for i, o in enumerate(objs, 1):
            offs.append(len(pdf))
            pdf += f'{i} 0 obj\n{o}\nendobj\n'
        xref = len(pdf)
        pdf += f'xref\n0 {len(objs) + 1}\n0000000000 65535 f \n' + ''.join(f'{o:010d} 00000 n \n' for o in offs)
        pdf += f'trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n'
        return pdf.encode('latin-1')

    async def main():
        # ---------------------------------------------------------------- RBAC statis (kabel dependensi tiap route)
        def dep_of(method, path):
            f = ep(method, path)
            d = __import__('inspect').signature(f).parameters.get('role')
            d = d.default if d is not None else None
            return getattr(d, 'dependency', d)
        want_op = [('POST', '/api/chat'), ('POST', '/api/orchestrate'), ('POST', '/api/knowledge'), ('DELETE', '/api/knowledge/{kid}'),
                   ('POST', '/api/documents/upload'), ('DELETE', '/api/documents/{did}'), ('POST', '/api/documents/{did}/summarize'),
                   ('POST', '/api/intelligence/compare'), ('POST', '/api/autonomous/run'), ('POST', '/api/collaboration/run'),
                   ('POST', '/api/v13/projects'), ('POST', '/api/v13/projects/{pid}/memory'), ('POST', '/api/v13/projects/{pid}/tasks'),
                   ('PATCH', '/api/v13/tasks/{tid}'), ('POST', '/api/v13/approvals/{aid}'), ('POST', '/api/v13/schedules'),
                   ('POST', '/api/v13/scheduler/tick'), ('POST', '/api/v14/prepare-run'), ('POST', '/api/v14/launch-approved'),
                   ('POST', '/api/v14/runs/{rid}/sync'), ('POST', '/api/v15/feedback')]
        want_auth = [('GET', '/api/knowledge'), ('GET', '/api/documents'), ('GET', '/api/agents'), ('GET', '/api/v13/overview'),
                     ('GET', '/api/v13/audit'), ('GET', '/api/v14/runs'), ('GET', '/api/v15/learning/overview'), ('GET', '/api/autonomous/logs'),
                     ('POST', '/api/knowledge/search'), ('POST', '/api/documents/search'), ('POST', '/api/intelligence/search'),
                     ('GET', '/api/intelligence/graph'), ('POST', '/api/v15/route'), ('GET', '/api/v34/status')]
        chk('rbac_operator_wajib_pada_semua_tulis/AI', all(getattr(dep_of(m, p), '__name__', '') == 'require_operator' for m, p in want_op))
        chk('rbac_baca_cukup_token_viewer', all(getattr(dep_of(m, p), '__name__', '') == 'auth' for m, p in want_auth))
        chk('rbac_backup_restore_khusus_admin', all(getattr(dep_of(m, p), '__name__', '') == 'require_admin' for m, p in (('GET', '/api/v13/backup'), ('POST', '/api/v13/restore'))))
        try:
            dep_of('GET', '/api/v13/backup')(role='operator')
            chk('require_admin_menolak_operator', False)
        except HTTPException as e:
            chk('require_admin_menolak_operator', e.status_code == 403)

        # ---------------------------------------------------------------- agen
        ag = ep('GET', '/api/agents')(role='viewer')['agents']
        chk('agen_50_dengan_id_01_sampai_50', len(ag) == 50 and ag[0]['id'] == '01' and ag[-1]['id'] == '50' and all(a['name'] and a['role'] for a in ag))

        # ---------------------------------------------------------------- knowledge
        kadd, klist, ksearch, kdel = ep('POST', '/api/knowledge'), ep('GET', '/api/knowledge'), ep('POST', '/api/knowledge/search'), ep('DELETE', '/api/knowledge/{kid}')
        k1 = kadd(data=L.KnowledgeIn34(title='Sejarah batik Jawa', category='Budaya', tags='batik, jawa', content="Batik Jawa punya motif parang dan kawung. O'Brien 100% ☆"), role='operator')
        kadd(data=L.KnowledgeIn34(title='Strategi promosi UMKM', category='Bisnis', tags=['umkm', 'promosi'], content='Promosi media sosial untuk UMKM kuliner'), role='operator')
        kadd(data=L.KnowledgeIn34(title='Catatan rapat', category='Bisnis', tags='', content='Jadwal rapat mingguan tim'), role='operator')
        items = klist(role='viewer')['items']
        chk('knowledge_list_3_dan_tags_array', len(items) == 3 and isinstance(k1['tags'], list) and k1['tags'] == ['batik', 'jawa'])
        res = ksearch(data=L.SearchIn34(query='motif BATIK', limit=10), role='viewer')['items']
        chk('knowledge_search_peringkat_benar', res and res[0]['id'] == k1['id'] and all('score' in x for x in res))
        chk('knowledge_search_karakter_khusus_aman', ksearch(data=L.SearchIn34(query="100% O'Brien", limit=5), role='viewer')['items'][0]['id'] == k1['id'])
        kdel(kid=k1['id'], role='operator')
        chk('knowledge_hapus_lalu_404', raises(404, kdel, kid=k1['id'], role='operator') and len(klist(role='viewer')['items']) == 2)

        # ---------------------------------------------------------------- dokumen
        up, dlist, dget, ddel = ep('POST', '/api/documents/upload'), ep('GET', '/api/documents'), ep('GET', '/api/documents/{did}'), ep('DELETE', '/api/documents/{did}')
        body, ct = multipart({'title': 'Panduan Batik', 'category': 'Budaya'}, 'panduan.txt', 'Batik tulis dibuat dengan canting dan malam.\nMotif parang melambangkan keberanian.'.encode())
        d1 = await up(request=Req(body, ct), role='operator')
        body, ct = multipart({}, 'catatan.md', '# Judul\nRencana promosi video produk UMKM'.encode())
        d2 = await up(request=Req(body, ct), role='operator')
        body, ct = multipart({'title': 'Laporan Word'}, 'laporan.docx', make_docx('Laporan penjualan kuartal satu\nOmzet naik karena promosi'))
        d3 = await up(request=Req(body, ct), role='operator')
        body, ct = multipart({'title': 'Dokumen PDF'}, 'dok.pdf', make_pdf('Halo Nusantara PDF'))
        try:
            d4 = await up(request=Req(body, ct), role='operator')
            chk('upload_pdf_diekstrak', 'Halo' in dget(did=d4['id'], role='viewer')['text'])
        except HTTPException as e:
            chk('upload_pdf_diekstrak', e.status_code == 501)   # pypdf belum terpasang: ditolak jelas, bukan crash
        chk('upload_txt_md_docx_berhasil', d1['char_count'] > 20 and d2['file_type'] == 'md' and d3['file_type'] == 'docx')
        chk('upload_docx_teks_terbaca', 'Omzet naik' in dget(did=d3['id'], role='viewer')['text'])
        body, ct = multipart({}, 'bahaya.exe', b'MZ....')
        chk('upload_format_asing_415', await araises(415, up(request=Req(body, ct), role='operator')))
        body, ct = multipart({}, 'palsu.docx', b'bukan zip')
        chk('upload_docx_palsu_422', await araises(422, up(request=Req(body, ct), role='operator')))
        body, ct = multipart({}, 'palsu.pdf', b'bukan pdf')
        chk('upload_pdf_palsu_422', await araises(422, up(request=Req(body, ct), role='operator')))
        body, ct = multipart({}, 'kosong.txt', b'   \n  ')
        chk('upload_kosong_422', await araises(422, up(request=Req(body, ct), role='operator')))
        chk('upload_content_length_melewati_batas_413', await araises(413, up(request=Req(b'x', ct, clen=L.UPLOAD_MAX_BYTES + 10 * 1024 * 1024), role='operator')))
        chk('upload_tanpa_multipart_415', await araises(415, up(request=Req(b'{}', 'application/json'), role='operator')))
        lst = dlist(role='viewer')['items']
        chk('dokumen_list_ada_excerpt_tanpa_teks_penuh', len(lst) >= 3 and all('excerpt' in x and 'text' not in x for x in lst))
        sr = ep('POST', '/api/documents/search')(data=L.SearchIn34(query='canting malam'), role='viewer')['items']
        chk('dokumen_search_menemukan', sr and sr[0]['id'] == d1['id'])
        full = dget(did=d1['id'], role='viewer')
        chk('dokumen_get_teks_penuh', 'canting' in full['text'])
        sm = await ep('POST', '/api/documents/{did}/summarize')(did=d1['id'], data=L.SummarizeIn34(provider='gemini'), role='operator')
        chk('ringkasan_dokumen_pendek_1_bagian', sm['chunks_processed'] == 1 and sm['summary'].startswith('HASIL[gemini'))
        long_body, ct = multipart({'title': 'Panjang'}, 'panjang.txt', ('kata ' * 10000).encode())
        dl = await up(request=Req(long_body, ct), role='operator')
        sm2 = await ep('POST', '/api/documents/{did}/summarize')(did=dl['id'], data=L.SummarizeIn34(provider='ollama', model='llama3.1:8b'), role='operator')
        chk('ringkasan_dokumen_panjang_dibatasi_dan_jujur', sm2['chunks_processed'] == 6 and sm2['truncated'] and 'hanya' in sm2['summary'])
        chk('provider_dan_model_diteruskan', ('ollama', 'llama3.1:8b') in CALLS)
        FAIL['unconfigured'] = True
        chk('ringkasan_tanpa_kunci_AI_503_jelas', await araises(503, ep('POST', '/api/documents/{did}/summarize')(did=d1['id'], data=L.SummarizeIn34(), role='operator')))
        FAIL['unconfigured'] = False
        ddel(did=d2['id'], role='operator')
        chk('dokumen_hapus_lalu_404', raises(404, dget, did=d2['id'], role='viewer'))

        # ---------------------------------------------------------------- intelligence
        isr = ep('POST', '/api/intelligence/search')(data=L.SearchIn34(query='promosi UMKM', scope='all', limit=10), role='viewer')
        types = {r['source_type'] for r in isr['results']}
        chk('intelligence_search_lintas_sumber_dan_jujur_soal_metode', isr['count'] >= 2 and {'knowledge', 'document'} <= types and 'bukan embedding' in isr['method'])
        only = ep('POST', '/api/intelligence/search')(data=L.SearchIn34(query='promosi', scope='knowledge'), role='viewer')
        chk('intelligence_scope_knowledge', only['results'] and all(r['source_type'] == 'knowledge' for r in only['results']))
        g = ep('GET', '/api/intelligence/graph')(role='viewer')
        chk('intelligence_graph_node_edge', g['nodes'] and any(e['weight'] >= 1 for e in g['edges']) and 'bukan analisis semantik' in g['note'])
        cmp_ = await ep('POST', '/api/intelligence/compare')(data=L.CompareIn34(question='Apa persamaannya?', sources=isr['results'][:2], provider='gemini'), role='operator')
        chk('intelligence_compare', cmp_['analysis'].startswith('HASIL') and len(cmp_['sources']) == 2)

        # ---------------------------------------------------------------- chat & orkestrasi
        ch = await ep('POST', '/api/chat')(data=L.ChatIn34(message='Halo', provider='custom', model='gpt-4.1-mini'), role='operator')
        chk('chat_reply_provider_custom_jadi_openai', ch['reply'].startswith('HASIL[openai|gpt-4.1-mini]') and ch['provider'] == 'openai')
        FAIL['unconfigured'] = True
        chk('chat_tanpa_kunci_503', await araises(503, ep('POST', '/api/chat')(data=L.ChatIn34(message='Halo'), role='operator')))
        FAIL['unconfigured'] = False
        chk('chat_model_berbahaya_422', await araises(422, ep('POST', '/api/chat')(data=L.ChatIn34(message='x', model='../../etc'), role='operator')))
        chk('chat_provider_tak_dikenal_422', await araises(422, ep('POST', '/api/chat')(data=L.ChatIn34(message='x', provider='rahasia'), role='operator')))
        orch = await ep('POST', '/api/orchestrate')(data=L.Orchestrate34In(goal='Promosi batik', provider='gemini', tasks=[
            L.OrchTask34(id='03', name='Ki Juru Tulis', role='Penulis', instruction='Tulis naskah'),
            L.OrchTask34(id='24', name='x', role='y', instruction='Analisis pasar')]), role='operator')
        chk('orkestrasi_urut_konteks_dan_sintesis', len(orch['agent_results']) == 2 and orch['agent_results'][1]['agent'] == 'Nyai Sasmita' and orch['final'].startswith('HASIL'))

        # ---------------------------------------------------------------- autonomous
        plan = ep('POST', '/api/autonomous/plan')(data=L.AutoPlan34In(goal='buat strategi promosi video untuk produk UMKM batik'), role='viewer')
        tasks = plan['tasks']
        chk('rencana_lokal_valid_dag_dan_jujur', len(tasks) >= 3 and 'LOKAL' in plan['notice'] and L.validate_tasks([L.Task34(**t) for t in tasks]))
        mk = lambda ts: [L.Task34(**t) for t in ts]  # noqa: E731
        run = await ep('POST', '/api/autonomous/run')(data=L.AutoRun34In(goal='promosi batik', tasks=mk(tasks), provider='gemini', max_parallel=3, max_retries=1), role='operator')
        chk('autonomous_semua_selesai_ada_review_dan_log', run['status'] == 'completed' and run['summary']['completed'] == len(tasks) and run['quality_review'].get('score') == 90
            and any(e['event'] == 'task.completed' for e in run['execution_log']))
        FAIL['once'] = {'Nyai Sasmita'}
        run2 = await ep('POST', '/api/autonomous/run')(data=L.AutoRun34In(goal='promosi batik', tasks=mk(tasks), provider='gemini', max_retries=1), role='operator')
        t1 = next(x for x in run2['agent_results'] if x['id'] == 'T1')
        chk('autonomous_retry_berhasil_attempts_2', run2['status'] == 'completed' and t1['attempts'] == 2)
        FAIL['once'] = set()
        FAIL['agents'] = {'Ki Adikara'}
        run3 = await ep('POST', '/api/autonomous/run')(data=L.AutoRun34In(goal='promosi batik', tasks=mk(tasks), provider='gemini', max_retries=0), role='operator')
        chk('autonomous_satu_gagal_status_partial', run3['status'] == 'partial' and run3['summary']['failed'] == 1)
        FAIL['agents'] = {'Nyai Sasmita'}
        run4 = await ep('POST', '/api/autonomous/run')(data=L.AutoRun34In(goal='promosi batik', tasks=mk(tasks), provider='gemini', max_retries=0), role='operator')
        chk('autonomous_dependensi_gagal_dilewati', run4['status'] == 'failed' and run4['summary']['skipped'] == len(tasks) - 1)
        FAIL['agents'] = set()
        cyc = [dict(tasks[0], depends_on=[tasks[1]['id']]), dict(tasks[1], depends_on=[tasks[0]['id']])]
        chk('autonomous_siklus_422', await araises(422, ep('POST', '/api/autonomous/run')(data=L.AutoRun34In(goal='promosi batik', tasks=mk(cyc)), role='operator')))
        bad = [dict(tasks[0], agent_id='99')]
        chk('autonomous_agen_tak_ada_422', await araises(422, ep('POST', '/api/autonomous/run')(data=L.AutoRun34In(goal='promosi batik', tasks=mk(bad)), role='operator')))
        bad2 = [dict(tasks[0], depends_on=['T999'])]
        chk('autonomous_dependensi_tak_ada_422', await araises(422, ep('POST', '/api/autonomous/run')(data=L.AutoRun34In(goal='promosi batik', tasks=mk(bad2)), role='operator')))
        lg = ep('GET', '/api/autonomous/logs')(limit=20, role='viewer')['events']
        chk('autonomous_logs_bentuk_sesuai_panel', lg and all('event' in e and 'time' in e for e in lg))

        # ---------------------------------------------------------------- kolaborasi (background + polling)
        cplan = ep('POST', '/api/collaboration/plan')(data=L.CollabPlan34In(goal='rancang kampanye media sosial untuk produk kuliner'), role='viewer')
        bg = BG()
        FAIL['review'] = [50, 90]
        cr = await ep('POST', '/api/collaboration/run')(data=L.CollabRun34In(goal='kampanye kuliner', shared_memory='Target pasar remaja', tasks=mk(cplan['tasks']), provider='gemini', correction_rounds=1),
                                                       background_tasks=bg, role='operator')
        chk('kolaborasi_run_langsung_kembali_running', cr['status'] == 'running' and cr['run_id'] and len(bg.jobs) == 1)
        mid = ep('GET', '/api/collaboration/runs/{rid}')(rid=cr['run_id'], role='viewer')
        chk('kolaborasi_polling_saat_berjalan_punya_total', mid['summary']['total'] == len(cplan['tasks']) and mid['status'] == 'running')
        await bg.run()
        fin = ep('GET', '/api/collaboration/runs/{rid}')(rid=cr['run_id'], role='viewer')
        chk('kolaborasi_selesai_final_review_koreksi', fin['status'] == 'completed' and fin['final'] and fin['quality_review'].get('score') == 90
            and any(e['event'] == 'correction.round' for e in fin['events']))
        chk('kolaborasi_shared_memory_terisi', fin['shared_memory']['catatan_awal'] == 'Target pasar remaja' and len(fin['shared_memory']['ringkasan_tugas']) == len(cplan['tasks']))
        chk('kolaborasi_riwayat', ep('GET', '/api/collaboration/logs')(limit=20, role='viewer')['items'][0]['id'] == cr['run_id'])
        chk('kolaborasi_run_tak_ada_404', raises(404, ep('GET', '/api/collaboration/runs/{rid}'), rid='tidak-ada', role='viewer'))
        # run macet dianggap gagal (aman multi-instance: berdasar updated_at)
        stale = L._new_id()
        with M.conn() as c:
            c.execute("INSERT INTO lg34_runs(id,kind,goal,status,provider,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                      (stale, 'collaboration', 'macet', 'running', 'gemini', '2020-01-01T00:00:00+00:00', '2020-01-01T00:00:00+00:00'))
        chk('run_macet_ditandai_gagal', ep('GET', '/api/collaboration/runs/{rid}')(rid=stale, role='viewer')['status'] == 'failed')

        # ---------------------------------------------------------------- command center v13
        pc = ep('POST', '/api/v13/projects')
        p1 = pc(data=L.Project34In(name='Proyek Batik', description='Promosi batik'), role='operator')
        chk('proyek_dibuat', p1['id'] and p1['status'] == 'active')
        chk('proyek_duplikat_409', raises(409, pc, data=L.Project34In(name='Proyek Batik'), role='operator'))
        ma = ep('POST', '/api/v13/projects/{pid}/memory')(pid=p1['id'], data=L.Memory34In(title='Brief', content='Target remaja'), role='operator')
        chk('memori_proyek', ep('GET', '/api/v13/projects/{pid}/memory')(pid=p1['id'], role='viewer')['items'][0]['id'] == ma['id'])
        chk('memori_proyek_404', raises(404, ep('GET', '/api/v13/projects/{pid}/memory'), pid='x', role='viewer'))
        tc = ep('POST', '/api/v13/projects/{pid}/tasks')
        t1_ = tc(pid=p1['id'], data=L.TaskNew34In(title='Buat caption', agent_id='3', priority='high', due_at='2026-12-01T10:00'), role='operator')
        t2_ = tc(pid=p1['id'], data=L.TaskNew34In(title='Analisis pasar', agent_id='24'), role='operator')
        chk('tugas_agen_dinormalisasi_dua_digit', t1_['agent_id'] == '03' and t1_['status'] == 'open' and t1_['due_at'])
        chk('tugas_prioritas_salah_422', raises(422, tc, pid=p1['id'], data=L.TaskNew34In(title='x', priority='darurat'), role='operator'))
        chk('tugas_agen_tak_ada_422', raises(422, tc, pid=p1['id'], data=L.TaskNew34In(title='x', agent_id='77'), role='operator'))
        chk('tugas_tenggat_salah_422', raises(422, tc, pid=p1['id'], data=L.TaskNew34In(title='x', due_at='besok'), role='operator'))
        pt = ep('PATCH', '/api/v13/tasks/{tid}')
        u = pt(tid=t1_['id'], data=L.TaskPatch34In(status='completed', score=4), role='operator')
        chk('tugas_patch_status_skor', u['status'] == 'completed' and u['score'] == 4)
        chk('tugas_skor_di_luar_1_5_422', raises(422, pt, tid=t1_['id'], data=L.TaskPatch34In(score=9), role='operator'))
        chk('tugas_status_salah_422', raises(422, pt, tid=t1_['id'], data=L.TaskPatch34In(status='selesai'), role='operator'))
        keep = pt(tid=t1_['id'], data=L.TaskPatch34In(status='completed'), role='operator')
        chk('tugas_patch_tanpa_skor_mempertahankan_skor', keep['score'] == 4)
        clr = pt(tid=t1_['id'], data=L.TaskPatch34In.model_validate({'status': 'completed', 'score': None}), role='operator')
        chk('tugas_skor_null_menghapus_skor', clr['score'] is None)
        pt(tid=t1_['id'], data=L.TaskPatch34In(status='completed', score=4), role='operator')
        lt = ep('GET', '/api/v13/projects/{pid}/tasks')(pid=p1['id'], role='viewer')
        chk('tugas_list_dengan_performa', len(lt['items']) == 2 and lt['performance'] == {'rated_tasks': 1, 'average_score': 4.0})
        an = ep('GET', '/api/v13/analytics/agents')(limit=50, role='viewer')['items']
        chk('analitik_agen', an[0]['agent_id'] == '03' and an[0]['average_score'] == 4.0 and an[0]['completed'] == 1)

        sch = ep('POST', '/api/v13/schedules')
        s_old = sch(data=L.ScheduleIn34(project_id=p1['id'], title='Posting pagi', due_at='2020-01-01T00:00:00.000Z'), role='operator')
        sch(data=L.ScheduleIn34(project_id=p1['id'], title='Posting masa depan', due_at='2099-01-01T00:00:00.000Z'), role='operator')
        chk('jadwal_format_salah_422', raises(422, sch, data=L.ScheduleIn34(project_id=p1['id'], title='x', due_at='nanti'), role='operator'))
        tick = ep('POST', '/api/v13/scheduler/tick')(role='operator')
        tick2 = ep('POST', '/api/v13/scheduler/tick')(role='operator')
        chk('scheduler_hanya_yang_jatuh_tempo_dan_idempoten', tick['promoted'] == 1 and tick2['promoted'] == 0)
        ap = ep('GET', '/api/v13/approvals')(role='viewer')['items']
        chk('jadwal_jadi_approval_pending', len(ap) == 1 and ap[0]['status'] == 'pending' and 'Posting pagi' in ap[0]['title'])
        dec = ep('POST', '/api/v13/approvals/{aid}')
        chk('approval_keputusan_salah_422', raises(422, dec, aid=ap[0]['id'], data=L.Decision34In(decision='mungkin'), role='operator'))
        d_ok = dec(aid=ap[0]['id'], data=L.Decision34In(decision='approved', note='ok'), role='operator')
        chk('approval_disetujui_tercatat_siapa', d_ok['status'] == 'approved' and d_ok['decided_by'] == 'operator')
        chk('approval_diputuskan_dua_kali_409', raises(409, dec, aid=ap[0]['id'], data=L.Decision34In(decision='rejected'), role='operator'))
        chk('approval_404', raises(404, dec, aid='x', data=L.Decision34In(decision='approved'), role='operator'))
        ov = ep('GET', '/api/v13/overview')(role='viewer')
        chk('overview_hitungan_dan_biaya_null_jujur', ov['projects'] == 1 and ov['tasks'] == 2 and ov['pending_approvals'] == 0 and ov['ai_calls'] > 0 and ov['cost_usd'] is None and ov['role'] == 'viewer')
        au = ep('GET', '/api/v13/audit')(role='viewer')['items']
        chk('audit_tercatat', any(x['action'] == 'v34.project.create' and x['actor_role'] == 'operator' for x in au))

        # ---------------------------------------------------------------- backup / restore
        bk = ep('GET', '/api/v13/backup')(role='admin')
        counts_before = {t: len(r) for t, r in bk['tables'].items()}
        chk('backup_format_dan_isi', bk['format'] == 'nck-v34-backup' and counts_before['lg34_projects'] == 1 and counts_before['lg34_tasks'] == 2 and counts_before['lg34_documents'] >= 3)
        # ubah data, lalu restore harus mengembalikan keadaan backup
        pc(data=L.Project34In(name='Proyek Sementara'), role='operator')
        ddel(did=d3['id'], role='operator')
        rr = ep('POST', '/api/v13/restore')
        rest = await rr(request=Req(json.dumps(bk).encode(), 'application/json'), role='admin')
        counts_after = {t: one_count(M, t) for t in counts_before}
        chk('restore_mengembalikan_keadaan_backup', all(counts_after[t] == counts_before[t] for t in counts_before) and rest['restored']['lg34_projects'] == 1)
        chk('restore_proyek_sementara_hilang', not [p for p in ep('GET', '/api/v13/projects')(role='viewer')['items'] if p['name'] == 'Proyek Sementara'])
        chk('restore_dokumen_kembali', dget(did=d3['id'], role='viewer')['id'] == d3['id'])
        chk('restore_umpan_balik_dan_fk_utuh', one_count(M, 'lg34_tasks') == 2)
        chk('restore_format_salah_422', await araises(422, rr(request=Req(json.dumps({'format': 'lama', 'tables': {}}).encode(), 'application/json'), role='admin')))
        chk('restore_bukan_json_400', await araises(400, rr(request=Req(b'bukan json', 'application/json'), role='admin')))
        chk('restore_tabel_asing_422', await araises(422, rr(request=Req(json.dumps({'format': 'nck-v34-backup', 'tables': {'audit': []}}).encode(), 'application/json'), role='admin')))
        broken = json.loads(json.dumps(bk))
        broken['tables']['lg34_tasks'][0].pop('title')
        pc(data=L.Project34In(name='Harus Selamat'), role='operator')
        chk('restore_rusak_ditolak_dan_data_tidak_berubah', await araises(422, rr(request=Req(json.dumps(broken).encode(), 'application/json'), role='admin'))
            and any(p['name'] == 'Harus Selamat' for p in ep('GET', '/api/v13/projects')(role='viewer')['items']))
        # setelah restore, ID otomatis tetap bekerja (feedback memakai identity)
        # ---------------------------------------------------------------- v14
        pr = ep('POST', '/api/v14/prepare-run')
        lc = ep('POST', '/api/v14/launch-approved')
        t3_ = tc(pid=p1['id'], data=L.TaskNew34In(title='Susun jadwal posting', agent_id='08'), role='operator')
        open_ids = [t3_['id']]
        prep = pr(data=L.Prepare34In(project_id=p1['id'], task_ids=open_ids + open_ids, goal='Kampanye batik', provider='gemini', mode='parallel'), role='operator')
        chk('v14_prepare_membuat_approval_pending_judul_TAHAP14', prep['status'] == 'pending' and any(a['title'].startswith('[TAHAP14]') for a in ep('GET', '/api/v13/approvals')(role='viewer')['items']))
        chk('v14_prepare_tugas_completed_ditolak_409', raises(409, pr, data=L.Prepare34In(project_id=p1['id'], task_ids=[t1_['id']]), role='operator'))
        chk('v14_prepare_tugas_proyek_lain_404', raises(404, pr, data=L.Prepare34In(project_id=p1['id'], task_ids=['tidak-ada']), role='operator'))
        chk('v14_prepare_mode_salah_422', raises(422, pr, data=L.Prepare34In(project_id=p1['id'], task_ids=open_ids, mode='acak'), role='operator'))
        bg2 = BG()
        chk('v14_launch_sebelum_disetujui_409', await araises(409, lc(data=L.Launch34In(approval_id=prep['approval_id']), background_tasks=bg2, role='operator')))
        dec(aid=prep['approval_id'], data=L.Decision34In(decision='approved'), role='operator')
        lr = await lc(data=L.Launch34In(approval_id=prep['approval_id']), background_tasks=bg2, role='operator')
        chk('v14_launch_berjalan_dan_tugas_in_progress', lr['status'] == 'running' and one_val(M, "SELECT status FROM lg34_tasks WHERE id=?", (t3_['id'],)) == 'in_progress')
        chk('v14_launch_dua_kali_409', await araises(409, lc(data=L.Launch34In(approval_id=prep['approval_id']), background_tasks=BG(), role='operator')))
        sy = ep('POST', '/api/v14/runs/{rid}/sync')
        chk('v14_sync_sebelum_selesai_belum_synced', sy(rid=lr['run_id'], role='operator')['synced'] is False)
        await bg2.run()
        s1 = sy(rid=lr['run_id'], role='operator')
        chk('v14_sync_menulis_hasil_ke_tugas', s1['synced'] and one_val(M, "SELECT status FROM lg34_tasks WHERE id=?", (t3_['id'],)) == 'completed' and 'HASIL' in one_val(M, "SELECT result FROM lg34_tasks WHERE id=?", (t3_['id'],)))
        chk('v14_sync_idempoten', 'Sudah' in sy(rid=lr['run_id'], role='operator')['message'])
        runs = ep('GET', '/api/v14/runs')(role='viewer')['items']
        chk('v14_runs_list', runs and runs[0]['run_id'] == lr['run_id'] and runs[0]['status'] == 'completed' and runs[0]['approval_id'] == prep['approval_id'])
        # v14 dengan kegagalan: tugas jadi blocked
        t4_ = tc(pid=p1['id'], data=L.TaskNew34In(title='Tugas gagal', agent_id='50'), role='operator')
        prep2 = pr(data=L.Prepare34In(project_id=p1['id'], task_ids=[t4_['id']], provider='gemini', mode='sequential'), role='operator')
        dec(aid=prep2['approval_id'], data=L.Decision34In(decision='approved'), role='operator')
        FAIL['agents'] = {'Ki Adikara'}
        bg3 = BG()
        lr2 = await lc(data=L.Launch34In(approval_id=prep2['approval_id']), background_tasks=bg3, role='operator')
        await bg3.run()
        FAIL['agents'] = set()
        sy(rid=lr2['run_id'], role='operator')
        chk('v14_kegagalan_menjadi_blocked_dengan_alasan', one_val(M, "SELECT status FROM lg34_tasks WHERE id=?", (t4_['id'],)) == 'blocked' and 'simulasi' in one_val(M, "SELECT result FROM lg34_tasks WHERE id=?", (t4_['id'],)))

        # ---------------------------------------------------------------- v15
        ft = ep('GET', '/api/v15/feedback/tasks')(role='viewer')['items']
        chk('feedback_tasks_hanya_completed', {x['id'] for x in ft} == {t1_['id'], t3_['id']} and ft[0]['agent_name'])
        fb = ep('POST', '/api/v15/feedback')
        chk('feedback_tersimpan_memperbarui_skor', fb(data=L.Feedback34In(task_id=t3_['id'], rating=5, notes='bagus'), role='operator')['agent_id'] == '08' and one_val(M, "SELECT score FROM lg34_tasks WHERE id=?", (t3_['id'],)) == 5)
        chk('feedback_rating_di_luar_range_422', raises(422, fb, data=L.Feedback34In(task_id=t3_['id'], rating=6), role='operator'))
        chk('feedback_tugas_belum_selesai_409', raises(409, fb, data=L.Feedback34In(task_id=t2_['id'], rating=3), role='operator'))
        lo = ep('GET', '/api/v15/learning/overview')(role='viewer')
        chk('learning_overview_ringkasan_jujur', lo['summary']['agent_count'] == 50 and lo['summary']['rated_count'] == 2 and lo['summary']['average_rating'] == 4.5 and 'bukan pelatihan model' in lo['note'])
        chk('learning_confidence_rendah_untuk_data_sedikit', all(a['confidence'] == 'rendah' and a['signal'] == 'data belum cukup' for a in lo['agents']))
        rt = ep('POST', '/api/v15/route')(data=L.Route34In(goal='strategi promosi video media sosial', limit=5), role='viewer')
        top = rt['recommendations']
        chk('route_rekomendasi_terurut_dan_beralasan', len(top) == 5 and top == sorted(top, key=lambda x: (-x['score'], x['agent_id'])) and top[0]['skill_match'] > 0 and top[0]['reason'])
        rec = ep('POST', '/api/v15/route')(data=L.Route34In(goal='xyz tidak ada', limit=10), role='viewer')['recommendations']
        chk('route_riwayat_rating_mempengaruhi_skor', rec[0]['agent_id'] == '08' and rec[0]['score'] > rec[-1]['score'])
        chk('route_proyek_tak_ada_404', raises(404, ep('POST', '/api/v15/route'), data=L.Route34In(goal='promosi', project_id='x'), role='viewer'))

        # ---------------------------------------------------------------- status modul
        st = ep('GET', '/api/v34/status')(role='viewer')
        chk('status_v34_tanpa_membocorkan_kunci', st['version'] == '34.0.0' and st['agents'] == 50 and st['providers'] == {'gemini_configured': False, 'openai_configured': False, 'ollama_configured': False}
            and all(isinstance(v, int) for v in st['tables'].values()))
        ad = ep('GET', '/api/v33/database/adapter')(role='operator')
        chk('sequence_identity_sehat_setelah_restore', ad['identity_sequences_ok'])

    def one_count(M_, t):
        with M_.conn() as c:
            return c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0]

    def one_val(M_, sql, params=()):
        with M_.conn() as c:
            r = c.execute(sql, params).fetchone()
            return r[0] if r else None

    try:
        asyncio.run(main())
    except Exception as exc:  # noqa: BLE001
        import traceback
        traceback.print_exc()
        out['_exception'] = False
        out['_exception_detail'] = repr(exc)[:300]
    print('RESULT:' + json.dumps(out))
    sys.stdout.flush()
    os._exit(0)


# ------------------------------------------------------------------ orkestrator
def run_child(backend, schema):
    env = dict(os.environ)
    pp = _bootstrap.pythonpath_for_children()
    if pp:
        env['PYTHONPATH'] = pp + os.pathsep + env.get('PYTHONPATH', '')
    p = subprocess.run([sys.executable, __file__, '--child', backend, schema], capture_output=True, text=True, env=env, timeout=600)
    res = None
    for line in reversed(p.stdout.splitlines()):
        if line.startswith('RESULT:'):
            res = json.loads(line[7:])
            break
    return res, p.stderr[-1500:], p.stdout[-800:]


def main():
    _bootstrap.install()
    backends = [('sqlite', '')]
    if DSN:
        backends.append(('postgres', 'nck_t34_a'))
    failed, total = [], 0
    for backend, schema in backends:
        if backend == 'postgres':
            import psycopg
            with psycopg.connect(DSN) as c:
                c.cursor().execute(f'DROP SCHEMA IF EXISTS {schema} CASCADE')
        res, err, so = run_child(backend, schema)
        if res is None:
            print(f'FAIL  [{backend}] anak proses tidak menghasilkan hasil\n{err}\n{so}')
            failed.append(f'{backend}:crash')
            continue
        for k, v in res.items():
            if k.endswith('_detail'):
                print('      detail:', v)
                continue
            total += 1
            print(('PASS  ' if v else 'FAIL  ') + f'[{backend}] {k}')
            if not v:
                failed.append(f'{backend}:{k}')
        if backend == 'postgres':
            with psycopg.connect(DSN) as c:
                c.cursor().execute(f'DROP SCHEMA IF EXISTS {schema} CASCADE')
        if err.strip() and res.get('_exception') is False:
            print(err)
    print(f'\nRINGKAS: {total - len(failed)}/{total} lulus' + ('' if not failed else ' | GAGAL: ' + str(failed)))
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--child':
        child(sys.argv[2], sys.argv[3])
    else:
        main()
