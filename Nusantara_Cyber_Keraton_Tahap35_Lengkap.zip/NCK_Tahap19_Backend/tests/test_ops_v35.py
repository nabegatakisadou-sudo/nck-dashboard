"""Uji Tahap 35: modul operasi (readiness, metrik, laporan backup), rotasi token, validasi produksi.

Bagian A (proses induk): logika murni + middleware dengan aplikasi penangkap.
Bagian B (proses anak per backend): main.py penuh pada SQLite dan (bila NCK_TEST_PG_DSN) PostgreSQL.
Bagian C (proses anak per skenario): NCK_ENV=production -> start harus ditolak/diterima sesuai konfigurasi.
Jalankan dari NCK_Tahap19_Backend:  python tests/test_ops_v35.py
"""
import asyncio
import io
import json
import os
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import _bootstrap  # noqa: E402

DSN = os.environ.get('NCK_TEST_PG_DSN', '')
A, O, V = 'a' * 40, 'o' * 40, 'v' * 40
SECRETS = [A, O, V, 'ZZ-super-secret-pw-123']


class Req:
    def __init__(self, scheme='http', headers=None, client='10.0.0.1'):
        class U:
            pass
        self.url = U()
        self.url.scheme = scheme
        self.url.path = '/x'
        self.headers = {k.lower(): v for k, v in (headers or {}).items()}
        self.client = type('C', (), {'host': client})() if client else None
        self.method = 'GET'


def good_env(**kw):
    env = {'NCK_ENV': 'production', 'NCK_VIEWER_TOKEN': V, 'NCK_OPERATOR_TOKEN': O, 'NCK_ADMIN_TOKEN': A,
           'NCK_CORS_ORIGINS': 'https://front.example', 'NCK_FORCE_HTTPS': '1', 'OPENAI_API_KEY': 'k',
           'NCK_POSTGRES_DSN': 'postgresql://u:ZZ-super-secret-pw-123@db.example/x?sslmode=require'}
    env.update(kw)
    return env


def good_ctx(**kw):
    import time
    ctx = {'backend': 'postgres', 'db_ms': 12.0, 'db_error': None, 'now': time.time(), 'exceptions_24h': 0,
           'req': {'scheme': 'https', 'xfp': 'https', 'xff': '1.2.3.4', 'client': '1.2.3.4'}, 'prev_use': {},
           'backup_last': {'created_at': __import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()},
           'drill_last': {'created_at': __import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()}}
    ctx.update(kw)
    return ctx


def st(checks, cid):
    return next(c['status'] for c in checks if c['id'] == cid)


# ============================================================ A. proses induk
def part_a(out):
    _bootstrap.install()
    import datetime as dt
    import nck_ops_v35 as P

    chk = lambda n, c: out.__setitem__('A ' + n, bool(c))  # noqa: E731
    # --- konfigurasi sehat
    cs = P.readiness_checks(good_env(), good_ctx())
    sm = P.summarize(cs)
    chk('konfigurasi sehat: 0 gagal, 0 peringatan', sm['fail'] == 0 and sm['warn'] == 0 and sm['verdict'] == 'lulus_pemeriksaan_otomatis')
    chk('setiap cek punya id, label, status valid', all(c['id'] and c['label'] and c['status'] in ('pass', 'warn', 'fail', 'info') for c in cs))
    chk('id cek unik', len({c['id'] for c in cs}) == len(cs))
    # --- matriks kegagalan
    chk('token lemah -> fail', st(P.readiness_checks(good_env(NCK_ADMIN_TOKEN='pendek'), good_ctx()), 'tokens_strong') == 'fail')
    chk('token placeholder -> fail', st(P.readiness_checks(good_env(NCK_ADMIN_TOKEN='replace_with_random_admin_token_long_long'), good_ctx()), 'tokens_strong') == 'fail')
    chk('token sama -> fail', st(P.readiness_checks(good_env(NCK_VIEWER_TOKEN=A), good_ctx()), 'tokens_distinct') == 'fail')
    chk('CORS * -> fail', st(P.readiness_checks(good_env(NCK_CORS_ORIGINS='*'), good_ctx()), 'cors_exact') == 'fail')
    chk('CORS kosong -> fail', st(P.readiness_checks(good_env(NCK_CORS_ORIGINS=''), good_ctx()), 'cors_exact') == 'fail')
    chk('CORS localhost di produksi -> warn', st(P.readiness_checks(good_env(NCK_CORS_ORIGINS='https://a.example,http://localhost:5500'), good_ctx()), 'cors_exact') == 'warn')
    chk('SQLite di Render -> fail', st(P.readiness_checks(good_env(RENDER='true'), good_ctx(backend='sqlite')), 'database_durable') == 'fail')
    chk('SQLite bukan Render -> warn', st(P.readiness_checks(good_env(), good_ctx(backend='sqlite')), 'database_durable') == 'warn')
    chk('PostgreSQL -> pass', st(P.readiness_checks(good_env(), good_ctx()), 'database_durable') == 'pass')
    chk('DSN jauh tanpa sslmode -> warn', st(P.readiness_checks(good_env(NCK_POSTGRES_DSN='postgresql://u:p@db.example/x'), good_ctx()), 'database_tls') == 'warn')
    chk('DSN jauh sslmode=require -> pass', st(P.readiness_checks(good_env(), good_ctx()), 'database_tls') == 'pass')
    chk('DSN lokal -> info', st(P.readiness_checks(good_env(NCK_POSTGRES_DSN='postgresql://u:p@localhost/x'), good_ctx()), 'database_tls') == 'info')
    chk('mode api + SQLite -> fail', st(P.readiness_checks(good_env(NCK_WORKER_MODE='api'), good_ctx(backend='sqlite')), 'worker_mode') == 'fail')
    chk('mode api + PG -> pass', st(P.readiness_checks(good_env(NCK_WORKER_MODE='api'), good_ctx()), 'worker_mode') == 'pass')
    chk('NCK_ENV bukan production -> warn', st(P.readiness_checks(good_env(NCK_ENV='development'), good_ctx()), 'env_production') == 'warn')
    chk('tanpa penyedia AI -> warn', st(P.readiness_checks(good_env(OPENAI_API_KEY=''), good_ctx()), 'ai_provider') == 'warn')
    chk('HTTP biasa -> warn', st(P.readiness_checks(good_env(), good_ctx(req={'scheme': 'http', 'xfp': '', 'xff': '', 'client': 'x'})), 'https_request') == 'warn')
    chk('X-Forwarded-Proto https dikenali', st(P.readiness_checks(good_env(), good_ctx(req={'scheme': 'http', 'xfp': 'https', 'xff': '', 'client': 'x'})), 'https_request') == 'pass')
    chk('HSTS tanpa FORCE_HTTPS di http -> warn', st(P.readiness_checks(good_env(NCK_FORCE_HTTPS='0'), good_ctx(req={'scheme': 'http', 'xfp': 'https', 'xff': '', 'client': 'x'})), 'hsts') == 'warn')
    chk('XFF tidak dipercaya -> warn', st(P.readiness_checks(good_env(), good_ctx(req={'scheme': 'https', 'xfp': 'https', 'xff': '9.9.9.9', 'client': '10.1.1.1'})), 'proxy_headers') == 'warn')
    chk('XFF dipercaya -> pass', st(P.readiness_checks(good_env(), good_ctx()), 'proxy_headers') == 'pass')
    chk('tanpa XFF -> info', st(P.readiness_checks(good_env(), good_ctx(req={'scheme': 'https', 'xfp': '', 'xff': '', 'client': 'x'})), 'proxy_headers') == 'info')
    chk('DB error -> fail', st(P.readiness_checks(good_env(), good_ctx(db_error='OperationalError: down', db_ms=None)), 'db_ping') == 'fail')
    chk('DB lambat -> warn', st(P.readiness_checks(good_env(), good_ctx(db_ms=1500.0)), 'db_ping') == 'warn')
    old = lambda h: {'created_at': (dt.datetime.now(dt.timezone.utc) - dt.timedelta(hours=h)).isoformat()}  # noqa: E731
    chk('backup 10 jam -> pass', st(P.readiness_checks(good_env(), good_ctx(backup_last=old(10))), 'backup_recent') == 'pass')
    chk('backup 50 jam -> warn', st(P.readiness_checks(good_env(), good_ctx(backup_last=old(50))), 'backup_recent') == 'warn')
    chk('backup 100 jam -> fail', st(P.readiness_checks(good_env(), good_ctx(backup_last=old(100))), 'backup_recent') == 'fail')
    chk('belum ada backup -> warn', st(P.readiness_checks(good_env(), good_ctx(backup_last=None)), 'backup_recent') == 'warn')
    chk('drill 10 hari -> pass', st(P.readiness_checks(good_env(), good_ctx(drill_last=old(240))), 'restore_drill') == 'pass')
    chk('drill 60 hari -> warn', st(P.readiness_checks(good_env(), good_ctx(drill_last=old(1440))), 'restore_drill') == 'warn')
    chk('belum ada drill -> warn', st(P.readiness_checks(good_env(), good_ctx(drill_last=None)), 'restore_drill') == 'warn')
    chk('galat 24 jam > 0 -> warn', st(P.readiness_checks(good_env(), good_ctx(exceptions_24h=3)), 'exceptions_24h') == 'warn')
    chk('rotasi aktif -> warn', st(P.readiness_checks(good_env(NCK_VIEWER_TOKEN_PREVIOUS='x' * 40), good_ctx()), 'tokens_rotation') == 'warn')
    chk('verdict belum_siap bila ada fail', P.summarize(P.readiness_checks(good_env(NCK_ADMIN_TOKEN='x'), good_ctx()))['verdict'] == 'belum_siap')
    chk('verdict siap_dengan_catatan bila hanya warn', P.summarize(P.readiness_checks(good_env(), good_ctx(backup_last=None)))['verdict'] == 'siap_dengan_catatan')
    # --- rahasia tidak pernah bocor
    blob = json.dumps(P.readiness_checks(good_env(NCK_VIEWER_TOKEN_PREVIOUS='PREVIOUS-' + 'p' * 40, NCK_POSTGRES_DSN='postgresql://u:ZZ-super-secret-pw-123@db.example/x'),
                                         good_ctx(req={'scheme': 'https', 'xfp': 'https', 'xff': '9.9.9.9', 'client': '10.1.1.1'})))
    chk('keluaran readiness tidak memuat token/kata sandi/IP', not any(s in blob for s in SECRETS + ['PREVIOUS-', '9.9.9.9', '10.1.1.1']))
    chk('limits selalu ada dan tidak kosong', len(P.LIMITS) >= 4)
    # --- dsn_info
    i = P.dsn_info('postgresql://user:ZZ-super-secret-pw-123@ep-1.neon.tech/db?sslmode=require&x=1')
    chk('dsn_info URI: host+sslmode, tanpa kata sandi', i['host'] == 'ep-1.neon.tech' and i['sslmode'] == 'require' and 'ZZ-super' not in json.dumps(i) and not i['local'])
    i = P.dsn_info('host=db.x port=5432 dbname=n user=u password=ZZ-super-secret-pw-123 sslmode=verify-full')
    chk('dsn_info key=value', i['host'] == 'db.x' and i['sslmode'] == 'verify-full' and 'ZZ-super' not in json.dumps(i))
    chk('dsn_info socket/localhost lokal', P.dsn_info('postgresql://u@/db?host=/var/run/postgresql')['local'] and P.dsn_info('postgresql://u:p@localhost/x')['local'])
    chk('dsn_info DSN rusak tidak melempar', P.dsn_info('http://[bad')['host'] == '' or True)

    # --- metrik
    m = P._Metrics()
    for i in range(1, 101):
        m.record('GET', '/api/v34/x', 200, float(i), 2000)
    m.record('GET', '/api/v34/x', 503, 3000.0, 2000)
    m.record('POST', '/health', 429, 1.0, 2000)
    s = m.snapshot()
    chk('metrik: total dan kelas status', s['requests_total'] == 102 and s['by_class'] == {'2xx': 100, '5xx': 1, '4xx': 1})
    chk('metrik: p50 ~ 51, p95 ~ 96, max 3000', 49 <= s['latency_ms']['p50'] <= 53 and 93 <= s['latency_ms']['p95'] <= 99 and s['latency_ms']['max'] == 3000.0)
    chk('metrik: lambat dan 5xx terakhir tercatat', s['slow_requests'] == 1 and s['recent_5xx'][-1]['status'] == 503)
    chk('metrik: kelompok jalur dibatasi dua segmen', set(s['top_groups']) == {'/api/v34', '/health'})
    m2 = P._Metrics()
    chk('metrik kosong: persentil None, tidak melempar', m2.snapshot()['latency_ms']['p50'] is None)
    for i in range(200):
        m2.record('GET', f'/g{i}/a', 200, 1.0, 2000)
    chk('metrik: kunci kelompok dibatasi (<=61)', len(m2.snapshot()['top_groups']) <= 15 and len(m2.by_group) <= 61)

    # --- middleware dengan aplikasi penangkap
    class Cap:
        def __init__(self):
            self.mw, self.routes = None, {}

        def middleware(self, t):
            def d(f):
                self.mw = f
                return f
            return d

        def on_event(self, n):
            return lambda f: f

        def _r(self, m):
            def r(path, **k):
                def d(f):
                    self.routes[(m, path)] = f
                    return f
                return d
            return r

        def get(self, path, **k):
            return self._r('GET')(path, **k)

        def post(self, path, **k):
            return self._r('POST')(path, **k)
    P.METRICS.reset()
    cap = Cap()
    lines = io.StringIO()
    import logging
    P.register(cap, conn=lambda: (_ for _ in ()).throw(RuntimeError('db mati')), auth=lambda: 'viewer', require_operator=lambda: 'operator',
               audit=lambda *a, **k: None, now=lambda: 'x', backend='sqlite', service='svc')
    lg = P._logger()
    h = logging.StreamHandler(lines)
    h.setFormatter(logging.Formatter('%(message)s'))
    lg.addHandler(h)

    class Resp:
        def __init__(self, code):
            self.status_code, self.headers = code, {'X-Request-ID': 'rid123'}

    async def ok_next(_r):
        return Resp(200)

    async def err_next(_r):
        raise RuntimeError('boom')

    async def s503_next(_r):
        return Resp(503)
    loop = asyncio.new_event_loop()
    r = loop.run_until_complete(cap.mw(Req(), ok_next))
    chk('middleware meneruskan respons apa adanya', r.status_code == 200)
    chk('middleware: permintaan 200 tidak mencetak log (hemat log)', lines.getvalue() == '')
    loop.run_until_complete(cap.mw(Req(), s503_next))
    chk('middleware: 503 dicatat dan dilog JSON dengan request id', json.loads(lines.getvalue().strip().splitlines()[-1])['s'] == 503 and 'rid123' in lines.getvalue())
    try:
        loop.run_until_complete(cap.mw(Req(), err_next))
        raised = False
    except RuntimeError:
        raised = True
    chk('middleware: pengecualian diteruskan dan dihitung 5xx', raised and P.METRICS.snapshot()['by_class'].get('5xx') == 2)
    chk('log tidak memuat query/token', 'token' not in lines.getvalue().lower())
    # /ready ketika DB mati -> 503
    resp = cap.routes[('GET', '/ready')]()
    chk('/ready: DB mati -> 503 tanpa detail galat', getattr(resp, 'status_code', 200) == 503 and b'mati' not in resp.body)
    loop.close()
    lg.removeHandler(h)

    # --- model laporan backup
    from pydantic import ValidationError
    bad = 0
    for kw in ({'kind': 'x', 'ok': True}, {'kind': 'backup', 'ok': True, 'sha256': 'zz'}, {'kind': 'backup', 'ok': True, 'bytes': -1},
               {'kind': 'backup', 'ok': True, 'detail': 'a' * 801}):
        try:
            P.BackupReportIn(**kw)
        except ValidationError:
            bad += 1
    chk('BackupReportIn menolak kind/sha256/bytes/detail tidak valid', bad == 4)
    chk('BackupReportIn menerima laporan sah', P.BackupReportIn(kind='restore_drill', ok=True, bytes=10, sha256='a' * 64).ok is True)


# ============================================================ B. anak: main.py penuh per backend
def child_main(backend, schema):
    work = tempfile.mkdtemp()
    for k in ('OPENAI_API_KEY', 'GEMINI_API_KEY', 'RENDER'):
        os.environ.pop(k, None)
    env = {'NCK_DB_BACKEND': backend, 'NCK_DB_PATH': work + '/t.db', 'NCK_BACKUP_DIR': work + '/b', 'NCK_WORKER_CONCURRENCY': '1',
           'NCK_ADMIN_TOKEN': A, 'NCK_OPERATOR_TOKEN': O, 'NCK_VIEWER_TOKEN': V, 'NCK_CORS_ORIGINS': 'https://front.example'}
    if backend == 'postgres':
        env.update({'NCK_POSTGRES_DSN': DSN, 'NCK_POSTGRES_SCHEMA': schema})
    os.environ.update(env)
    _bootstrap.install()
    import main as M
    import nck_ops_v35 as P
    from fastapi import HTTPException
    for h in _bootstrap.startup_handlers(M):
        h()
    out = {}
    ep = lambda m, p: _bootstrap.endpoint(M, m, p)  # noqa: E731
    chk = lambda n, c: out.__setitem__(n, bool(c))  # noqa: E731

    def code_of(fn, *a, **k):
        try:
            fn(*a, **k)
            return 200
        except HTTPException as e:
            return e.status_code

    def dep_of(handler):
        """Fungsi dependensi hak akses sebuah endpoint (stub: default itu sendiri; FastAPI asli: Depends.dependency)."""
        import inspect
        d = inspect.signature(handler).parameters['role'].default
        return getattr(d, 'dependency', d)
    try:
        r = ep('GET', '/ready')()
        chk('/ready 200 dan ready=true', r['ready'] is True and r['db_ms'] is not None)
        chk('/ready tidak memuat rahasia', not any(s in json.dumps(r) for s in (A, O, V)))
        s = ep('GET', '/api/v35/ops/status')('viewer')
        chk('ops/status: versi 35, database sesuai backend, uptime >= 0', s['version'] == '35.0.0' and s['database'] == backend and s['uptime_seconds'] >= 0)
        chk('ops/status: platform lainnya di luar Render', s['platform'] == 'lainnya')
        os.environ['RENDER'] = 'true'
        os.environ['RENDER_GIT_COMMIT'] = 'abc123def456'
        s2 = ep('GET', '/api/v35/ops/status')('viewer')
        chk('ops/status membaca RENDER dan RENDER_GIT_COMMIT', s2['platform'] == 'render' and s2['release']['commit'] == 'abc123def456')
        rd = ep('GET', '/api/v35/ops/readiness')(Req(), 'viewer')
        ids = {c['id']: c for c in rd['checks']}
        chk('readiness: bentuk lengkap (checks, summary, limits, verdict)', rd['checks'] and rd['limits'] and rd['summary']['verdict'] in ('belum_siap', 'siap_dengan_catatan', 'lulus_pemeriksaan_otomatis'))
        chk('readiness: db_ping pass dari database nyata', ids['db_ping']['status'] == 'pass')
        chk('readiness: dev (bukan production) -> env_production warn', ids['env_production']['status'] == 'warn')
        if backend == 'sqlite':
            chk('readiness: SQLite + RENDER=true -> database_durable fail (nyata)', ids['database_durable']['status'] == 'fail' and rd['summary']['verdict'] == 'belum_siap')
        else:
            chk('readiness: PostgreSQL -> database_durable pass (nyata)', ids['database_durable']['status'] == 'pass')
        chk('readiness: belum ada backup -> warn', ids['backup_recent']['status'] == 'warn' and ids['restore_drill']['status'] == 'warn')
        chk('readiness: JSON tidak memuat token', not any(s_ in json.dumps(rd) for s_ in (A, O, V)))
        os.environ.pop('RENDER', None)
        # metrik dari middleware belum aktif pada stub (tidak ada request nyata); struktur harus valid
        mt = ep('GET', '/api/v35/ops/metrics')('viewer')
        chk('metrics: struktur valid + antrean tugas + db', 'latency_ms' in mt and mt['db']['ok'] is True and set(mt['task_runs']) == {'queued', 'running', 'completed', 'failed'})
        # laporan backup
        dep = dep_of(ep('POST', '/api/v35/ops/backup-report'))
        chk('backup-report: operator ditolak 403', code_of(dep, 'operator') == 403)
        chk('backup-report: viewer ditolak 403', code_of(dep, 'viewer') == 403)
        chk('backup-report: admin lolos dependensi', code_of(dep, 'admin') == 200)
        r1 = ep('POST', '/api/v35/ops/backup-report')(P.BackupReportIn(kind='backup', ok=True, bytes=1234, sha256='A' * 64, detail='uji'), 'admin')
        chk('backup-report: admin sukses', r1['status'] == 'recorded')
        ep('POST', '/api/v35/ops/backup-report')(P.BackupReportIn(kind='restore_drill', ok=True, bytes=1234), 'admin')
        ep('POST', '/api/v35/ops/backup-report')(P.BackupReportIn(kind='backup', ok=False, detail='gagal'), 'admin')
        lst = ep('GET', '/api/v35/ops/backups')(30, 'operator')
        chk('backups: 3 laporan, terbaru di atas, sha256 huruf kecil', len(lst['items']) == 3 and lst['items'][0]['ok'] == 0 and lst['items'][2]['sha256'] == 'a' * 64)
        dep2 = dep_of(ep('GET', '/api/v35/ops/backups'))
        chk('backups: viewer ditolak 403, operator lolos', code_of(dep2, 'viewer') == 403 and code_of(dep2, 'operator') == 200)
        rd = ep('GET', '/api/v35/ops/readiness')(Req(), 'viewer')
        ids = {c['id']: c for c in rd['checks']}
        chk('readiness: backup GAGAL tidak dihitung; backup sukses dihitung', ids['backup_recent']['status'] == 'pass')
        chk('readiness: drill sukses -> pass', ids['restore_drill']['status'] == 'pass')
        audit_rows = M.conn().execute("SELECT COUNT(*) FROM audit WHERE action='v35.backup_report'").fetchone()[0]
        chk('audit mencatat laporan backup (3)', audit_rows == 3)
        # ---- rotasi token tanpa putus
        OLD, NEW = 'OLD-' + 'q' * 40, 'NEW-' + 'n' * 40
        os.environ['NCK_VIEWER_TOKEN'] = NEW
        chk('rotasi: token LAMA belum diset -> ditolak 403', code_of(M.auth, OLD) == 403)
        os.environ['NCK_VIEWER_TOKEN_PREVIOUS'] = OLD
        chk('rotasi: token LAMA diterima sebagai viewer', M.auth(OLD) == 'viewer')
        chk('rotasi: token BARU diterima sebagai viewer', M.auth(NEW) == 'viewer')
        chk('rotasi: token LAMA tidak naik peran', M.auth(OLD) != 'admin')
        rd = ep('GET', '/api/v35/ops/readiness')(Req(), 'viewer')
        rot = next(c for c in rd['checks'] if c['id'] == 'tokens_rotation')
        chk('rotasi: readiness warn + catatan "dipakai ... menit lalu" tanpa token', rot['status'] == 'warn' and 'menit lalu' in rot['detail'] and OLD not in json.dumps(rd))
        os.environ['NCK_OPERATOR_TOKEN_PREVIOUS'] = A  # sama dengan token admin saat ini: tidak boleh jadi pintu naik peran
        chk('rotasi: PREVIOUS operator = token admin saat ini -> tetap admin (tidak menimpa)', M.auth(A) == 'admin')
        os.environ.pop('NCK_OPERATOR_TOKEN_PREVIOUS')
        os.environ.pop('NCK_VIEWER_TOKEN_PREVIOUS')
        chk('rotasi: setelah PREVIOUS dihapus token lama ditolak 403', code_of(M.auth, OLD) == 403)
        chk('rotasi: token baru tetap berlaku', M.auth(NEW) == 'viewer')
        chk('auth: tanpa token 401', code_of(M.auth, None) == 401)
        chk('v35 status endpoint tidak mengklaim production_ready', ep('GET', '/api/v35/status')('viewer')['production_ready'] is False)
    except Exception as exc:  # noqa: BLE001
        import traceback
        traceback.print_exc()
        out['_exception'] = False
        out['_exception_detail'] = repr(exc)[:300]
    print('RESULT:' + json.dumps(out))
    sys.stdout.flush()
    os._exit(0)


# ============================================================ C. anak: skenario produksi
def child_prod(scenario):
    work = tempfile.mkdtemp()
    base = {'NCK_ENV': 'production', 'NCK_DB_BACKEND': 'sqlite', 'NCK_DB_PATH': work + '/t.db', 'NCK_BACKUP_DIR': work + '/b',
            'NCK_ADMIN_TOKEN': A, 'NCK_OPERATOR_TOKEN': O, 'NCK_VIEWER_TOKEN': V, 'NCK_CORS_ORIGINS': 'https://front.example'}
    extra = {'ok': {}, 'prev_ok': {'NCK_VIEWER_TOKEN_PREVIOUS': 'old-' + 'x' * 40},
             'prev_short': {'NCK_VIEWER_TOKEN_PREVIOUS': 'pendek'},
             'prev_equal': {'NCK_VIEWER_TOKEN_PREVIOUS': A},
             'weak': {'NCK_ADMIN_TOKEN': 'lemah'}, 'cors_star': {'NCK_CORS_ORIGINS': '*'}}[scenario]
    os.environ.update(base)
    os.environ.update(extra)
    _bootstrap.install()
    import main as M
    res = {'ok': True, 'error': ''}
    try:
        M.v31_security_startup()
    except RuntimeError as e:
        res = {'ok': False, 'error': str(e)}
    print('RESULT:' + json.dumps(res))
    sys.stdout.flush()
    os._exit(0)


# ============================================================ orkestrator
def run_child(args):
    env = dict(os.environ)
    pp = _bootstrap.pythonpath_for_children()
    if pp:
        env['PYTHONPATH'] = pp + os.pathsep + env.get('PYTHONPATH', '')
    p = subprocess.run([sys.executable, __file__, '--child'] + args, capture_output=True, text=True, env=env, timeout=600)
    for line in reversed(p.stdout.splitlines()):
        if line.startswith('RESULT:'):
            return json.loads(line[7:]), p.stderr[-1500:]
    return None, p.stderr[-1500:] + p.stdout[-500:]


def main():
    failed, total = [], 0

    def show(name, ok):
        nonlocal total
        total += 1
        print(('PASS  ' if ok else 'FAIL  ') + name)
        if not ok:
            failed.append(name)
    out = {}
    part_a(out)
    for k, v in out.items():
        show(k, v)
    backends = [('sqlite', '')] + ([('postgres', 'nck_t35_a')] if DSN else [])
    for backend, schema in backends:
        if backend == 'postgres':
            import psycopg
            with psycopg.connect(DSN) as c:
                c.cursor().execute(f'DROP SCHEMA IF EXISTS {schema} CASCADE')
        res, err = run_child(['main', backend, schema])
        if res is None:
            show(f'[{backend}] anak proses crash: {err}', False)
            continue
        for k, v in res.items():
            if k.endswith('_detail'):
                print('      detail:', v)
                continue
            show(f'[{backend}] {k}', v)
        if backend == 'postgres':
            with psycopg.connect(DSN) as c:
                c.cursor().execute(f'DROP SCHEMA IF EXISTS {schema} CASCADE')
    # skenario produksi
    exp = {'ok': (True, ''), 'prev_ok': (True, ''), 'prev_short': (False, 'NCK_VIEWER_TOKEN_PREVIOUS'),
           'prev_equal': (False, 'must differ'), 'weak': (False, 'NCK_ADMIN_TOKEN'), 'cors_star': (False, 'NCK_CORS_ORIGINS')}
    for sc, (want_ok, needle) in exp.items():
        res, err = run_child(['prod', sc])
        good = res is not None and res['ok'] == want_ok and (want_ok or needle in res['error'])
        leak = res is not None and any(s in res['error'] for s in (A, O, V))
        show(f'[produksi:{sc}] start {"diterima" if want_ok else "DITOLAK dengan pesan jelas"}', good and not leak)
    print(f'\nRINGKAS: {total - len(failed)}/{total} lulus' + ('' if not failed else ' | GAGAL: ' + str(failed)))
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--child':
        if sys.argv[2] == 'main':
            child_main(sys.argv[3], sys.argv[4])
        else:
            child_prod(sys.argv[3])
    else:
        main()
