"""Uji balapan DDL: banyak proses start SERENTAK pada skema PostgreSQL kosong (mis. API + worker pertama kali nyala bersamaan).
Tanpa penanganan, CREATE SCHEMA/TABLE/INDEX ... IF NOT EXISTS yang bersamaan dapat gagal dengan 'duplicate key ... pg_*_index'.
Butuh PostgreSQL: env NCK_TEST_PG_DSN (default shim lokal)."""
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import _bootstrap  # noqa: E402

DSN = os.environ.get('NCK_TEST_PG_DSN', 'postgresql://postgres@/nck_test')
S = 'nck_t34_race'
N, ROUNDS = 6, 4
TABLES = 8


def child(start_at):
    _bootstrap.install()
    import nck_db
    while time.time() < float(start_at):
        time.sleep(0.001)
    nck_db.ensure_schema()
    with nck_db.connect(os.environ['NCK_DB_PATH']) as c:
        for i in range(TABLES):
            c.execute(f'CREATE TABLE IF NOT EXISTS race_t{i}(id INTEGER PRIMARY KEY AUTOINCREMENT, nama TEXT, ts TEXT)')
            c.execute(f'CREATE INDEX IF NOT EXISTS ix_race_t{i} ON race_t{i}(nama)')
    print('RESULT:ok')
    sys.stdout.flush()
    os._exit(0)


def main():
    _bootstrap.install()
    import psycopg
    pp = _bootstrap.pythonpath_for_children()
    env = dict(os.environ)
    if pp:
        env['PYTHONPATH'] = pp + os.pathsep + env.get('PYTHONPATH', '')
    env.update({'NCK_DB_BACKEND': 'postgres', 'NCK_POSTGRES_DSN': DSN, 'NCK_POSTGRES_SCHEMA': S, 'NCK_DB_PATH': '/tmp/unused_race.db'})
    gagal_total = 0
    for rnd in range(1, ROUNDS + 1):
        with psycopg.connect(DSN) as c:
            c.execute(f'DROP SCHEMA IF EXISTS {S} CASCADE')
        start = time.time() + 4.0
        ps = [subprocess.Popen([sys.executable, __file__, '--child', str(start)], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               text=True, env=env) for _ in range(N)]
        bad = []
        for p in ps:
            so, se = p.communicate(timeout=180)
            if p.returncode != 0 or 'RESULT:ok' not in so:
                bad.append(se.strip().splitlines()[-1][:200] if se.strip() else f'exit={p.returncode}')
        print(f'ronde {rnd}: {N - len(bad)}/{N} proses sukses' + (f'  GAGAL: {bad[:2]}' if bad else ''), flush=True)
        gagal_total += len(bad)
    with psycopg.connect(DSN) as c:
        c.execute(f'DROP SCHEMA IF EXISTS {S} CASCADE')
    ok = gagal_total == 0
    print('PASS  start serentak pada skema kosong tanpa galat DDL' if ok else f'FAIL  {gagal_total} proses gagal', flush=True)
    print(f'\nRINGKAS: {"1/1" if ok else "0/1"} lulus')
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    if len(sys.argv) > 2 and sys.argv[1] == '--child':
        child(sys.argv[2])
    else:
        main()
