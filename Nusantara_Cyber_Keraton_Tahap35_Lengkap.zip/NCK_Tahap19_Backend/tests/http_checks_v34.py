"""Uji HTTP NYATA Tahap 34 terhadap server uvicorn yang sedang berjalan (FastAPI asli, middleware asli, PostgreSQL/SQLite asli).

Hanya pustaka standar. Server AI palsu (kompatibel OpenAI dan Ollama) dijalankan di sini pada 127.0.0.1:NCK_FAKE_AI_PORT (default 9911)
sehingga alur AI (chat, orkestrasi, kolaborasi, antrean worker) berjalan lewat httpx sungguhan TANPA kunci AI asli.

Env yang dibaca:
  NCK_HTTP_BASE (default http://127.0.0.1:8000), NCK_ADMIN_TOKEN / NCK_OPERATOR_TOKEN / NCK_VIEWER_TOKEN,
  NCK_CORS_ORIGINS (bila diisi, CORS ikut diuji), NCK_FAKE_AI_PORT.
Server harus dijalankan dengan:
  OPENAI_API_KEY=ci-fake-key OPENAI_BASE_URL=http://127.0.0.1:9911/v1 NCK_OLLAMA_URL=http://127.0.0.1:9911
  (tanpa GEMINI_API_KEY), NCK_RATE_LIMIT=3000 NCK_EXPENSIVE_RATE_LIMIT=300.
Keluar dengan kode 1 bila ada cek gagal.
"""
import http.client
import io
import json
import os
import secrets
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

BASE = os.environ.get('NCK_HTTP_BASE', 'http://127.0.0.1:8000').rstrip('/')
ADMIN = os.environ.get('NCK_ADMIN_TOKEN', '')
OPER = os.environ.get('NCK_OPERATOR_TOKEN', '')
VIEW = os.environ.get('NCK_VIEWER_TOKEN', '')
CORS_ORIGIN = (os.environ.get('NCK_CORS_ORIGINS', '').split(',')[0] or '').strip()
FAKE_PORT = int(os.environ.get('NCK_FAKE_AI_PORT', '9911'))

RESULTS = []


def check(name, cond, detail=''):
    RESULTS.append((name, bool(cond), detail))
    print(('PASS  ' if cond else 'FAIL  ') + name + ('' if cond else '   :: ' + str(detail)[:400]), flush=True)


# ------------------------------------------------------------------ server AI palsu
FAKE_STATS = {'chat': 0, 'review': 0}


class FakeAI(BaseHTTPRequestHandler):
    def log_message(self, *a):  # senyap
        pass

    def do_POST(self):
        n = int(self.headers.get('Content-Length') or 0)
        try:
            body = json.loads(self.rfile.read(n) or b'{}')
        except ValueError:
            body = {}
        msgs = body.get('messages') or []
        system = msgs[0].get('content', '') if msgs else ''
        user = msgs[-1].get('content', '') if msgs else ''
        if 'reviewer AI independen' in system or '"score":0-100' in user:
            FAKE_STATS['review'] += 1
            text = '{"score":88,"feedback":"Hasil memadai (server AI palsu uji)."}'
        else:
            FAKE_STATS['chat'] += 1
            text = 'HASIL-AI-UJI: ' + ' '.join(user.split())[:80]
        if self.path.endswith('/chat/completions'):
            out = {'choices': [{'message': {'role': 'assistant', 'content': text}}], 'usage': {'prompt_tokens': 7, 'completion_tokens': 9}}
        elif self.path.endswith('/api/chat'):
            out = {'message': {'role': 'assistant', 'content': text}, 'prompt_eval_count': 7, 'eval_count': 9}
        else:
            self.send_response(404)
            self.end_headers()
            return
        raw = json.dumps(out).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)


def start_fake_ai():
    srv = ThreadingHTTPServer(('127.0.0.1', FAKE_PORT), FakeAI)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


# ------------------------------------------------------------------ klien HTTP
def call(method, path, token=None, body=None, raw=None, ctype=None, headers=None, timeout=90):
    h = {'Accept': 'application/json'}
    if token:
        h['X-NCK-Token'] = token
    data = None
    if raw is not None:
        data = raw
        if ctype:
            h['Content-Type'] = ctype
    elif body is not None:
        data = json.dumps(body).encode()
        h['Content-Type'] = 'application/json'
    h.update(headers or {})
    req = urllib.request.Request(BASE + path, data=data, method=method, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            code, txt, hd = r.status, r.read(), r.headers
    except urllib.error.HTTPError as e:
        code, txt, hd = e.code, e.read(), e.headers
    try:
        js = json.loads(txt)
    except ValueError:
        js = None
    return code, js, hd


def detail_of(js):
    return json.dumps(js, ensure_ascii=False)[:300] if js is not None else ''


def multipart(fields, filename, content, ctype='text/plain'):
    b = '----nck' + secrets.token_hex(8)
    parts = []
    for k, v in fields.items():
        parts.append(f'--{b}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
    parts.append((f'--{b}\r\nContent-Disposition: form-data; name="file"; filename="{filename}"\r\n'
                  f'Content-Type: {ctype}\r\n\r\n').encode() + content + b'\r\n')
    parts.append(f'--{b}--\r\n'.encode())
    return b''.join(parts), f'multipart/form-data; boundary={b}'


def make_docx(text):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', '<?xml version="1.0"?><Types/>')
        z.writestr('word/document.xml', '<?xml version="1.0"?><w:document><w:body><w:p><w:r><w:t>' + text + '</w:t></w:r></w:p></w:body></w:document>')
    return buf.getvalue()


def wait_for(fn, timeout, interval=0.7):
    t0 = time.time()
    while time.time() - t0 < timeout:
        v = fn()
        if v:
            return v
        time.sleep(interval)
    return None


# ------------------------------------------------------------------ skenario
def scenario():
    # ---- A. dasar & autentikasi
    c, js, _ = call('GET', '/health')
    check('A1 /health 200', c == 200, c)
    c, js, _ = call('GET', '/api/v34/status')
    check('A2 tanpa token -> 401', c == 401, (c, detail_of(js)))
    c, js, _ = call('GET', '/api/v34/status', token='token-salah-0123456789')
    check('A3 token salah -> 403', c == 403, (c, detail_of(js)))
    c, js, _ = call('GET', '/api/v34/status', VIEW)
    check('A4 viewer baca status 200, role=viewer, 50 agen', c == 200 and js and js.get('role') == 'viewer' and js.get('agents') == 50, (c, detail_of(js)))
    check('A5 status melaporkan provider AI terkonfigurasi (OpenAI + Ollama palsu)', js and js['providers']['openai_configured'] and js['providers']['ollama_configured'] and not js['providers']['gemini_configured'], js and js.get('providers'))

    # ---- B. matriks RBAC (dependensi dievaluasi sebelum validasi body -> harus 403 persis)
    ok_body = {
        'chat': {'message': 'halo', 'provider': 'ollama'},
        'orch': {'goal': 'tujuan uji', 'tasks': [{'id': 't1', 'name': 'A', 'role': 'r', 'instruction': 'kerjakan'}], 'provider': 'ollama'},
        'kb': {'title': 'Judul', 'category': 'Uji', 'content': 'isi'},
        'compare': {'question': 'bandingkan ini', 'sources': [{'title': 'a', 'source_id': 'x'}, {'title': 'b', 'source_id': 'y'}], 'provider': 'ollama'},
        'auto': {'goal': 'tujuan uji', 'tasks': [{'id': 't1', 'agent_id': '24', 'instruction': 'kerjakan'}], 'provider': 'ollama'},
        'proj': {'name': 'Proyek RBAC', 'description': ''},
        'mem': {'title': 'M', 'content': 'c'},
        'tnew': {'title': 'T', 'agent_id': '24', 'priority': 'normal'},
        'tpatch': {'status': 'completed'},
        'dec': {'decision': 'approved', 'note': ''},
        'sched': {'project_id': 'x', 'title': 'S', 'due_at': '2030-01-01T00:00:00Z'},
        'prep': {'project_id': 'x', 'task_ids': ['x'], 'goal': 'g'},
        'launch': {'approval_id': 'x'},
        'fb': {'task_id': 'x', 'rating': 4, 'notes': ''},
        'summ': {'provider': 'ollama'},
    }
    operator_writes = [
        ('POST', '/api/chat', ok_body['chat']), ('POST', '/api/orchestrate', ok_body['orch']),
        ('POST', '/api/knowledge', ok_body['kb']), ('DELETE', '/api/knowledge/abc', None),
        ('DELETE', '/api/documents/abc', None), ('POST', '/api/documents/abc/summarize', ok_body['summ']),
        ('POST', '/api/intelligence/compare', ok_body['compare']), ('POST', '/api/autonomous/run', ok_body['auto']),
        ('POST', '/api/collaboration/run', ok_body['auto']),
        ('POST', '/api/v13/projects', ok_body['proj']), ('POST', '/api/v13/projects/abc/memory', ok_body['mem']),
        ('POST', '/api/v13/projects/abc/tasks', ok_body['tnew']), ('PATCH', '/api/v13/tasks/abc', ok_body['tpatch']),
        ('POST', '/api/v13/approvals/abc', ok_body['dec']), ('POST', '/api/v13/schedules', ok_body['sched']),
        ('POST', '/api/v13/scheduler/tick', None), ('POST', '/api/v14/prepare-run', ok_body['prep']),
        ('POST', '/api/v14/launch-approved', ok_body['launch']), ('POST', '/api/v14/runs/abc/sync', None),
        ('POST', '/api/v15/feedback', ok_body['fb']),
    ]
    admin_only = [('GET', '/api/v13/backup', None), ('POST', '/api/v13/restore', {'format': 'x', 'tables': {}})]
    bad = []
    for m, p, b in operator_writes:
        c, js, _ = call(m, p, VIEW, body=b)
        if c != 403:
            bad.append(f'viewer {m} {p} -> {c}')
        c, _, _ = call(m, p, None, body=b)
        if c != 401:
            bad.append(f'anon {m} {p} -> {c}')
    check(f'B1 viewer ditolak 403 & anonim 401 pada {len(operator_writes)} endpoint tulis/AI', not bad, bad[:4])
    bad = []
    for m, p, b in admin_only:
        for tok, name in ((VIEW, 'viewer'), (OPER, 'operator')):
            c, js, _ = call(m, p, tok, body=b)
            if c != 403:
                bad.append(f'{name} {m} {p} -> {c}')
    check('B2 backup/restore hanya admin (viewer & operator 403)', not bad, bad)
    viewer_reads = ['/api/knowledge', '/api/documents', '/api/agents', '/api/intelligence/graph', '/api/v13/overview', '/api/v13/projects',
                    '/api/v13/approvals', '/api/v13/schedules', '/api/v13/audit', '/api/v13/analytics/agents', '/api/v14/runs',
                    '/api/v15/learning/overview', '/api/v15/feedback/tasks', '/api/autonomous/logs', '/api/collaboration/logs']
    bad = []
    for p in viewer_reads:
        c, js, _ = call('GET', p, VIEW)
        if c != 200:
            bad.append(f'{p} -> {c} {detail_of(js)[:80]}')
    check(f'B3 viewer boleh membaca {len(viewer_reads)} endpoint GET (200)', not bad, bad[:3])
    viewer_posts = [('/api/knowledge/search', {'query': 'uji'}), ('/api/documents/search', {'query': 'uji'}), ('/api/intelligence/search', {'query': 'uji'}),
                    ('/api/autonomous/plan', {'goal': 'riset pasar produk baru'}), ('/api/collaboration/plan', {'goal': 'riset pasar produk baru'}),
                    ('/api/v15/route', {'goal': 'analisis bisnis'})]
    bad = []
    for p, b in viewer_posts:
        c, js, _ = call('POST', p, VIEW, body=b)
        if c != 200:
            bad.append(f'{p} -> {c} {detail_of(js)[:80]}')
    check('B4 viewer boleh pencarian/perencanaan lokal (POST baca-saja) 200', not bad, bad[:3])
    c, js, _ = call('GET', '/api/agents', VIEW)
    check('B5 direktori agen 50 entri', c == 200 and len(js['agents']) == 50, (c, detail_of(js)))

    # ---- C. CORS (preflight metode DELETE/PATCH yang dipakai panel)
    if CORS_ORIGIN:
        for meth in ('DELETE', 'PATCH', 'POST'):
            c, _, hd = call('OPTIONS', '/api/knowledge/abc', headers={'Origin': CORS_ORIGIN, 'Access-Control-Request-Method': meth,
                                                                  'Access-Control-Request-Headers': 'x-nck-token,content-type'})
            allow = (hd.get('access-control-allow-methods') or '') if hd else ''
            check(f'C {meth}: preflight CORS diizinkan', c == 200 and meth in allow and hd.get('access-control-allow-origin') == CORS_ORIGIN, (c, allow))
        c, _, hd = call('OPTIONS', '/api/knowledge', headers={'Origin': 'http://jahat.example', 'Access-Control-Request-Method': 'POST'})
        check('C origin asing ditolak (tanpa allow-origin)', not (hd.get('access-control-allow-origin') if hd else None), hd and hd.get('access-control-allow-origin'))

    # ---- D. knowledge base
    c, kb, _ = call('POST', '/api/knowledge', OPER, body={'title': 'Strategi Kopi Nusantara', 'category': 'Bisnis', 'tags': ['kopi', 'ekspor'],
                                                         'content': 'Rencana ekspor kopi arabika Gayo ke pasar Jepang dan Eropa.'})
    check('D1 operator menambah catatan knowledge', c == 200 and kb and kb.get('id'), (c, detail_of(kb)))
    kid = (kb or {}).get('id', 'x')
    c, js, _ = call('POST', '/api/knowledge/search', VIEW, body={'query': 'ekspor kopi arabika'})
    check('D2 pencarian leksikal menemukan catatan', c == 200 and any(i.get('id') == kid for i in js.get('items', [])), (c, detail_of(js)))
    c, js, _ = call('DELETE', f'/api/knowledge/{kid}', OPER)
    check('D3 hapus catatan 200', c == 200 and js.get('deleted') == kid, (c, detail_of(js)))
    c, js, _ = call('DELETE', f'/api/knowledge/{kid}', OPER)
    check('D4 hapus ulang -> 404', c == 404, (c, detail_of(js)))
    c, js, _ = call('POST', '/api/knowledge', OPER, body={'title': '', 'content': 'x'})
    check('D5 validasi body: judul kosong -> 422', c == 422, (c, detail_of(js)))

    # ---- E. dokumen (multipart nyata)
    body, ct = multipart({'title': 'Catatan Rapat Uji', 'category': 'Rapat'}, 'rapat.txt',
                         'Rapat membahas anggaran logistik pelabuhan Makassar dan jadwal pengiriman rempah.'.encode())
    c, up, _ = call('POST', '/api/documents/upload', OPER, raw=body, ctype=ct)
    check('E1 unggah TXT multipart 200', c == 200 and up and up.get('char_count', 0) > 20, (c, detail_of(up)))
    did = (up or {}).get('id', 'x')
    c, js, _ = call('POST', '/api/documents/search', VIEW, body={'query': 'logistik pelabuhan Makassar'})
    check('E2 pencarian dokumen menemukan unggahan', c == 200 and any(i.get('id') == did for i in js.get('items', [])), (c, detail_of(js)))
    c, js, _ = call('GET', f'/api/documents/{did}', VIEW)
    check('E3 baca dokumen 200', c == 200, (c, detail_of(js)))
    c, js, _ = call('POST', f'/api/documents/{did}/summarize', OPER, body={'provider': 'ollama'})
    check('E4 ringkasan dokumen lewat Ollama palsu', c == 200 and js and 'HASIL-AI-UJI' in js.get('summary', ''), (c, detail_of(js)))
    body, ct = multipart({}, 'laporan.docx', make_docx('Laporan triwulan pengiriman rempah ke Surabaya'), 'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
    c, js, _ = call('POST', '/api/documents/upload', OPER, raw=body, ctype=ct)
    check('E5 unggah DOCX: teks terekstrak', c == 200 and js and js.get('char_count', 0) > 10 and js.get('file_type') == 'docx', (c, detail_of(js)))
    body, ct = multipart({}, 'virus.exe', b'MZ\x90\x00')
    c, js, _ = call('POST', '/api/documents/upload', OPER, raw=body, ctype=ct)
    check('E6 format tidak didukung -> 415', c == 415, (c, detail_of(js)))
    body, ct = multipart({}, 'palsu.docx', b'bukan zip sama sekali')
    c, js, _ = call('POST', '/api/documents/upload', OPER, raw=body, ctype=ct)
    check('E7 DOCX palsu -> 422', c == 422, (c, detail_of(js)))
    # unggahan melebihi batas: boleh 413 dari server, atau koneksi diputus server sebelum body habis dikirim
    big = b'a' * (12 * 1024 * 1024 + 300 * 1024)
    body, ct = multipart({}, 'besar.txt', big)
    status = None
    try:
        u = urllib.parse.urlparse(BASE)
        hc = http.client.HTTPConnection(u.hostname, u.port, timeout=60)
        hc.putrequest('POST', '/api/documents/upload')
        hc.putheader('X-NCK-Token', OPER)
        hc.putheader('Content-Type', ct)
        hc.putheader('Content-Length', str(len(body)))
        hc.endheaders()
        try:
            hc.send(body)
        except (BrokenPipeError, ConnectionResetError):
            pass
        try:
            status = hc.getresponse().status
        except (ConnectionResetError, http.client.RemoteDisconnected, BrokenPipeError):
            status = 'koneksi-diputus'
    finally:
        try:
            hc.close()
        except Exception:  # noqa: BLE001
            pass
    check('E8 unggahan > batas ditolak (413 atau koneksi diputus)', status in (413, 'koneksi-diputus'), status)
    c, js, _ = call('DELETE', f'/api/documents/{did}', OPER)
    check('E9 hapus dokumen 200', c == 200, (c, detail_of(js)))

    # ---- F. AI lewat HTTP: provider nyata (palsu) vs tidak dikonfigurasi
    c, js, _ = call('POST', '/api/chat', OPER, body={'message': 'Apa kabar Nusantara?', 'provider': 'ollama'})
    check('F1 chat via Ollama palsu: balasan bersumber dari server AI', c == 200 and js and js['reply'].startswith('HASIL-AI-UJI'), (c, detail_of(js)))
    c, js, _ = call('POST', '/api/chat', OPER, body={'message': 'Apa kabar?', 'provider': 'openai'})
    check('F2 chat via OpenAI-compatible palsu (OPENAI_BASE_URL)', c == 200 and js and js['reply'].startswith('HASIL-AI-UJI'), (c, detail_of(js)))
    c, js, _ = call('POST', '/api/chat', OPER, body={'message': 'Apa kabar?', 'provider': 'gemini'})
    check('F3 Gemini tanpa kunci -> 503 dengan pesan jelas (bukan hasil palsu)', c == 503 and 'GEMINI_API_KEY' in json.dumps(js), (c, detail_of(js)))
    c, js, _ = call('POST', '/api/chat', OPER, body={'message': 'x', 'provider': 'ollama', 'model': 'bad model;rm -rf /'})
    check('F4 nama model berbahaya ditolak/diabaikan (tidak 500)', c in (200, 400, 422), (c, detail_of(js)))
    c, js, _ = call('POST', '/api/orchestrate', OPER, body={'goal': 'Susun rencana peluncuran produk', 'provider': 'ollama', 'tasks': [
        {'id': 't1', 'name': 'Riset', 'role': 'Analis', 'instruction': 'Riset pasar'}, {'id': 't2', 'name': 'Strategi', 'role': 'Strategis', 'instruction': 'Susun strategi'}]})
    check('F5 orkestrasi 2 agen: hasil gabungan + 2 hasil agen', c == 200 and js and js.get('final') and len(js.get('agent_results', [])) == 2, (c, detail_of(js)))
    c, js, _ = call('POST', '/api/autonomous/run', OPER, body={'goal': 'Riset dan ringkas pasar kopi', 'provider': 'ollama', 'tasks': [
        {'id': 't1', 'title': 'Riset', 'agent_id': '24', 'instruction': 'Riset pasar kopi'},
        {'id': 't2', 'title': 'Evaluasi', 'agent_id': '50', 'instruction': 'Evaluasi hasil riset', 'depends_on': ['t1']}]})
    check('F6 autonomous/run (DAG 2 tugas) selesai + review skor 88', c == 200 and js and js.get('status') == 'completed' and (js.get('quality_review') or {}).get('score') == 88, (c, detail_of(js)))
    c, js, _ = call('POST', '/api/autonomous/run', OPER, body={'goal': 'Uji dependensi', 'provider': 'ollama', 'tasks': [
        {'id': 't1', 'title': 'A', 'agent_id': '24', 'instruction': 'x', 'depends_on': ['t9']}]})
    check('F7 dependensi ke tugas tak ada -> 422', c == 422, (c, detail_of(js)))

    # ---- G. kolaborasi (BackgroundTasks nyata) + log
    c, js, _ = call('POST', '/api/collaboration/run', OPER, body={'goal': 'Rencana ekspor kopi', 'provider': 'ollama', 'correction_rounds': 0, 'tasks': [
        {'id': 't1', 'title': 'Riset', 'agent_id': '24', 'instruction': 'Riset pasar'},
        {'id': 't2', 'title': 'Evaluasi', 'agent_id': '50', 'instruction': 'Evaluasi', 'depends_on': ['t1']}]})
    check('G1 kolaborasi mengembalikan run_id (status running)', c == 200 and js and js.get('run_id'), (c, detail_of(js)))
    rid = (js or {}).get('run_id', 'x')

    def finished():
        c2, j2, _ = call('GET', f'/api/collaboration/runs/{rid}', VIEW)
        return j2 if c2 == 200 and j2 and j2.get('status') in ('completed', 'partial', 'failed') else None
    fin = wait_for(finished, 90)
    check('G2 run kolaborasi (latar belakang) selesai: completed 2/2', fin and fin['status'] == 'completed' and fin['summary']['completed'] == 2, detail_of(fin))
    check('G3 hasil memuat review kualitas & event', fin and (fin.get('quality_review') or {}).get('score') == 88 and len(fin.get('events', [])) >= 4, detail_of(fin)[:200])
    c, js, _ = call('GET', '/api/collaboration/runs/tidak-ada', VIEW)
    check('G4 run tak dikenal -> 404', c == 404, c)

    # ---- H. proyek v13 + tugas + persetujuan v14 + pembelajaran v15
    nama = 'Proyek HTTP ' + secrets.token_hex(3)
    c, pj, _ = call('POST', '/api/v13/projects', OPER, body={'name': nama, 'description': 'uji http'})
    check('H1 buat proyek', c == 200 and pj and pj.get('id'), (c, detail_of(pj)))
    pid = (pj or {}).get('id', 'x')
    c, js, _ = call('POST', '/api/v13/projects', OPER, body={'name': nama})
    check('H2 nama proyek duplikat -> 409', c == 409, (c, detail_of(js)))
    c, js, _ = call('POST', f'/api/v13/projects/{pid}/memory', OPER, body={'title': 'Catatan', 'content': 'Penting'})
    check('H3 tambah memori proyek', c == 200, (c, detail_of(js)))
    c, t1, _ = call('POST', f'/api/v13/projects/{pid}/tasks', OPER, body={'title': 'Tugas Satu', 'agent_id': '24', 'priority': 'high'})
    c2, t2, _ = call('POST', f'/api/v13/projects/{pid}/tasks', OPER, body={'title': 'Tugas Dua', 'agent_id': '50'})
    check('H4 buat dua tugas', c == 200 and c2 == 200 and t1.get('id') and t2.get('id'), (c, c2))
    c, js, _ = call('POST', f'/api/v13/projects/{pid}/tasks', OPER, body={'title': 'Salah', 'priority': 'sangat-penting'})
    check('H5 prioritas tidak valid -> 422', c == 422, (c, detail_of(js)))
    c, js, _ = call('PATCH', f'/api/v13/tasks/{t1["id"]}', OPER, body={'status': 'completed', 'score': 4})
    check('H6 PATCH tugas completed skor 4 (metode PATCH lewat middleware asli)', c == 200 and js['status'] == 'completed' and js['score'] == 4, (c, detail_of(js)))
    c, js, _ = call('PATCH', f'/api/v13/tasks/{t1["id"]}', OPER, body={'score': 9})
    check('H7 skor di luar 1..5 -> 422', c == 422, (c, detail_of(js)))
    c, js, _ = call('POST', '/api/v14/prepare-run', OPER, body={'project_id': pid, 'task_ids': [t2['id']], 'goal': 'Kerjakan tugas dua', 'provider': 'openai', 'mode': 'sequential'})
    check('H8 prepare-run membuat approval pending', c == 200 and js.get('status') == 'pending', (c, detail_of(js)))
    aid = (js or {}).get('approval_id', 'x')
    c, js, _ = call('POST', '/api/v14/launch-approved', OPER, body={'approval_id': aid})
    check('H9 launch sebelum disetujui -> 409', c == 409, (c, detail_of(js)))
    c, js, _ = call('POST', f'/api/v13/approvals/{aid}', OPER, body={'decision': 'approved', 'note': 'ok'})
    check('H10 setujui approval', c == 200, (c, detail_of(js)))
    c, js, _ = call('POST', f'/api/v13/approvals/{aid}', OPER, body={'decision': 'rejected'})
    check('H11 keputusan ulang -> 409', c == 409, (c, detail_of(js)))
    c, js, _ = call('POST', '/api/v14/launch-approved', OPER, body={'approval_id': aid})
    check('H12 launch setelah disetujui 200 (running)', c == 200 and js.get('run_id'), (c, detail_of(js)))
    vrid = (js or {}).get('run_id', 'x')
    c, js, _ = call('POST', '/api/v14/launch-approved', OPER, body={'approval_id': aid})
    check('H13 launch ganda untuk approval yang sama -> 409', c == 409, (c, detail_of(js)))

    def v14_done():
        c3, j3, _ = call('GET', '/api/v14/runs', VIEW)
        for it in (j3 or {}).get('items', []):
            if it['run_id'] == vrid and it['status'] not in ('running', 'queued'):
                return it
        return None
    it = wait_for(v14_done, 90)
    check('H14 run v14 (latar belakang) selesai', it and it['status'] == 'completed', it)
    c, js, _ = call('POST', f'/api/v14/runs/{vrid}/sync', OPER)
    check('H15 sinkron hasil ke tugas proyek', c == 200 and js.get('synced') is True, (c, detail_of(js)))
    c, js, _ = call('GET', f'/api/v13/projects/{pid}/tasks', VIEW)
    done_tasks = [x for x in (js or {}).get('items', []) if x['status'] == 'completed']
    check('H16 kedua tugas kini completed', c == 200 and len(done_tasks) == 2, (c, [x['status'] for x in (js or {}).get('items', [])]))
    c, js, _ = call('POST', '/api/v15/feedback', OPER, body={'task_id': t2['id'], 'rating': 5, 'notes': 'bagus'})
    check('H17 feedback tugas selesai', c == 200, (c, detail_of(js)))
    c, js, _ = call('POST', '/api/v15/route', VIEW, body={'goal': 'analisis riset pasar bisnis kopi'})
    check('H18 routing agen mengembalikan saran', c == 200 and js, (c, detail_of(js)))
    c, js, _ = call('GET', '/api/v13/audit', VIEW)
    check('H19 audit mencatat aksi v34', c == 200 and any(str(x.get('action', '')).startswith('v34.') for x in (js or {}).get('items', [])), (c, detail_of(js)))

    # ---- I. backup / restore round trip (admin)
    c, bk, _ = call('GET', '/api/v13/backup', ADMIN)
    check('I1 backup admin 200 berformat nck-v34-backup', c == 200 and bk and bk.get('format') == 'nck-v34-backup' and bk['tables']['lg34_projects'], (c, detail_of(bk)[:200]))
    n_proj = len((bk or {}).get('tables', {}).get('lg34_projects', []))
    c, js, _ = call('POST', '/api/v13/restore', ADMIN, raw=json.dumps(bk).encode(), ctype='application/json')
    check('I2 restore backup yang sama 200', c == 200 and js and js['restored']['lg34_projects'] == n_proj, (c, detail_of(js)))
    c, js, _ = call('GET', '/api/v13/projects', VIEW)
    check('I3 data proyek utuh setelah restore', c == 200 and any(p['id'] == pid for p in (js or {}).get('items', [])), (c, detail_of(js)[:200]))
    c, js, _ = call('POST', '/api/v13/restore', ADMIN, raw=b'{bukan json', ctype='application/json')
    check('I4 restore JSON rusak -> 400, data tak berubah', c == 400, (c, detail_of(js)))
    c, js, _ = call('POST', '/api/v13/restore', ADMIN, body={'format': 'lain', 'tables': {}})
    check('I5 restore format asing -> 422', c == 422, (c, detail_of(js)))

    # ---- J. antrean worker (v22/v23) lewat HTTP + status terdistribusi
    pname = 'Antrean HTTP ' + secrets.token_hex(3)
    c, js, _ = call('POST', '/api/v22/projects', OPER, body={'name': pname, 'description': 'uji worker'})
    check('J0 buat proyek v22', c == 200, (c, detail_of(js)))
    c, js, _ = call('POST', '/api/v22/tasks', OPER, body={'project': pname, 'title': 'Tugas antrean uji', 'instruction': 'Tulis satu paragraf ringkas.', 'agent_id': 'ki_mandra', 'priority': 'normal'})
    check('J1 buat tugas v22', c == 200 and js.get('id'), (c, detail_of(js)))
    tid = (js or {}).get('id', 0)
    c, js, _ = call('POST', f'/api/v23/tasks/{tid}/execute', OPER, body={'provider': 'openai', 'max_retries': 0, 'review_enabled': False, 'review_threshold': 75})
    check('J2 tugas masuk antrean', c == 200 and js.get('status') == 'queued', (c, detail_of(js)))

    def q_done():
        c4, j4, _ = call('GET', f'/api/v23/tasks/{tid}/execution', VIEW)
        e = (j4 or {}).get('execution') or {}
        return e if c4 == 200 and e.get('status') in ('completed', 'failed') else None
    ex = wait_for(q_done, 90)
    check('J3 worker memproses tugas: completed dengan keluaran dari server AI', ex and ex['status'] == 'completed' and 'HASIL-AI-UJI' in (ex.get('output') or ''), ex)
    c, js, _ = call('GET', '/api/v34/distributed/status', VIEW)
    check('J4 status terdistribusi: mode both, worker hidup, antrean tercatat',
          c == 200 and js and js.get('mode') in ('both', 'api', 'worker') and js.get('workers_alive', 0) >= 1 and js['queue']['completed'] >= 1, (c, detail_of(js)))
    c, js, _ = call('GET', '/api/v34/distributed/status')
    check('J5 status terdistribusi tanpa token -> 401', c == 401, c)
    check('J6 server AI palsu benar-benar dipanggil (bukan hasil karangan)', FAKE_STATS['chat'] >= 8, FAKE_STATS)


def main():
    start_fake_ai()
    # tunggu server siap
    ok = wait_for(lambda: call('GET', '/health', timeout=5)[0] == 200, 60, 1)
    if not ok:
        print('Server tidak siap di', BASE)
        sys.exit(2)
    if not (ADMIN and OPER and VIEW):
        print('NCK_ADMIN_TOKEN / NCK_OPERATOR_TOKEN / NCK_VIEWER_TOKEN wajib diisi.')
        sys.exit(2)
    t0 = time.time()
    try:
        scenario()
    except Exception as exc:  # noqa: BLE001
        import traceback
        traceback.print_exc()
        check('SKENARIO BERJALAN TANPA PENGECUALIAN', False, repr(exc))
    ok = sum(1 for r in RESULTS if r[1])
    print(f'\nRINGKAS: {ok}/{len(RESULTS)} lulus ({time.time() - t0:.0f} dtk)')
    sys.exit(0 if ok == len(RESULTS) else 1)


if __name__ == '__main__':
    main()
