"""Uji beban RINGAN (smoke load) terhadap server yang sedang berjalan — hanya pustaka standar.

Tujuan: mendeteksi galat 5xx, penulisan yang hilang, dan kemacetan yang jelas di bawah konkurensi kecil.
BUKAN benchmark kapasitas produksi: berjalan di satu mesin runner CI, satu proses uvicorn, tanpa jaringan nyata.
Ambang (env): NCK_LOAD_THREADS=8, NCK_LOAD_REQUESTS=800, NCK_LOAD_P95_MS=3000.
Keluar dengan kode 1 bila ada 5xx/galat jaringan, penulisan hilang, atau p95 melebihi ambang."""
import json
import os
import random
import statistics
import sys
import threading
import time
import urllib.error
import urllib.request

BASE = os.environ.get('NCK_HTTP_BASE', 'http://127.0.0.1:8000').rstrip('/')
OPER = os.environ.get('NCK_OPERATOR_TOKEN', '')
VIEW = os.environ.get('NCK_VIEWER_TOKEN', '')
THREADS = int(os.environ.get('NCK_LOAD_THREADS', '8'))
TOTAL = int(os.environ.get('NCK_LOAD_REQUESTS', '800'))
P95_MS = float(os.environ.get('NCK_LOAD_P95_MS', '3000'))

LOCK = threading.Lock()
LAT, CODES, ERRS = [], {}, []
WRITES_OK = [0]


def req(method, path, token, body=None):
    data = json.dumps(body).encode() if body is not None else None
    h = {'X-NCK-Token': token, 'Accept': 'application/json'}
    if data is not None:
        h['Content-Type'] = 'application/json'
    r = urllib.request.Request(BASE + path, data=data, method=method, headers=h)
    t0 = time.perf_counter()
    try:
        with urllib.request.urlopen(r, timeout=30) as resp:
            code, txt = resp.status, resp.read()
    except urllib.error.HTTPError as e:
        code, txt = e.code, e.read()
    except Exception as exc:  # noqa: BLE001
        with LOCK:
            ERRS.append(repr(exc)[:120])
        return None, None
    dt = (time.perf_counter() - t0) * 1000
    with LOCK:
        LAT.append(dt)
        CODES[code] = CODES.get(code, 0) + 1
    try:
        return code, json.loads(txt)
    except ValueError:
        return code, None


def count_notes():
    c, js = req('GET', '/api/v34/status', VIEW)
    return js['tables']['lg34_knowledge'] if c == 200 and js else None


def worker(n, seed):
    rnd = random.Random(seed)
    for i in range(n):
        x = rnd.random()
        if x < 0.45:
            req('GET', '/api/v34/status', VIEW)
        elif x < 0.65:
            req('POST', '/api/knowledge/search', VIEW, {'query': rnd.choice(['kopi ekspor', 'logistik pelabuhan', 'strategi pasar', 'anggaran'])})
        elif x < 0.80:
            req('GET', '/api/knowledge', VIEW)
        elif x < 0.95:
            c, _ = req('POST', '/api/knowledge', OPER, {'title': f'Beban {seed}-{i}', 'category': 'Beban', 'content': 'catatan uji beban ' * 5})
            if c == 200:
                with LOCK:
                    WRITES_OK[0] += 1
        else:
            req('GET', '/api/v34/distributed/status', VIEW)


def main():
    if not (OPER and VIEW):
        print('NCK_OPERATOR_TOKEN dan NCK_VIEWER_TOKEN wajib diisi.')
        sys.exit(2)
    before = count_notes()
    per = TOTAL // THREADS
    t0 = time.perf_counter()
    ts = [threading.Thread(target=worker, args=(per, s)) for s in range(THREADS)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    el = time.perf_counter() - t0
    after = count_notes()
    lat = sorted(LAT)
    n = len(lat)
    p50, p95 = (statistics.median(lat), lat[int(n * 0.95) - 1]) if n else (0, 0)
    srv_err = sum(v for k, v in CODES.items() if k >= 500)
    unexpected = {k: v for k, v in CODES.items() if k != 200}
    print(f'permintaan={n} thread={THREADS} waktu={el:.1f}s throughput={n / el:.0f} req/dtk')
    print(f'latensi p50={p50:.0f}ms p95={p95:.0f}ms maks={max(lat) if lat else 0:.0f}ms; kode={dict(sorted(CODES.items()))}; galat-jaringan={len(ERRS)}')
    ok = True
    for name, cond, detail in [
        ('tanpa 5xx', srv_err == 0, srv_err),
        ('tanpa galat jaringan/timeout', not ERRS, ERRS[:3]),
        ('semua respons 200 (tidak ada 429/4xx tak terduga)', not unexpected, unexpected),
        (f'p95 <= {P95_MS:.0f} ms', p95 <= P95_MS, round(p95)),
        ('tidak ada penulisan hilang (jumlah catatan naik tepat sebesar POST sukses)', before is not None and after == before + WRITES_OK[0], (before, after, WRITES_OK[0])),
    ]:
        print(('PASS  ' if cond else 'FAIL  ') + name + ('' if cond else f'   :: {detail}'))
        ok = ok and cond
    print(f'\nRINGKAS: {"semua lulus" if ok else "ADA YANG GAGAL"}')
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
