#!/usr/bin/env bash
# Tahap 34 - uji HTTP nyata + beban ringan + backup/restore pg_dump pada PostgreSQL.
# Dijalankan dari CI (FastAPI + psycopg asli) dan dapat dicoba lokal. Env wajib:
#   NCK_PG_DSN          DSN database tempat skema uji dibuat (mis. postgresql://postgres:postgres@localhost:5432/postgres)
#   NCK_PG_ADMIN_DSN    DSN yang boleh CREATE/DROP DATABASE (biasanya sama dengan di atas)
#   NCK_PG_RESTORE_DSN  DSN database TUJUAN restore (database baru bernama nck_restore pada server yang sama)
#   NCK_ADMIN_TOKEN / NCK_OPERATOR_TOKEN / NCK_VIEWER_TOKEN
# Opsional: NCK_CI_SCHEMA (default nck_ci_http), NCK_PYTHON (default python), NCK_PORT (8000), NCK_PORT2 (8001)
set -euo pipefail
cd "$(dirname "$0")/.."
PY="${NCK_PYTHON:-python}"
SCHEMA="${NCK_CI_SCHEMA:-nck_ci_http}"
PORT="${NCK_PORT:-8000}"; PORT2="${NCK_PORT2:-8001}"
: "${NCK_PG_DSN:?}" "${NCK_PG_ADMIN_DSN:?}" "${NCK_PG_RESTORE_DSN:?}" "${NCK_ADMIN_TOKEN:?}" "${NCK_OPERATOR_TOKEN:?}" "${NCK_VIEWER_TOKEN:?}"
LOGDIR="${NCK_LOG_DIR:-/tmp/nck-ci-logs}"; mkdir -p "$LOGDIR"; LOGDIR="$(cd "$LOGDIR" && pwd)"
PIDS=()
cleanup() { for p in "${PIDS[@]:-}"; do kill "$p" 2>/dev/null || true; done; }
trap cleanup EXIT
fail() { echo "GAGAL: $*"; exit 1; }
wait_health() { for _ in $(seq 1 60); do curl -fsS "http://127.0.0.1:$1/health" >/dev/null 2>&1 && return 0; sleep 1; done; fail "server port $1 tidak siap (lihat $LOGDIR)"; }

# lingkungan server AI palsu + batas laju longgar (HANYA untuk uji)
export OPENAI_API_KEY=ci-fake-key OPENAI_BASE_URL=http://127.0.0.1:9911/v1 NCK_OLLAMA_URL=http://127.0.0.1:9911
export NCK_RATE_LIMIT=3000 NCK_EXPENSIVE_RATE_LIMIT=300 NCK_CORS_ORIGINS=http://localhost:5500
unset GEMINI_API_KEY
export NCK_DB_BACKEND=postgres NCK_POSTGRES_SCHEMA="$SCHEMA" NCK_DB_PATH="$LOGDIR/unused.db" NCK_BACKUP_DIR="$LOGDIR/backups"

echo "== 1. Bersihkan skema lama dan nyalakan API (PostgreSQL) =="
psql "$NCK_PG_DSN" -qAt -c "DROP SCHEMA IF EXISTS $SCHEMA CASCADE"
NCK_POSTGRES_DSN="$NCK_PG_DSN" "$PY" -m uvicorn main:app --host 127.0.0.1 --port "$PORT" > "$LOGDIR/uvicorn1.log" 2>&1 &
PIDS+=($!)
wait_health "$PORT"

echo "== 2. Uji HTTP nyata (hak akses, CORS, unggah, AI palsu, kolaborasi, persetujuan, backup/restore JSON, antrean worker) =="
NCK_HTTP_BASE="http://127.0.0.1:$PORT" "$PY" tests/http_checks_v34.py | tee "$LOGDIR/http_checks.txt"

echo "== 3. Uji beban ringan =="
NCK_HTTP_BASE="http://127.0.0.1:$PORT" "$PY" tests/load_check_v34.py | tee "$LOGDIR/load.txt"

echo "== 4. pg_dump skema -> pg_restore ke database baru =="
# Pilih pg_dump/pg_restore yang versi MAYOR-nya SAMA dengan server. Alasan: pg_dump >= 17 menulis
# "SET transaction_timeout" yang DITOLAK server PostgreSQL 16 saat restore (penyebab CI #2 merah,
# karena runner membawa klien PostgreSQL yang lebih baru). Urutan pilihan:
#   (1) biner berversi di $NCK_PG_BIN_ROOT/<mayor>/bin  (default /usr/lib/postgresql)
#   (2) pg_dump & pg_restore di PATH bila mayornya sama
#   (3) image docker postgres:<mayor> dengan --network host (tanpa apt)
# Paksa dengan NCK_PG_TOOLS=local atau NCK_PG_TOOLS=docker (default: auto).
SRV_MAJOR=$(( $(psql "$NCK_PG_DSN" -qAt -c "SHOW server_version_num") / 10000 ))
BIN_ROOT="${NCK_PG_BIN_ROOT:-/usr/lib/postgresql}"
major_of() { "$1" --version 2>/dev/null | sed -E 's/[^0-9]*([0-9]+).*/\1/'; }
PG_MODE=""; PG_BIN=""; PG_IMAGE=""
choose_pg_tools() {
  local want="${NCK_PG_TOOLS:-auto}" d="$BIN_ROOT/$SRV_MAJOR/bin"
  if [ "$want" != "docker" ]; then
    if [ -x "$d/pg_dump" ] && [ -x "$d/pg_restore" ]; then PG_MODE=local; PG_BIN="$d"; return 0; fi
    if command -v pg_dump >/dev/null 2>&1 && command -v pg_restore >/dev/null 2>&1 \
       && [ "$(major_of pg_dump)" = "$SRV_MAJOR" ] && [ "$(major_of pg_restore)" = "$SRV_MAJOR" ]; then
      PG_MODE=local; PG_BIN="$(dirname "$(command -v pg_dump)")"; return 0
    fi
  fi
  if [ "$want" != "local" ] && command -v docker >/dev/null 2>&1; then
    PG_MODE=docker; PG_IMAGE="postgres:$SRV_MAJOR"; return 0
  fi
  return 1
}
choose_pg_tools || fail "tidak ada pg_dump/pg_restore PostgreSQL $SRV_MAJOR yang cocok, dan docker tidak tersedia atau dimatikan (NCK_PG_TOOLS=${NCK_PG_TOOLS:-auto}; klien di PATH: $(command -v pg_dump >/dev/null 2>&1 && pg_dump --version || echo tidak ada))"
echo "  server PostgreSQL mayor=$SRV_MAJOR; alat dump/restore: mode=$PG_MODE ${PG_BIN}${PG_IMAGE}"
do_dump() {    # $1=dsn $2=skema $3=nama file di $LOGDIR
  if [ "$PG_MODE" = docker ]; then
    docker run --rm --network host -v "$LOGDIR:/out" --entrypoint pg_dump "$PG_IMAGE" "$1" -n "$2" -Fc -f "/out/$3"
  else
    "$PG_BIN/pg_dump" "$1" -n "$2" -Fc -f "$LOGDIR/$3"
  fi
}
do_restore() { # $1=dsn tujuan $2=nama file di $LOGDIR
  if [ "$PG_MODE" = docker ]; then
    docker run --rm --network host -v "$LOGDIR:/out" --entrypoint pg_restore "$PG_IMAGE" --no-owner -d "$1" "/out/$2"
  else
    "$PG_BIN/pg_restore" --no-owner -d "$1" "$LOGDIR/$2"
  fi
}
rm -f "$LOGDIR/nck.dump" 2>/dev/null || true
do_dump "$NCK_PG_DSN" "$SCHEMA" nck.dump
ls -l "$LOGDIR/nck.dump"
[ "$(stat -c %s "$LOGDIR/nck.dump")" -gt 1000 ] || fail "berkas dump terlalu kecil (pg_dump gagal?)"
psql "$NCK_PG_ADMIN_DSN" -qAt -c "DROP DATABASE IF EXISTS nck_restore" -c "CREATE DATABASE nck_restore"
do_restore "$NCK_PG_RESTORE_DSN" nck.dump
echo "  restore selesai tanpa galat"

echo "== 5. Jumlah baris SETIAP tabel harus sama persis =="
TABLES=$(psql "$NCK_PG_DSN" -qAt -c "SELECT table_name FROM information_schema.tables WHERE table_schema='$SCHEMA' AND table_type='BASE TABLE' ORDER BY 1")
N=0; BAD=0
for t in $TABLES; do
  a=$(psql "$NCK_PG_DSN" -qAt -c "SELECT count(*) FROM $SCHEMA.\"$t\"")
  b=$(psql "$NCK_PG_RESTORE_DSN" -qAt -c "SELECT count(*) FROM $SCHEMA.\"$t\"")
  N=$((N+1))
  if [ "$a" != "$b" ]; then echo "  BEDA: $t asli=$a restore=$b"; BAD=$((BAD+1)); fi
done
echo "  tabel diperiksa: $N, berbeda: $BAD"
[ "$N" -ge 30 ] || fail "terlalu sedikit tabel ($N); skema tidak terbentuk benar"
[ "$BAD" -eq 0 ] || fail "jumlah baris tidak sama setelah restore"

echo "== 6. Nyalakan API kedua di atas database hasil restore dan periksa =="
NCK_POSTGRES_DSN="$NCK_PG_RESTORE_DSN" "$PY" -m uvicorn main:app --host 127.0.0.1 --port "$PORT2" > "$LOGDIR/uvicorn2.log" 2>&1 &
PIDS+=($!)
wait_health "$PORT2"
NCK_HTTP_BASE="http://127.0.0.1:$PORT2" "$PY" - <<'PYEOF'
import json, os, urllib.request
base = os.environ['NCK_HTTP_BASE']
def call(m, p, tok, body=None):
    h = {'X-NCK-Token': tok, 'Accept': 'application/json'}
    d = None
    if body is not None:
        d = json.dumps(body).encode(); h['Content-Type'] = 'application/json'
    return json.loads(urllib.request.urlopen(urllib.request.Request(base + p, data=d, method=m, headers=h), timeout=30).read())
adm, op, vw = os.environ['NCK_ADMIN_TOKEN'], os.environ['NCK_OPERATOR_TOKEN'], os.environ['NCK_VIEWER_TOKEN']
st = call('GET', '/api/v34/status', vw)
assert st['tables']['lg34_projects'] >= 1 and st['tables']['lg34_knowledge'] >= 1, st['tables']
new = call('POST', '/api/knowledge', op, {'title': 'Setelah restore', 'category': 'Uji', 'content': 'penulisan setelah restore harus berhasil'})
assert new['id'], new
ad = call('GET', '/api/v33/database/adapter', adm)
assert ad['backend'] == 'postgres' and ad['identity_sequences_ok'] is True, ad
q = call('POST', '/api/knowledge/search', vw, {'query': 'penulisan setelah restore'})
assert any(i['id'] == new['id'] for i in q['items']), q
print('OK: data hasil restore terbaca, penulisan baru berhasil, sequence sehat, pencarian bekerja')
PYEOF

echo "== SELESAI: semua tahap lulus =="
psql "$NCK_PG_ADMIN_DSN" -qAt -c "DROP DATABASE IF EXISTS nck_restore" >/dev/null 2>&1 || true
