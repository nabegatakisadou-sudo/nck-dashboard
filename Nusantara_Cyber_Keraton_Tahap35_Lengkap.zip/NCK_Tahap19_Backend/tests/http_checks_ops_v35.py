"""Uji HTTP NYATA Tahap 35 terhadap server uvicorn yang sedang berjalan.
Fase:  api            server produksi baru start: /ready, hak akses, header, CORS, readiness, metrik, laporan backup
       after_report   setelah backup+drill dilaporkan: readiness harus menampilkan backup dan drill 'pass'
       rotation OLD NEW   server dengan NCK_VIEWER_TOKEN=NEW dan NCK_VIEWER_TOKEN_PREVIOUS=OLD
       rotation_done OLD NEW  server tanpa token lama: OLD harus ditolak
Env: NCK_HTTP_BASE, NCK_ADMIN_TOKEN, NCK_OPERATOR_TOKEN, NCK_VIEWER_TOKEN, NCK_FRONT_ORIGIN
"""
import json
import os
import sys
import urllib.error
import urllib.request

BASE = os.environ['NCK_HTTP_BASE']
ADM, OPR, VWR = os.environ.get('NCK_ADMIN_TOKEN', ''), os.environ.get('NCK_OPERATOR_TOKEN', ''), os.environ.get('NCK_VIEWER_TOKEN', '')
FRONT = os.environ.get('NCK_FRONT_ORIGIN', 'https://front.example')
RES = []


def call(method, path, tok=None, body=None, headers=None):
    h = {'Accept': 'application/json'}
    if tok:
        h['X-NCK-Token'] = tok
    d = None
    if body is not None:
        d = json.dumps(body).encode()
        h['Content-Type'] = 'application/json'
    h.update(headers or {})
    req = urllib.request.Request(BASE + path, data=d, method=method, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            raw, code, hd = r.read(), r.status, dict(r.headers)
    except urllib.error.HTTPError as e:
        raw, code, hd = e.read(), e.code, dict(e.headers)
    try:
        js = json.loads(raw) if raw else None
    except ValueError:
        js = None
    return code, js, {k.lower(): v for k, v in hd.items()}, raw


def ck(name, cond, extra=''):
    RES.append(bool(cond))
    print(('PASS  ' if cond else 'FAIL  ') + name + ('' if cond else f'   <- {extra}'))


def phase_api():
    c, js, hd, _ = call('GET', '/ready')
    ck('O1 /ready publik 200, ready=true', c == 200 and js and js['ready'] is True, f'{c} {js}')
    ck('O2 /ready tidak memuat rahasia', not any(t and t in json.dumps(js) for t in (ADM, OPR, VWR)))
    c, _, hd, _ = call('GET', '/health')
    ck('O3 header keamanan + HSTS (NCK_FORCE_HTTPS=1) + X-Request-ID', hd.get('x-content-type-options') == 'nosniff' and 'max-age' in hd.get('strict-transport-security', '') and hd.get('x-request-id'), str(hd))
    ck('O4 tanpa token -> 401', call('GET', '/api/v35/ops/status')[0] == 401)
    ck('O5 token salah -> 403', call('GET', '/api/v35/ops/status', 'salah-' + 'x' * 40)[0] == 403)
    c, js, _, _ = call('GET', '/api/v35/ops/status', VWR)
    ck('O6 ops/status viewer: versi 35, database postgres, uptime', c == 200 and js['version'] == '35.0.0' and js['database'] == 'postgres' and js['uptime_seconds'] >= 0, f'{c} {js}')
    ck('O7 ops/status: environment=production', js and js['environment'] == 'production')
    c, js, _, raw = call('GET', '/api/v35/ops/readiness', VWR)
    ids = {x['id']: x for x in (js or {}).get('checks', [])}
    ck('O8 readiness 200 dan bentuk lengkap', c == 200 and ids and js['limits'] and js['summary'])
    ck('O9 readiness (produksi sungguhan): tokens/cors/database/db_ping/env = pass',
       all(ids[k]['status'] == 'pass' for k in ('tokens_strong', 'tokens_distinct', 'cors_exact', 'database_durable', 'db_ping', 'env_production', 'hsts')), str({k: v['status'] for k, v in ids.items()}))
    ck('O10 readiness: HTTP biasa -> https_request warn; belum ada backup/drill -> warn', ids['https_request']['status'] == 'warn' and ids['backup_recent']['status'] == 'warn' and ids['restore_drill']['status'] == 'warn')
    ck('O11 readiness: tidak ada FAIL dan putusan siap_dengan_catatan', js['summary']['fail'] == 0 and js['summary']['verdict'] == 'siap_dengan_catatan', str(js['summary']))
    ck('O12 readiness TIDAK memuat token/DSN', not any(t and t in raw.decode() for t in (ADM, OPR, VWR, 'postgresql://')))
    c, m1, _, _ = call('GET', '/api/v35/ops/metrics', VWR)
    for _ in range(5):
        call('GET', '/health')
    call('GET', '/api/v35/ops/status')  # 401
    c2, m2, _, _ = call('GET', '/api/v35/ops/metrics', VWR)
    ck('O13 metrik: jumlah permintaan naik >= 7 dan 4xx tercatat', c2 == 200 and m2['requests_total'] - m1['requests_total'] >= 7 and m2['by_class'].get('4xx', 0) >= 3, f'{m1["requests_total"]}->{m2["requests_total"]} {m2["by_class"]}')
    ck('O14 metrik: p95 terisi, tanpa 5xx, db ok, antrean ada', m2['latency_ms']['p95'] is not None and m2['by_class'].get('5xx', 0) == 0 and m2['db']['ok'] and set(m2['task_runs']) == {'queued', 'running', 'completed', 'failed'}, str(m2))
    # CORS
    c, _, hd, _ = call('OPTIONS', '/api/v35/ops/status', headers={'Origin': 'https://evil.example', 'Access-Control-Request-Method': 'GET', 'Access-Control-Request-Headers': 'x-nck-token'})
    ck('O15 CORS: origin asing tidak diizinkan', 'access-control-allow-origin' not in hd)
    c, _, hd, _ = call('OPTIONS', '/api/v35/ops/status', headers={'Origin': FRONT, 'Access-Control-Request-Method': 'GET', 'Access-Control-Request-Headers': 'x-nck-token'})
    ck('O16 CORS: origin frontend diizinkan', hd.get('access-control-allow-origin') == FRONT, str(hd))
    # laporan backup: RBAC + validasi
    body = {'kind': 'backup', 'ok': True, 'bytes': 100, 'sha256': 'a' * 64, 'detail': 'uji http'}
    ck('O17 backup-report: tanpa token 401, viewer/operator 403', call('POST', '/api/v35/ops/backup-report', None, body)[0] == 401 and call('POST', '/api/v35/ops/backup-report', VWR, body)[0] == 403 and call('POST', '/api/v35/ops/backup-report', OPR, body)[0] == 403)
    ck('O18 backup-report: kind/sha256/bytes tidak valid -> 422', all(call('POST', '/api/v35/ops/backup-report', ADM, b)[0] == 422 for b in ({'kind': 'x', 'ok': True}, {'kind': 'backup', 'ok': True, 'sha256': 'zz'}, {'kind': 'backup', 'ok': True, 'bytes': -5}, {'ok': True})))
    ck('O19 GET backups: viewer 403, operator 200', call('GET', '/api/v35/ops/backups', VWR)[0] == 403 and call('GET', '/api/v35/ops/backups', OPR)[0] == 200)
    ck('O20 /api/v35/status tidak mengklaim production_ready', call('GET', '/api/v35/status', VWR)[1]['production_ready'] is False)


def phase_seed():
    """Isi data nyata lewat API agar backup berisi sesuatu."""
    for i in range(3):
        c, js, _, _ = call('POST', '/api/knowledge', OPR, {'title': f'Catatan backup {i}', 'category': 'Uji', 'content': f'isi uji backup nomor {i}'})
        ck(f'S{i} seed catatan knowledge', c == 200, f'{c} {js}')
    c, js, _, _ = call('POST', '/api/v13/projects', OPR, {'name': 'Proyek uji backup', 'description': 'seed'})
    ck('S3 seed proyek (200/409 boleh)', c in (200, 409), f'{c} {js}')


def phase_after_report():
    c, js, _, _ = call('GET', '/api/v35/ops/readiness', VWR)
    ids = {x['id']: x for x in js['checks']}
    ck('R1 readiness: backup_recent pass setelah laporan', ids['backup_recent']['status'] == 'pass', str(ids['backup_recent']))
    ck('R2 readiness: restore_drill pass setelah laporan', ids['restore_drill']['status'] == 'pass', str(ids['restore_drill']))
    ck('R3 putusan tetap siap_dengan_catatan (HTTP lokal) dan tanpa FAIL', js['summary']['fail'] == 0 and js['summary']['verdict'] == 'siap_dengan_catatan', str(js['summary']))
    c, lst, _, _ = call('GET', '/api/v35/ops/backups', OPR)
    kinds = [(x['kind'], x['ok']) for x in lst['items']]
    ck('R4 riwayat memuat backup dan restore_drill sukses', ('backup', 1) in kinds and ('restore_drill', 1) in kinds, str(kinds))


def phase_rotation(old, new):
    c, js, _, _ = call('GET', '/api/v35/ops/status', old)
    ck('T1 token LAMA masih diterima selama rotasi', c == 200, c)
    c, js, _, _ = call('GET', '/api/v35/ops/status', new)
    ck('T2 token BARU diterima', c == 200, c)
    c, _, _, _ = call('POST', '/api/knowledge', old, {'title': 'x', 'category': 'x', 'content': 'x'})
    ck('T3 token lama TIDAK naik peran (tulis ditolak 403)', c == 403, c)
    c, js, _, raw = call('GET', '/api/v35/ops/readiness', new)
    rot = next(x for x in js['checks'] if x['id'] == 'tokens_rotation')
    ck('T4 readiness: rotasi aktif (warn) dengan catatan pemakaian, tanpa membocorkan token', rot['status'] == 'warn' and 'menit lalu' in rot['detail'] and old not in raw.decode(), str(rot))


def phase_rotation_done(old, new):
    ck('U1 setelah PREVIOUS dihapus, token lama ditolak 403', call('GET', '/api/v35/ops/status', old)[0] == 403)
    ck('U2 token baru tetap berlaku', call('GET', '/api/v35/ops/status', new)[0] == 200)
    c, js, _, _ = call('GET', '/api/v35/ops/readiness', new)
    ck('U3 readiness: rotasi selesai (pass)', next(x for x in js['checks'] if x['id'] == 'tokens_rotation')['status'] == 'pass')


if __name__ == '__main__':
    ph = sys.argv[1]
    {'api': phase_api, 'seed': phase_seed, 'after_report': phase_after_report,
     'rotation': lambda: phase_rotation(sys.argv[2], sys.argv[3]),
     'rotation_done': lambda: phase_rotation_done(sys.argv[2], sys.argv[3])}[ph]()
    bad = RES.count(False)
    print(f'\nRINGKAS [{ph}]: {len(RES) - bad}/{len(RES)} lulus')
    sys.exit(1 if bad else 0)
