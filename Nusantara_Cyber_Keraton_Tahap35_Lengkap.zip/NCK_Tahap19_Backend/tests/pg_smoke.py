"""Uji asap migrasi + adapter PostgreSQL NCK Tahap 33.

Butuh server PostgreSQL. DSN dari env NCK_TEST_PG_DSN, contoh:
    postgresql://postgres:postgres@localhost:5432/postgres
Jalankan dari folder NCK_Tahap19_Backend:   python tests/pg_smoke.py
Menyentuh hanya schema bernama nck_ci_* (dibuat lalu dihapus). Jangan arahkan ke database produksi.
Exit code 0 = semua lulus.
"""
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
BACK = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import _bootstrap  # noqa: E402

DSN = os.environ.get('NCK_TEST_PG_DSN', 'postgresql://postgres@/nck_test')


# ====================================================================== mode anak
def child_seed(out):
    """Bangun DB SQLite dari kode aplikasi lalu isi data sintetis (termasuk karakter khusus)."""
    import random
    os.environ.update({'NCK_DB_BACKEND': 'sqlite', 'NCK_DB_PATH': out, 'NCK_BACKUP_DIR': out + '.bk', 'NCK_WORKER_CONCURRENCY': '1'})
    _bootstrap.install()
    import main as M
    for h in _bootstrap.startup_handlers(M):
        h()
    c = sqlite3.connect(out)
    c.row_factory = sqlite3.Row
    random.seed(7)
    names = [r[0] for r in c.execute("select name from sqlite_master where type='table' and name not like 'sqlite_%'")]
    info = {n: [dict(r) for r in c.execute(f'pragma table_info("{n}")')] for n in names}
    fks = {n: [dict(r) for r in c.execute(f'pragma foreign_key_list("{n}")')] for n in names}
    uniq = {n: set() for n in names}
    for n in names:
        for ix in c.execute(f'pragma index_list("{n}")').fetchall():
            if ix['unique'] and ix['origin'] != 'pk':
                cols = [r['name'] for r in c.execute(f'pragma index_info("{ix["name"]}")')]
                if len(cols) == 1:
                    uniq[n].add(cols[0])
    order, done = [], set()
    while len(order) < len(names):
        for n in names:
            if n not in done and all(f['table'] in done or f['table'] == n for f in fks[n]):
                order.append(n)
                done.add(n)
    special = ["O'Brien \"kutip\"", '100% yakin', 'baris\nbaru\tTab', 'Nusantara ☆ keraton — éñ', '{"k": [1,2,3]}', 'a;b;--c', '%s ? :x']
    total = 0
    for n in order:
        if c.execute(f'select count(*) from "{n}"').fetchone()[0]:
            continue
        for i in range(1, 13):
            vals, cols_ = [], []
            for col in info[n]:
                nm, typ = col['name'], (col['type'] or '').upper()
                fk = next((f for f in fks[n] if f['from'] == nm), None)
                if col['pk'] and 'INT' in typ and not fk:
                    continue
                if fk:
                    pr = c.execute(f'select "{fk["to"] or "id"}" from "{fk["table"]}" order by random() limit 1').fetchone()
                    v = pr[0] if pr else None
                elif col['pk'] or nm in uniq[n]:
                    v = f'{n[:8]}-{i:04d}-{nm}' if 'INT' not in typ else i + 100
                elif 'INT' in typ:
                    v = random.randint(0, 50)
                elif 'REAL' in typ:
                    v = round(random.random() * 100, 3)
                else:
                    v = special[(i + len(nm)) % len(special)] if random.random() < .5 else f'{nm}-{i}'
                if nm.endswith('_at'):
                    v = f'2026-11-{10 + i % 9:02d}T0{i % 9}:00:00+00:00'
                if not col['notnull'] and not col['pk'] and random.random() < .12 and not fk and nm not in uniq[n]:
                    v = None
                vals.append(v)
                cols_.append(nm)
            try:
                c.execute(f'insert into "{n}"({",".join(chr(34) + x + chr(34) for x in cols_)}) values({",".join("?" * len(vals))})', vals)
            except sqlite3.IntegrityError:
                pass
        total += c.execute(f'select count(*) from "{n}"').fetchone()[0]
    c.commit()
    print('RESULT:' + json.dumps({'tables': len(names), 'rows': total,
                                  'fk_issues': len(c.execute('pragma foreign_key_check').fetchall())}))
    sys.stdout.flush()
    os._exit(0)


def child_app(schema, label):
    """Jalankan aplikasi pada PostgreSQL (schema kosong = 'fresh', hasil migrasi = 'migrated') dan kumpulkan cek."""
    work = tempfile.mkdtemp()
    for k in ('OPENAI_API_KEY', 'GEMINI_API_KEY'):
        os.environ.pop(k, None)
    os.environ.update({'NCK_DB_BACKEND': 'postgres', 'NCK_POSTGRES_DSN': DSN, 'NCK_POSTGRES_SCHEMA': schema,
                       'NCK_DB_PATH': work + '/unused.db', 'NCK_BACKUP_DIR': work + '/b', 'NCK_WORKER_CONCURRENCY': '3'})
    _bootstrap.install()
    import main as M
    ep = lambda m, p: _bootstrap.endpoint(M, m, p)  # noqa: E731

    class BG:
        def add_task(self, *a, **k):
            pass
    out = {}
    errs = []
    for h in _bootstrap.startup_handlers(M):
        try:
            h()
        except Exception as e:  # noqa: BLE001
            errs.append(f'{h.__name__}: {e!r}'[:200])
    out['startup_tanpa_error'] = not errs
    if errs:
        out['startup_errors'] = errs

    def maxid(t):
        with M.conn() as c:
            return c.execute(f'SELECT COALESCE(MAX(id),0) FROM {t}').fetchone()[0]
    watch = ('projects', 'memories', 'tasks', 'projects_v22', 'tasks_v22')
    before = {t: maxid(t) for t in watch}
    r1 = ep('POST', '/api/v19/memories')(data=M.MemoryIn(project='Alpha', content="O'Brien 100% ☆ \"ganda\""), role='admin')
    ep('POST', '/api/v19/tasks')(data=M.TaskIn(title='Tugas satu', instruction='Kerjakan tugas nomor satu'), role='admin')
    ep('POST', '/api/v22/projects')(data=M.Project22In(name='Alpha', description='Proyek'), role='admin')
    try:
        ep('POST', '/api/v22/projects')(data=M.Project22In(name='Alpha', description='dup'), role='admin')
        out['proyek_duplikat_ditolak_409'] = False
    except M.HTTPException as e:
        out['proyek_duplikat_ditolak_409'] = e.status_code == 409
    ep('POST', '/api/v22/knowledge')(data=M.Knowledge22In(project='Alpha', title='Panduan Keraton', content='Kepala Kerajaan memimpin', tags='adat'), role='admin')
    ep('POST', '/api/v22/knowledge')(data=M.Knowledge22In(project='Alpha', title='Lain', content='kepala lain 100%', tags=''), role='admin')
    kn = ep('GET', '/api/v22/knowledge')(q='KEPALA', role='admin')
    out['pencarian_tidak_peka_huruf'] = len(kn['items']) >= 2
    out['pencarian_persen_literal'] = len(ep('GET', '/api/v22/knowledge')(q='100%', role='admin')['items']) >= 1
    new_ids = {t: maxid(t) for t in watch}
    out['id_baru_naik_tanpa_bentrok'] = all(new_ids[t] > before[t] for t in ('projects', 'memories', 'tasks', 'projects_v22'))
    out['lastrowid_memori_terisi'] = bool(r1) and (r1.get('id', 1) or 1) > 0
    # antrean: pause -> banyak tugas -> resume; 3 worker berebut; tiap tugas harus diklaim tepat satu kali
    ep('POST', '/api/v27/workers/control')(data=M.WorkerControl27In(paused=True, reason='uji'), role='admin')
    for i in range(1, 13):
        ep('POST', '/api/v22/tasks')(data=M.Task22In(project='Alpha', title=f'Tugas {i}', instruction=f'Instruksi {i}', agent_id='ki_mandra', priority='normal'), role='admin')
    for _ in range(2):
        ep('POST', '/api/v23/queue/dispatch')(data=M.Dispatch23In(max_retries=0, review_enabled=False, limit=10), background_tasks=BG(), role='operator')
    ep('POST', '/api/v27/workers/control')(data=M.WorkerControl27In(paused=False), role='admin')
    t0 = time.time()
    while time.time() - t0 < 120:
        with M.conn() as c:
            n = c.execute("SELECT COUNT(*) FROM task_runs_v23 WHERE status IN ('queued','running')").fetchone()[0]
        if n == 0 and time.time() - t0 > 3:
            break
        time.sleep(1)
    time.sleep(2)
    with M.conn() as c:
        claims = {r['task_id']: r['n'] for r in c.execute("SELECT task_id, COUNT(*) AS n FROM queue_events_v27 WHERE event='worker.claimed' GROUP BY task_id").fetchall()}
        # hanya lease milik tugas yang diklaim pada uji ini (data seed sintetis boleh punya lease lama)
        leases = sum(c.execute('SELECT COUNT(*) FROM worker_leases_v27 WHERE task_id=?', (tid,)).fetchone()[0] for tid in claims)
        notdone = c.execute("SELECT COUNT(*) FROM task_runs_v23 WHERE status IN ('queued','running')").fetchone()[0]
        # julianday
        done_ids = [r['task_id'] for r in c.execute('SELECT task_id FROM task_runs_v23 ORDER BY task_id LIMIT 2').fetchall()]
        for k, tid in enumerate(done_ids):
            c.execute("UPDATE task_runs_v23 SET status='completed', started_at=?, finished_at=? WHERE task_id=?",
                      (f'2026-11-19T0{k + 1}:00:00+00:00', f'2026-11-19T0{k + 1}:00:{42 + 18 * k}+00:00', tid))
    out['tugas_diklaim'] = len(claims)
    out['tiap_tugas_diklaim_tepat_sekali'] = len(claims) >= 10 and all(v == 1 for v in claims.values())
    out['lease_bersih'] = leases == 0
    out['tidak_ada_run_menggantung'] = notdone == 0
    prod = ep('GET', '/api/v26/productivity')(role='admin')
    out['julianday_berjalan'] = isinstance(prod, dict)
    ad = ep('GET', '/api/v33/database/adapter')(role='operator')
    out['sequence_identity_sehat'] = bool(ad['identity_sequences_ok']) and len(ad['identity_sequences']) > 0
    out['backend_postgres_aktif'] = ad['backend'] == 'postgres'
    print('RESULT:' + json.dumps(out))
    sys.stdout.flush()
    os._exit(0)


# ====================================================================== orkestrator
RESULTS = []


def check(name, cond, detail=''):
    RESULTS.append((name, bool(cond), detail))
    print(('PASS  ' if cond else 'FAIL  ') + name + ('' if cond else '   :: ' + str(detail)[:300]), flush=True)


def child_env(extra=None):
    env = dict(os.environ)
    pp = _bootstrap.pythonpath_for_children()
    if pp:
        env['PYTHONPATH'] = pp + os.pathsep + env.get('PYTHONPATH', '')
    env['NCK_TEST_PG_DSN'] = DSN
    env.update(extra or {})
    return env


def run(cmd, extra_env=None, timeout=420):
    p = subprocess.run(cmd, capture_output=True, text=True, env=child_env(extra_env), timeout=timeout)
    return p.returncode, p.stdout, p.stderr


def last_json(stdout, prefix='RESULT:'):
    for line in reversed(stdout.splitlines()):
        if line.startswith(prefix):
            return json.loads(line[len(prefix):])
    return None


def mig(args):
    code, so, se = run([sys.executable, os.path.join(BACK, 'tools', 'migrate_sqlite_to_postgres_v33.py')] + args)
    rep = None
    if '{' in so:
        try:
            rep = json.loads(so[so.index('{'):])
        except ValueError:
            rep = None
    return code, rep, se


def pg(sql, params=None, fetch=False):
    import psycopg
    with psycopg.connect(DSN) as c:
        cur = c.cursor()
        cur.execute(sql, params)
        return cur.fetchall() if fetch else None


def drop(schema):
    pg(f'DROP SCHEMA IF EXISTS {schema} CASCADE')


def main():
    using = _bootstrap.install()
    print('Pustaka uji:', using, '\nDSN:', DSN.split('@')[-1], '\n')
    tmp = tempfile.mkdtemp()
    seed = os.path.join(tmp, 'seed.db')
    S_MIG, S_FRESH, S_BAD, S_MIG2 = 'nck_ci_mig', 'nck_ci_fresh', 'nck_ci_bad', 'nck_ci_mig2'
    for s in (S_MIG, S_FRESH, S_BAD, S_MIG2):
        drop(s)
    try:
        code, so, se = run([sys.executable, __file__, '--child', 'seed', seed])
        r = last_json(so)
        check('seed: skema aplikasi + data uji terbentuk', code == 0 and r and r['tables'] >= 28 and r['rows'] > 100 and r['fk_issues'] == 0, (code, se[-300:], r))

        code, rep, se = mig(['--sqlite', seed, '--dry-run'])
        pos = {t['table']: i for i, t in enumerate(rep['tables'])} if rep else {}
        sq = sqlite3.connect(seed)
        edges = [(t, fk[2]) for (t,) in sq.execute("select name from sqlite_master where type='table' and name not like 'sqlite_%'").fetchall()
                 for fk in sq.execute(f'pragma foreign_key_list("{t}")').fetchall() if fk[2] != t]
        check('dry-run OK tanpa psycopg & tanpa konflik tipe', code == 0 and rep and rep['status'] == 'DRY_RUN_OK' and not rep['type_conflicts'], (code, se[-200:]))
        check('urutan muat: induk sebelum anak (semua relasi FK)', edges and all(pos[p] < pos[c] for c, p in edges), edges[:3])

        code, rep, se = mig(['--sqlite', seed, '--postgres', DSN, '--schema', S_MIG, '--snapshot', '--snapshot-path', seed + '.snap'])
        check('migrasi: VERIFIED (jumlah baris + checksum isi semua tabel)', code == 0 and rep and rep['status'] == 'VERIFIED' and all(t['verified'] and t.get('checksum_ok') for t in rep['tables']), (code, se[-300:]))
        check('migrasi dari snapshot (bukan file hidup)', rep and rep['source'].endswith('.snap'), rep and rep['source'])

        before = pg(f'SELECT count(*) FROM {S_MIG}.projects', fetch=True)[0][0]
        code, rep2, se = mig(['--sqlite', seed, '--postgres', DSN, '--schema', S_MIG])
        after = pg(f'SELECT count(*) FROM {S_MIG}.projects', fetch=True)[0][0]
        check('jalankan ulang tanpa --replace-target-data DITOLAK + rollback', code == 4 and before == after, (code, se[-200:]))

        code, rep3, se = mig(['--sqlite', seed, '--postgres', DSN, '--schema', S_MIG, '--replace-target-data'])
        check('--replace-target-data berhasil dan terverifikasi', code == 0 and rep3 and rep3['status'] == 'VERIFIED', (code, se[-200:]))

        led1 = pg(f'SELECT count(*) FROM {S_MIG}._nck_migration_runs_v33', fetch=True)[0][0]
        code, rep4, se = mig(['--sqlite', seed, '--postgres', DSN, '--schema', S_MIG, '--verify-only'])
        led2 = pg(f'SELECT count(*) FROM {S_MIG}._nck_migration_runs_v33', fetch=True)[0][0]
        check('--verify-only VERIFIED dan tidak menulis (ledger tetap)', code == 0 and rep4['status'] == 'VERIFIED' and led1 == led2, (code, led1, led2))

        pg(f"UPDATE {S_MIG}.audit SET detail='DIUBAH' WHERE id=(SELECT min(id) FROM {S_MIG}.audit)")
        code, rep5, se = mig(['--sqlite', seed, '--postgres', DSN, '--schema', S_MIG, '--verify-only'])
        check('checksum mendeteksi perubahan 1 sel (jumlah baris sama)', code == 2 and rep5 and rep5['status'] == 'MISMATCH', (code, se[-200:]))
        mig(['--sqlite', seed, '--postgres', DSN, '--schema', S_MIG, '--replace-target-data'])

        bad = seed + '.badtype'
        shutil.copy(seed, bad)
        b = sqlite3.connect(bad)
        b.execute("update ai_usage_v21 set prompt_chars='bukan-angka' where rowid=1")
        b.commit()
        b.close()
        code, rep6, se = mig(['--sqlite', bad, '--postgres', DSN, '--schema', S_BAD])
        exists = pg('SELECT count(*) FROM information_schema.schemata WHERE schema_name=%s', (S_BAD,), fetch=True)[0][0]
        check('gerbang konflik tipe: diblokir sebelum menyentuh PostgreSQL', code == 3 and rep6 and rep6['status'] == 'BLOCKED_TYPE_CONFLICTS' and exists == 0, (code, exists))

        # constraint nyata di hasil migrasi
        def fails(sql):
            try:
                pg(sql)
                return False
            except Exception:  # noqa: BLE001
                return True
        check('UNIQUE ditegakkan di PostgreSQL', fails(f"INSERT INTO {S_MIG}.projects(name,created_at) SELECT name,created_at FROM {S_MIG}.projects LIMIT 1"))
        check('FK ditegakkan di PostgreSQL', fails(f"INSERT INTO {S_MIG}.memories(project_id,content,created_at) VALUES (987654321,'x','y')"))
        check('CHECK ditegakkan (singleton worker_control)', fails(f"INSERT INTO {S_MIG}.worker_control_v27(id,paused,reason,updated_at,updated_by) VALUES (2,0,'','x','x')"))
        # regresi: migrasi ke schema KEDUA di database yang sama tidak boleh melewatkan CHECK (bug nama constraint global)
        code, rep7, se = mig(['--sqlite', seed, '--postgres', DSN, '--schema', S_MIG2])
        has_chk = pg("SELECT count(*) FROM pg_constraint c JOIN pg_namespace s ON s.oid=c.connamespace "
                     "WHERE s.nspname=%s AND c.contype='c' AND c.conrelid::regclass::text LIKE %s", (S_MIG2, '%worker_control_v27'), fetch=True)[0][0]
        check('migrasi ke schema kedua di DB yang sama tetap membawa CHECK', code == 0 and has_chk >= 1, (code, has_chk, se[-200:]))
        nid = pg(f"INSERT INTO {S_MIG}.projects(name,created_at) VALUES ('proyek-id-otomatis','x') RETURNING id", fetch=True)
        check('id otomatis (identity) bekerja setelah migrasi', nid and nid[0][0] > 0, nid)
        pg(f"DELETE FROM {S_MIG}.projects WHERE name='proyek-id-otomatis'")

        # aplikasi pada schema kosong (DDL dari kode aplikasi) dan pada hasil migrasi (cutover)
        for label, schema in (('fresh', S_FRESH), ('migrated', S_MIG)):
            code, so, se = run([sys.executable, __file__, '--child', 'app', schema, label])
            res = last_json(so) or {}
            for k, v in res.items():
                if isinstance(v, bool):
                    check(f'aplikasi [{label}] {k}', v, res.get('startup_errors'))
            if not res:
                check(f'aplikasi [{label}] berjalan', False, (code, se[-400:], so[-400:]))

        # paritas skema: DDL aplikasi vs hasil migrasi
        def shape(schema):
            q1 = ("SELECT table_name, column_name, data_type, is_nullable, is_identity FROM information_schema.columns "
                  "WHERE table_schema=%s AND table_name NOT LIKE %s AND table_name NOT LIKE %s ORDER BY 1,2")
            cols = pg(q1, (schema, r'\_nck%', r'nck\_cluster%'), fetch=True)
            q2 = ("SELECT conrelid::regclass::text, contype, regexp_replace(pg_get_constraintdef(oid), %s, '', 'g') FROM pg_constraint "
                  "WHERE connamespace=%s::regnamespace ORDER BY 1,2,3")
            cons = [tuple(r) for r in pg(q2, ('"?' + schema + '"?\\.', schema), fetch=True)
                    if '_nck' not in r[0] and 'nck_cluster' not in r[0]]
            cons = [(a.replace(schema + '.', ''), b, c) for a, b, c in cons]
            return [tuple(r) for r in cols], sorted(cons)
        a, b = shape(S_FRESH), shape(S_MIG)
        check('paritas skema: kolom/tipe/identity identik (aplikasi vs migrasi)', a[0] == b[0], [x for x in a[0] if x not in b[0]][:3])
        check('paritas skema: PK/UNIQUE/FK/CHECK identik (aplikasi vs migrasi)', a[1] == b[1], [x for x in a[1] if x not in b[1]][:3])
    finally:
        for s in (S_MIG, S_FRESH, S_BAD, S_MIG2):
            try:
                drop(s)
            except Exception:  # noqa: BLE001
                pass
        shutil.rmtree(tmp, ignore_errors=True)
    failed = [n for n, ok, _ in RESULTS if not ok]
    print(f'\nRINGKAS: {len(RESULTS) - len(failed)}/{len(RESULTS)} lulus', '' if not failed else f'| GAGAL: {failed}')
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--child':
        if sys.argv[2] == 'seed':
            child_seed(sys.argv[3])
        elif sys.argv[2] == 'app':
            child_app(sys.argv[3], sys.argv[4])
    else:
        main()
