#!/usr/bin/env bash
# Tahap 35 - uji integrasi OPERASI PRODUKSI pada PostgreSQL nyata (CI: FastAPI + psycopg + docker asli).
# Env wajib: NCK_PG_ADMIN_DSN (boleh CREATE/DROP DATABASE), NCK_ADMIN_TOKEN, NCK_OPERATOR_TOKEN, NCK_VIEWER_TOKEN (>=32 karakter, berbeda)
# Opsional : NCK_PYTHON (python), NCK_OPS_PORT (8010), NCK_LOG_DIR, NCK_OPS_DRILL_MODE=docker|dsn (default dsn)
#            docker = latihan restore utama menyalakan postgres:<mayor> sementara lewat docker (jalur yang dipakai workflow ops)
set -euo pipefail
cd "$(dirname "$0")/.."
PY="${NCK_PYTHON:-python}"
PORT="${NCK_OPS_PORT:-8010}"; PORT2=$((PORT + 1)); PORT3=$((PORT + 2)); PORT4=$((PORT + 3))
: "${NCK_PG_ADMIN_DSN:?}" "${NCK_ADMIN_TOKEN:?}" "${NCK_OPERATOR_TOKEN:?}" "${NCK_VIEWER_TOKEN:?}"
LOGDIR="${NCK_LOG_DIR:-/tmp/nck-ops-logs}"; rm -rf "$LOGDIR"; mkdir -p "$LOGDIR"; LOGDIR="$(cd "$LOGDIR" && pwd)"
PIDS=()
cleanup() { for p in "${PIDS[@]:-}"; do kill "$p" 2>/dev/null || true; done; }
trap cleanup EXIT
fail() { echo "GAGAL: $*"; exit 1; }
ok() { echo "PASS  $*"; }
wait_health() { for _ in $(seq 1 60); do curl -fsS "http://127.0.0.1:$1/health" >/dev/null 2>&1 && return 0; sleep 1; done; fail "server port $1 tidak siap (lihat $LOGDIR)"; }
stop_pid() { kill "$1" 2>/dev/null || true; for _ in $(seq 1 20); do kill -0 "$1" 2>/dev/null || return 0; sleep 0.5; done; kill -9 "$1" 2>/dev/null || true; }

export NCK_FRONT_ORIGIN=https://front.example
echo "== 1. Database sumber nck_ops_src (skema public, seperti di hosting nyata) =="
psql "$NCK_PG_ADMIN_DSN" -qAt -c "DROP DATABASE IF EXISTS nck_ops_src" -c "CREATE DATABASE nck_ops_src" > /dev/null
SRC_DSN="$(python3 tools/dsn_with_db_v35.py "$NCK_PG_ADMIN_DSN" nck_ops_src)"
PROD=(NCK_ENV=production NCK_DB_BACKEND=postgres "NCK_POSTGRES_DSN=$SRC_DSN" NCK_POSTGRES_SCHEMA=public
      "NCK_CORS_ORIGINS=$NCK_FRONT_ORIGIN" NCK_FORCE_HTTPS=1 NCK_RATE_LIMIT=3000 NCK_EXPENSIVE_RATE_LIMIT=300
      "NCK_DB_PATH=$LOGDIR/unused.db" "NCK_BACKUP_DIR=$LOGDIR/appbackups" NCK_WORKER_MODE=both
      "NCK_ADMIN_TOKEN=$NCK_ADMIN_TOKEN" "NCK_OPERATOR_TOKEN=$NCK_OPERATOR_TOKEN" "NCK_VIEWER_TOKEN=$NCK_VIEWER_TOKEN")
unset OPENAI_API_KEY GEMINI_API_KEY OPENAI_BASE_URL NCK_OLLAMA_URL 2>/dev/null || true

echo "== 2. Server produksi MENOLAK start pada konfigurasi lemah =="
expect_refuse() {  # $1=label  $2=potongan pesan  sisanya=penimpa env
  local label="$1" pat="$2"; shift 2
  set +e
  env "${PROD[@]}" "$@" timeout 90 "$PY" -m uvicorn main:app --host 127.0.0.1 --port "$PORT4" > "$LOGDIR/refuse_$label.log" 2>&1
  local rc=$?
  set -e
  if [ "$rc" -eq 0 ] || [ "$rc" -eq 124 ]; then fail "start dengan konfigurasi '$label' seharusnya DITOLAK (kode keluar $rc)"; fi
  grep -q "production security configuration invalid" "$LOGDIR/refuse_$label.log" || fail "pesan penolakan '$label' tidak ditemukan di log"
  grep -q "$pat" "$LOGDIR/refuse_$label.log" || fail "pesan penolakan '$label' tidak menyebut '$pat'"
  for t in "$NCK_ADMIN_TOKEN" "$NCK_OPERATOR_TOKEN" "$NCK_VIEWER_TOKEN"; do
    ! grep -qF "$t" "$LOGDIR/refuse_$label.log" || fail "log penolakan '$label' membocorkan token"
  done
  ok "start ditolak: $label (kode $rc), pesan jelas, tanpa kebocoran token"
}
expect_refuse token_lemah "NCK_ADMIN_TOKEN" NCK_ADMIN_TOKEN=lemah
expect_refuse cors_bintang "NCK_CORS_ORIGINS" NCK_CORS_ORIGINS='*'
expect_refuse previous_sama_dengan_token_aktif "must differ" "NCK_VIEWER_TOKEN_PREVIOUS=$NCK_ADMIN_TOKEN"
expect_refuse previous_pendek "NCK_VIEWER_TOKEN_PREVIOUS" NCK_VIEWER_TOKEN_PREVIOUS=pendek

echo "== 3. Server produksi VALID: uji HTTP nyata =="
env "${PROD[@]}" "$PY" -m uvicorn main:app --host 127.0.0.1 --port "$PORT" > "$LOGDIR/uvicorn_ops1.log" 2>&1 &
API1=$!; PIDS+=("$API1")
wait_health "$PORT"
export NCK_HTTP_BASE="http://127.0.0.1:$PORT"
"$PY" tests/http_checks_ops_v35.py seed || fail "seed data"
"$PY" tests/http_checks_ops_v35.py api || fail "uji HTTP fase api"

echo "== 4. Backup terenkripsi + uji putar-balik =="
export NCK_BACKUP_DSN="$SRC_DSN" NCK_BACKUP_SCHEMA=public
BKPASS='kalimat-sandi-uji-cukup-panjang'
NCK_BACKUP_OUT="$LOGDIR/bk" NCK_BACKUP_PASSPHRASE="$BKPASS" bash tools/pg_backup_v35.sh | tee "$LOGDIR/backup1.out"
[ "$(ls "$LOGDIR/bk" | wc -l | tr -d ' ')" = 2 ] || fail "folder backup harus berisi tepat 2 berkas (dump.enc + meta)"
ls "$LOGDIR/bk" | grep -q '\.dump\.enc$' || fail "berkas .dump.enc tidak ada"
! ls "$LOGDIR/bk" | grep -q '\.dump$' || fail "berkas dump POLOS tidak boleh tertinggal di folder keluaran"
python3 - "$LOGDIR/bk/backup_meta.json" <<'PYEOF' || fail "isi meta tidak sesuai"
import json, sys
m = json.load(open(sys.argv[1]))
assert m['encrypted'] is True and m['schema'] == 'public' and len(m['tables']) >= 30, m.keys()
assert m['total_rows_before'] > 0 and len(m['sha256']) == 64 and m['bytes'] > 1000
assert not any(k in json.dumps(m) for k in ('kalimat-sandi', 'postgresql://'))
print('meta OK: %d tabel, %d baris, mayor %d' % (len(m['tables']), m['total_rows_before'], m['server_major']))
PYEOF
ok "backup: tepat 2 berkas, terenkripsi, meta valid tanpa rahasia"
# berkas terenkripsi tidak boleh memuat teks polos dari data
! grep -aq "isi uji backup nomor" "$LOGDIR/bk"/*.enc || fail "data polos terlihat di berkas terenkripsi"
ok "data polos tidak terlihat di dalam berkas terenkripsi"

echo "== 5. Latihan restore (jalur utama) =="
drill() {  # $1=folder ; env lain diwarisi
  if [ "${NCK_OPS_DRILL_MODE:-dsn}" = docker ]; then
    NCK_DRILL_START_DOCKER=1 NCK_DRILL_IN="$1" bash tools/restore_drill_v35.sh
  else
    NCK_DRILL_DSN="$NCK_PG_ADMIN_DSN" NCK_DRILL_IN="$1" bash tools/restore_drill_v35.sh
  fi
}
drill_dsn() { NCK_DRILL_DSN="$NCK_PG_ADMIN_DSN" NCK_DRILL_IN="$1" bash tools/restore_drill_v35.sh; }
NCK_BACKUP_PASSPHRASE="$BKPASS" NCK_DRILL_RESULT="$LOGDIR/drill_result.json" drill "$LOGDIR/bk" | tee "$LOGDIR/drill1.out"
grep -q "LATIHAN RESTORE BERHASIL" "$LOGDIR/drill1.out" || fail "latihan restore utama gagal"
ok "latihan restore berhasil (mode ${NCK_OPS_DRILL_MODE:-dsn})"

echo "== 6. Uji NEGATIF: kerusakan HARUS terdeteksi =="
must_fail() {  # $1=label $2=potongan pesan ; perintah dijalankan dari stdin-argumen sisanya
  local label="$1" pat="$2"; shift 2
  if "$@" > "$LOGDIR/neg_$label.out" 2>&1; then fail "$label: seharusnya GAGAL tetapi lulus"; fi
  grep -q "$pat" "$LOGDIR/neg_$label.out" || { cat "$LOGDIR/neg_$label.out"; fail "$label: gagal tetapi pesan tidak menyebut '$pat'"; }
  ok "$label -> gagal dengan pesan: $pat"
}
cp -r "$LOGDIR/bk" "$LOGDIR/bk_rusak"
python3 - "$LOGDIR/bk_rusak"/*.enc <<'PYEOF'
import sys
p = sys.argv[1]
b = bytearray(open(p, 'rb').read())
b[len(b) // 2] ^= 0xFF
open(p, 'wb').write(bytes(b))
PYEOF
must_fail berkas_rusak "TIDAK cocok" env NCK_BACKUP_PASSPHRASE="$BKPASS" bash -c 'NCK_DRILL_DSN="$0" NCK_DRILL_IN="$1" bash tools/restore_drill_v35.sh' "$NCK_PG_ADMIN_DSN" "$LOGDIR/bk_rusak"
must_fail sandi_salah "dekripsi gagal" env NCK_BACKUP_PASSPHRASE='sandi-yang-salah-sekali' bash -c 'NCK_DRILL_DSN="$0" NCK_DRILL_IN="$1" bash tools/restore_drill_v35.sh' "$NCK_PG_ADMIN_DSN" "$LOGDIR/bk"
must_fail tanpa_sandi "NCK_BACKUP_PASSPHRASE kosong" env -u NCK_BACKUP_PASSPHRASE bash -c 'NCK_DRILL_DSN="$0" NCK_DRILL_IN="$1" bash tools/restore_drill_v35.sh' "$NCK_PG_ADMIN_DSN" "$LOGDIR/bk"
cp -r "$LOGDIR/bk" "$LOGDIR/bk_meta_salah"
python3 - "$LOGDIR/bk_meta_salah/backup_meta.json" <<'PYEOF'
import json, sys
p = sys.argv[1]
m = json.load(open(p))
t = sorted(m['tables'])[0]
m['tables'][t]['before'] += 1000
m['tables'][t]['after'] += 1000
json.dump(m, open(p, 'w'))
PYEOF
must_fail jumlah_baris_beda "PERBEDAAN" env NCK_BACKUP_PASSPHRASE="$BKPASS" bash -c 'NCK_DRILL_DSN="$0" NCK_DRILL_IN="$1" bash tools/restore_drill_v35.sh' "$NCK_PG_ADMIN_DSN" "$LOGDIR/bk_meta_salah"
cp -r "$LOGDIR/bk" "$LOGDIR/bk_meta_tabel"
python3 - "$LOGDIR/bk_meta_tabel/backup_meta.json" <<'PYEOF'
import json, sys
p = sys.argv[1]
m = json.load(open(p))
del m['tables'][sorted(m['tables'])[0]]
json.dump(m, open(p, 'w'))
PYEOF
must_fail tabel_tak_terduga "tabel tak terduga" env NCK_BACKUP_PASSPHRASE="$BKPASS" bash -c 'NCK_DRILL_DSN="$0" NCK_DRILL_IN="$1" bash tools/restore_drill_v35.sh' "$NCK_PG_ADMIN_DSN" "$LOGDIR/bk_meta_tabel"
must_fail backup_sandi_pendek "terlalu pendek" env NCK_BACKUP_OUT="$LOGDIR/bk_x" NCK_BACKUP_PASSPHRASE=pendek bash tools/pg_backup_v35.sh
must_fail backup_skema_kosong "tidak memiliki tabel" env NCK_BACKUP_OUT="$LOGDIR/bk_x" NCK_BACKUP_SCHEMA=tidak_ada NCK_BACKUP_PASSPHRASE="$BKPASS" bash tools/pg_backup_v35.sh
must_fail backup_skema_injeksi "nama skema tidak valid" env NCK_BACKUP_OUT="$LOGDIR/bk_x" "NCK_BACKUP_SCHEMA=public; DROP TABLE x" NCK_BACKUP_PASSPHRASE="$BKPASS" bash tools/pg_backup_v35.sh
must_fail backup_dsn_salah "tidak bisa terhubung" env NCK_BACKUP_OUT="$LOGDIR/bk_x" "NCK_BACKUP_DSN=postgresql://nobody@127.0.0.1:1/x?connect_timeout=3" bash tools/pg_backup_v35.sh
echo "== 7. Backup TANPA sandi (peringatan wajib) + latihan =="
NCK_BACKUP_OUT="$LOGDIR/bk_plain" NCK_BACKUP_PASSPHRASE= bash tools/pg_backup_v35.sh > "$LOGDIR/plain.out" 2> "$LOGDIR/plain.err"
grep -q "TIDAK terenkripsi" "$LOGDIR/plain.err" || fail "peringatan 'TIDAK terenkripsi' tidak muncul"
ls "$LOGDIR/bk_plain" | grep -q '\.dump$' || fail "dump polos tidak ada"
env -u NCK_BACKUP_PASSPHRASE bash -c 'NCK_DRILL_DSN="$0" NCK_DRILL_IN="$1" bash tools/restore_drill_v35.sh' "$NCK_PG_ADMIN_DSN" "$LOGDIR/bk_plain" > "$LOGDIR/drill_plain.out"
grep -q "LATIHAN RESTORE BERHASIL" "$LOGDIR/drill_plain.out" || fail "latihan backup polos gagal"
ok "backup polos: peringatan tampil, latihan restore berhasil"

echo "== 8. Laporan ke API + kesiapan =="
export NCK_BASE_URL="$NCK_HTTP_BASE"
"$PY" tools/report_backup_v35.py --kind backup --ok true --meta "$LOGDIR/bk/backup_meta.json" --detail "uji CI" --wait 20
"$PY" tools/report_backup_v35.py --kind restore_drill --ok true --bytes 1 --detail "uji CI" --wait 20
ok "pelapor mencatat backup dan latihan restore"
NCK_ADMIN_TOKEN=salah-salah-salah-salah-salah-salah-salah "$PY" tools/report_backup_v35.py --kind backup --ok true --wait 20 > "$LOGDIR/report_bad.out" 2>&1 && fail "pelapor dengan token salah seharusnya gagal" || true
grep -q "GAGAL melapor" "$LOGDIR/report_bad.out" || fail "pesan pelapor token salah tidak jelas"
ok "pelapor dengan token salah gagal cepat dan jelas"
"$PY" tests/http_checks_ops_v35.py after_report || fail "uji HTTP fase after_report"

echo "== 9. Preflight terhadap URL hidup =="
NCK_VIEWER_TOKEN="$NCK_VIEWER_TOKEN" "$PY" tools/prod_preflight_v35.py --url "http://127.0.0.1:$PORT" --frontend-origin "$NCK_FRONT_ORIGIN" --allow-http --wait 10 | tee "$LOGDIR/preflight1.out"
grep -q "Putusan server: siap_dengan_catatan" "$LOGDIR/preflight1.out" || fail "putusan preflight tidak sesuai"
grep -q "RINGKAS: .* 0 gagal" "$LOGDIR/preflight1.out" || fail "preflight melaporkan GAGAL"
ok "preflight lulus (hanya peringatan HTTP lokal)"
if NCK_VIEWER_TOKEN=token-salah-token-salah-token-salah-1234 "$PY" tools/prod_preflight_v35.py --url "http://127.0.0.1:$PORT" --allow-http --wait 5 > "$LOGDIR/preflight_bad.out" 2>&1; then fail "preflight dengan token salah seharusnya GAGAL"; fi
grep -q "Token viewer ditolak" "$LOGDIR/preflight_bad.out" || fail "pesan token viewer ditolak tidak muncul"
if "$PY" tools/prod_preflight_v35.py --url "http://127.0.0.1:9" --allow-http --wait 3 > "$LOGDIR/preflight_down.out" 2>&1; then fail "preflight ke server mati seharusnya GAGAL"; fi
grep -q "tidak menjawab 200" "$LOGDIR/preflight_down.out" || fail "pesan server mati tidak muncul"
if "$PY" tools/prod_preflight_v35.py --url "http://127.0.0.1:$PORT" --wait 5 --viewer-token "$NCK_VIEWER_TOKEN" > "$LOGDIR/preflight_http.out" 2>&1; then fail "preflight HTTP tanpa --allow-http seharusnya GAGAL"; fi
grep -q "wajib HTTPS" "$LOGDIR/preflight_http.out" || fail "pesan wajib HTTPS tidak muncul"
ok "preflight gagal dengan benar: token salah, server mati, HTTP tanpa izin"

echo "== 10. Rotasi token tanpa putus (server terpisah) =="
stop_pid "$API1"
OLDV="TOKEN-LAMA-$(printf 'q%.0s' $(seq 1 36))"; NEWV="TOKEN-BARU-$(printf 'n%.0s' $(seq 1 36))"
env "${PROD[@]}" "NCK_VIEWER_TOKEN=$NEWV" "NCK_VIEWER_TOKEN_PREVIOUS=$OLDV" "$PY" -m uvicorn main:app --host 127.0.0.1 --port "$PORT2" > "$LOGDIR/uvicorn_ops2.log" 2>&1 &
API2=$!; PIDS+=("$API2"); wait_health "$PORT2"
NCK_HTTP_BASE="http://127.0.0.1:$PORT2" "$PY" tests/http_checks_ops_v35.py rotation "$OLDV" "$NEWV" || fail "rotasi fase 1"
stop_pid "$API2"
env "${PROD[@]}" "NCK_VIEWER_TOKEN=$NEWV" "$PY" -m uvicorn main:app --host 127.0.0.1 --port "$PORT3" > "$LOGDIR/uvicorn_ops3.log" 2>&1 &
API3=$!; PIDS+=("$API3"); wait_health "$PORT3"
NCK_HTTP_BASE="http://127.0.0.1:$PORT3" "$PY" tests/http_checks_ops_v35.py rotation_done "$OLDV" "$NEWV" || fail "rotasi fase 2"

echo "== 11. Log server tidak membocorkan rahasia =="
for f in "$LOGDIR"/*.log "$LOGDIR"/*.out "$LOGDIR"/*.err; do
  [ -f "$f" ] || continue
  for t in "$NCK_ADMIN_TOKEN" "$NCK_OPERATOR_TOKEN" "$OLDV" "$NEWV" "$BKPASS"; do
    ! grep -qF "$t" "$f" || fail "rahasia ditemukan di $(basename "$f")"
  done
done
ok "tidak ada token/sandi di log server maupun keluaran skrip"
psql "$NCK_PG_ADMIN_DSN" -qAt -c "DROP DATABASE IF EXISTS nck_ops_src" -c "DROP DATABASE IF EXISTS nck_drill" > /dev/null 2>&1 || true
echo; echo "OPS RINGKAS: semua pemeriksaan integrasi Tahap 35 lulus"
