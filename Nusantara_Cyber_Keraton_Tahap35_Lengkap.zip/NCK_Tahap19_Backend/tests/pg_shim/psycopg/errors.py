class Error(Exception):
    sqlstate = None


class DatabaseError(Error):
    pass


class IntegrityError(DatabaseError):
    pass


class ProgrammingError(DatabaseError):
    pass
