"""Shim PENGUJIAN: meniru subset API psycopg 3 lewat proses `psql`.

Dipakai hanya jika driver psycopg asli tidak terpasang (mis. sandbox tanpa internet).
Semantik SQL dijalankan oleh server PostgreSQL asli, tetapi BUKAN driver produksi:
  - parameter diinterpolasi sebagai literal berkutip (tak-bertipe), bukan server-side binding
  - hasil SELECT dibungkus json_agg sehingga tipe diambil dari JSON (float integral bisa kembali sebagai int)
Di produksi dan CI gunakan psycopg[binary] asli.
"""
import json
import os
import re
import subprocess
import uuid

from . import errors  # noqa: F401
from .errors import DatabaseError, Error, IntegrityError, ProgrammingError

SOCK = os.environ.get('NCK_TEST_PGSOCK', '/var/lib/postgresql/sock')
PGUSER = os.environ.get('NCK_TEST_PGUSER', 'postgres')


def _parse_dsn(dsn):
    m = re.search(r'/([A-Za-z0-9_]+)(?:\?|$)', dsn)
    return m.group(1) if m else 'postgres'


def _lit(v):
    if v is None:
        return 'NULL'
    if isinstance(v, bool):
        return 'TRUE' if v else 'FALSE'
    if isinstance(v, (int, float)):
        return repr(v)
    if isinstance(v, (bytes, bytearray)):
        return "'\\x" + bytes(v).hex() + "'::bytea"
    if isinstance(v, (list, tuple)):
        return 'ARRAY[' + ','.join(_lit(x) for x in v) + ']'
    return "'" + str(v).replace("'", "''") + "'"


def _bind(sql, params):
    if params is None:
        return sql
    it = iter(params)
    used = [0]

    def rep(m):
        if m.group(0) == '%%':
            return '%'
        try:
            val = next(it)
        except StopIteration:
            raise ProgrammingError('jumlah parameter kurang')
        used[0] += 1
        return _lit(val)
    out = re.sub(r'%%|%s', rep, sql)
    if used[0] != len(params):
        raise ProgrammingError(f'jumlah parameter tidak cocok: dipakai {used[0]}, diberi {len(params)}')
    return out


class Cursor:
    def __init__(self, conn):
        self._c = conn
        self.description = None
        self.rowcount = -1
        self._rows = []
        self._pos = 0

    def execute(self, sql, params=None):
        self._c._run(self, _bind(sql, params))
        return self

    def executemany(self, sql, seq):
        total = 0
        for p in seq:
            self.execute(sql, p)
            total += max(self.rowcount, 0)
        self.rowcount = total
        return self

    def fetchone(self):
        if self._pos >= len(self._rows):
            return None
        r = self._rows[self._pos]
        self._pos += 1
        return r

    def fetchall(self):
        r = self._rows[self._pos:]
        self._pos = len(self._rows)
        return r

    def fetchmany(self, size=1):
        r = self._rows[self._pos:self._pos + size]
        self._pos += len(r)
        return r

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


class _Tx:
    def __init__(self, conn):
        self.c = conn
        self.owned = False
        self.sp = None

    def __enter__(self):
        c = self.c
        if not c._in_tx:
            c._send_ctl('BEGIN')
            c._in_tx = True
            self.owned = True
        else:
            c._sp += 1
            self.sp = f'nck_sp_{c._sp}'
            c._send_ctl('SAVEPOINT ' + self.sp)
        return self

    def __exit__(self, et, ev, tb):
        c = self.c
        if self.owned:
            c._send_ctl('ROLLBACK' if et else 'COMMIT')
            c._in_tx = False
        else:
            if et:
                c._send_ctl(f'ROLLBACK TO SAVEPOINT {self.sp}')
            c._send_ctl(f'RELEASE SAVEPOINT {self.sp}')
        return False


class Connection:
    def __init__(self, dsn, **kw):
        self._db = _parse_dsn(dsn)
        self._p = subprocess.Popen(
            ['psql', '-X', '-q', '-A', '-t', '-h', SOCK, '-U', PGUSER, '-d', self._db],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        self._in_tx = False
        self._sp = 0
        self._send_raw("\\set VERBOSITY verbose\n")
        self._drain()
        opt = kw.get('options', '')
        m = re.search(r'search_path=([A-Za-z0-9_,]+)', opt or '')
        if m:
            self._run(Cursor(self), f'SET search_path TO {m.group(1)}')
            self._send_ctl('COMMIT') if self._in_tx else None
            self._in_tx = False

    # --- komunikasi
    def _send_raw(self, text):
        self._p.stdin.write(text)
        self._p.stdin.flush()

    def _drain(self):
        tok = '__END_' + uuid.uuid4().hex + '__'
        self._send_raw(f'\\echo {tok}\n')
        while True:
            line = self._p.stdout.readline()
            if line == '':
                raise Error('psql berhenti')
            if line.strip() == tok:
                return

    def _exec_text(self, sql):
        tok = '__END_' + uuid.uuid4().hex + '__'
        self._send_raw(sql.rstrip().rstrip(';') + ';\n\\echo ' + tok + '\n')
        lines = []
        while True:
            line = self._p.stdout.readline()
            if line == '':
                raise Error('psql berhenti')
            if line.strip() == tok:
                break
            lines.append(line.rstrip('\n'))
        err = None
        for ln in lines:
            m = re.match(r'(?:psql:.*?:\d+:\s*)?ERROR:\s+([0-9A-Z]{5}):\s*(.*)', ln)
            if m:
                err = (m.group(1), m.group(2))
                break
        if err:
            cls = IntegrityError if err[0].startswith('23') else DatabaseError
            e = cls(f'{err[0]}: {err[1]}')
            e.sqlstate = err[0]
            raise e
        return [ln for ln in lines if not re.match(r'(NOTICE|WARNING|DETAIL|HINT|LOCATION|CONTEXT|QUERY|STATEMENT):', ln)
                and not re.match(r'psql:.*(NOTICE|WARNING)', ln)]

    def _send_ctl(self, sql):
        self._exec_text(sql)

    def _run(self, cur, sql):
        word = sql.lstrip().split(None, 1)[0].upper() if sql.strip() else ''
        if not self._in_tx and word not in ('BEGIN', 'COMMIT', 'ROLLBACK', 'START'):
            self._send_ctl('BEGIN')
            self._in_tx = True
        cur.description, cur.rowcount, cur._rows, cur._pos = None, -1, [], 0
        has_ret = bool(re.search(r'\bRETURNING\b', sql, re.I))
        if word in ('SELECT', 'WITH', 'VALUES', 'SHOW'):
            out = self._exec_text(f'SELECT COALESCE(json_agg(row_to_json(_q)),\'[]\'::json) FROM ({sql.rstrip().rstrip(";")}) _q')
            data = json.loads(''.join(out) or '[]')
            self._fill(cur, data, sql)
            cur.rowcount = len(data)
        elif word in ('INSERT', 'UPDATE', 'DELETE'):
            if has_ret:
                out = self._exec_text('WITH _r AS (' + sql.rstrip().rstrip(';') + ') SELECT COALESCE(json_agg(row_to_json(_r)),\'[]\'::json) FROM _r')
                data = json.loads(''.join(out) or '[]')
                self._fill(cur, data, sql)
                cur.rowcount = len(data)
            else:
                out = self._exec_text('WITH _r AS (' + sql.rstrip().rstrip(';') + ' RETURNING 1) SELECT count(*) FROM _r')
                cur.rowcount = int(''.join(out).strip() or 0)
        else:
            self._exec_text(sql)

    @staticmethod
    def _fill(cur, data, sql):
        if data:
            names = list(data[0].keys())
            cur.description = [(n,) for n in names]
            cur._rows = [tuple(r.get(n) for n in names) for r in data]
        else:
            cur.description = [('?',)] if re.match(r'\s*(SELECT|WITH)', sql, re.I) else None
            cur._rows = []

    # --- API psycopg
    def cursor(self, *a, **k):
        return Cursor(self)

    def execute(self, sql, params=None):
        return self.cursor().execute(sql, params)

    def transaction(self):
        return _Tx(self)

    def commit(self):
        if self._in_tx:
            self._send_ctl('COMMIT')
            self._in_tx = False

    def rollback(self):
        if self._in_tx:
            self._send_ctl('ROLLBACK')
            self._in_tx = False

    def close(self):
        try:
            if self._in_tx:
                self._send_ctl('ROLLBACK')
        except Exception:
            pass
        try:
            self._p.stdin.close()
            self._p.wait(timeout=5)
        except Exception:
            self._p.kill()

    def __enter__(self):
        return self

    def __exit__(self, et, ev, tb):
        try:
            if et is None:
                self.commit()
            else:
                self.rollback()
        finally:
            self.close()
        return False


def connect(conninfo='', **kw):
    return Connection(conninfo, **kw)
