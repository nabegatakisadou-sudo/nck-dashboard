NUSANTARA CYBER-KERATON — BACKEND KUMULATIF TAHAP 19–35

Persyaratan: Python 3.10+.

INSTALASI
1. Ekstrak paket ZIP.
2. Masuk ke NCK_Tahap19_Backend.
3. Buat virtual environment: python -m venv .venv
4. Aktifkan environment dan instal: pip install -r requirements.txt
5. Salin .env.example menjadi .env, lalu isi token acak kuat untuk NCK_VIEWER_TOKEN, NCK_OPERATOR_TOKEN, dan NCK_ADMIN_TOKEN.
6. Isi OPENAI_API_KEY dan/atau GEMINI_API_KEY jika ingin memakai provider AI. Simpan semua secret hanya di environment backend.
7. Jalankan: uvicorn main:app --host 0.0.0.0 --port 8000
8. Tes GET /health dan buka /docs untuk dokumentasi API.

AUTENTIKASI & FRONTEND
- Header token: X-NCK-Token.
- Viewer dapat membaca data; Operator/Admin dapat melakukan operasi sesuai role.
- Dashboard HTML memakai URL backend tersimpan dan token sesi yang sudah digunakan tahap sebelumnya. Konfigurasikan CORS hanya untuk origin tepercaya dan gunakan HTTPS.

DATABASE
- Bawaan: SQLite, otomatis dibuat pada nck_enterprise.db atau lokasi NCK_DB_PATH (NCK_DB_BACKEND=sqlite).
- Opsional sejak Tahap 33: NCK_DB_BACKEND=postgres + NCK_POSTGRES_DSN (+ NCK_POSTGRES_SCHEMA) melalui nck_db.py.
  Jangan aktifkan sebelum migrasi terverifikasi dan diuji di staging. Panduan lengkap: ../README_Tahap33.txt
- Lakukan backup (SQLite: /api/v30/backups; PostgreSQL: pg_dump atau backup penyedia).
- Untuk deployment multi-instance, gunakan database bersama seperti PostgreSQL dan worker antrean durable.

TAHAP 26
- GET /api/v26/status
- GET /api/v26/command-center
- GET /api/v26/alerts
- POST /api/v26/alerts/{id}/ack
- GET /api/v26/productivity
- Kebijakan aktif Tahap 25 otomatis dicocokkan (global/project/agent) dan disisipkan ke prompt task Tahap 23.

TAHAP 34 (lihat ../README_Tahap34.txt untuk panduan lengkap)
- Backend untuk panel lama (chat, orkestrasi, knowledge, dokumen, intelligence, autonomous, kolaborasi, Command Center v13-v15):
  modul nck_legacy_v34.py; semua endpoint wajib token (viewer baca, operator tulis/AI, admin backup/restore).
- Provider AI: gemini, openai/custom (OPENAI_BASE_URL), ollama (NCK_OLLAMA_URL). Tanpa kunci -> 503 jelas, tidak ada hasil palsu.
- Eksekusi terdistribusi: NCK_WORKER_MODE=both|api|worker; worker mandiri: python worker_service_v34.py (butuh PostgreSQL bersama).
  GET /api/v34/status dan GET /api/v34/distributed/status.
- Unggah dokumen: NCK_UPLOAD_MAX_BYTES (bawaan 12 MB); PDF memerlukan pypdf (sudah di requirements.txt).
- Uji: tests/test_translate.py, pg_smoke.py, test_ddl_race.py, test_legacy_v34.py, test_distributed_v34.py,
  http_checks_v34.py + load_check_v34.py (dijalankan oleh tests/ci_http_pg_v34.sh di CI).

TAHAP 35 (lihat ../README_Tahap35.txt untuk panduan lengkap)
- Operasi produksi: modul nck_ops_v35.py. GET /ready (publik, memeriksa database, 503 tanpa rincian bila gagal);
  GET /api/v35/ops/status, /ops/readiness (daftar periksa dari server), /ops/metrics (metrik di memori, hilang saat restart);
  POST /api/v35/ops/backup-report (admin) dan GET /api/v35/ops/backups (operator).
- NCK_ENV=production = server menolak start bila token lemah/tidak berbeda, CORS kosong atau "*".
- Rotasi token tanpa downtime: NCK_VIEWER_TOKEN_PREVIOUS / NCK_OPERATOR_TOKEN_PREVIOUS / NCK_ADMIN_TOKEN_PREVIOUS.
- tools/: pg_backup_v35.sh (backup terverifikasi + enkripsi), restore_drill_v35.sh (latihan restore), prod_preflight_v35.py (uji asap URL produksi),
  report_backup_v35.py. Dijalankan lewat GitHub Actions "NCK Ops" (.github/workflows/nck-ops.yml).
- Uji: tests/test_ops_v35.py, tests/http_checks_ops_v35.py + tests/ci_ops_pg_v35.sh (dijalankan oleh NCK CI).

BATASAN
- Governance enforcement berbasis prompt dan audit; bukan sandbox deterministik atau jaminan kepatuhan sempurna.
- Alert ditampilkan melalui snapshot saat dashboard di-refresh, belum memakai WebSocket/push.
- BackgroundTasks masih berjalan in-process; untuk produksi perlu durable worker queue.
- Uji provider AI live dilakukan setelah kredensial dan server deployment tersedia.


TAHAP 28 — INFRASTRUKTUR CLUSTER (OPSIONAL)
- NCK_POSTGRES_DSN: koneksi PostgreSQL untuk registry node cluster v28.
- NCK_REDIS_URL: koneksi Redis untuk heartbeat node dan stream event infrastruktur nck:v28:infra-events.
- NCK_NODE_ID dan NCK_NODE_ROLE: identitas node.
- Pemeriksaan: GET /api/v28/infrastructure/status.
- Registrasi node: POST /api/v28/cluster/heartbeat (operator).
PENTING: PostgreSQL/Redis pada tahap ini dipakai untuk control-plane/registry/event bus, belum menggantikan SQLite seluruh data aplikasi atau mengaktifkan eksekusi task lintas-host.


TAHAP 29 — MIGRATION TOOLING & REDIS STREAM DISPATCH FOUNDATION
Lihat ../README_Tahap29.txt untuk prosedur, batasan, dan deployment. Core execution masih SQLite; worker dispatcher memerlukan executor adapter idempotent.


TAHAP 30–32 — Lihat ../README_Tahap30.txt, ../README_Tahap31.txt, ../README_Tahap32.txt.
(Alat migrasi Tahap 32 dan sebelumnya sudah usang; pakai tools/migrate_sqlite_to_postgres_v33.py.)

TAHAP 33 — ADAPTER DATABASE POSTGRESQL (OPSIONAL)
Lihat ../README_Tahap33.txt: adapter nck_db.py, endpoint /api/v33/status dan /api/v33/database/adapter,
alat migrasi v33 (checksum), tes otomatis di tests/, dan daftar batasan yang belum diuji.
Tes: python tests/test_translate.py ; python tests/pg_smoke.py (butuh NCK_TEST_PG_DSN).
