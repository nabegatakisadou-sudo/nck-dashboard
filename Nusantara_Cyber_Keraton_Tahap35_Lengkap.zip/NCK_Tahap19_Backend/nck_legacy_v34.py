"""NCK Tahap 34 - backend untuk panel dashboard lama (Tahap 6-15).

Panel lama memanggil endpoint yang tidak pernah ada di backend ini (/api/chat, /api/knowledge,
/api/documents, /api/v13/..., dst). Modul ini menyediakannya dengan kontrak yang dibaca langsung
dari kode dashboard. Prinsip:
  - semua endpoint wajib token (viewer baca, operator tulis/AI, admin backup/restore)
  - tidak ada hasil palsu: bila kunci AI belum diisi, jawaban 503 dengan pesan jelas
  - kompatibel SQLite dan PostgreSQL (lewat adapter nck_db)
  - perencanaan agen (autonomous/collaboration plan) dan pencarian dibuat LOKAL berbasis aturan
    kata kunci, bukan AI/embedding; respons menyebutkannya
"""
import asyncio
import html as _html
import io
import json
import math
import os
import re
import secrets
import zipfile
from collections import Counter
from datetime import datetime, timezone
from email.parser import BytesParser
from email.policy import HTTP as _HTTP_POLICY
from typing import Any, Optional

from fastapi import BackgroundTasks, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from nck_agents_v34 import AGENT_BY_ID, AGENTS_DIRECTORY

VERSION = '34.0.0'
STATE = {'llm': None}          # fungsi LLM; tes boleh menggantinya
PRIORITIES = ('critical', 'high', 'normal', 'low')
TASK_STATES = ('open', 'in_progress', 'completed', 'blocked')
MAX_TASKS = 12
UPLOAD_MAX_BYTES = min(int(os.getenv('NCK_UPLOAD_MAX_BYTES', str(12 * 1024 * 1024))), 25 * 1024 * 1024)
STALE_RUN_SECONDS = 900
BACKUP_FORMAT = 'nck-v34-backup'
_WORD = re.compile(r"[a-z0-9À-ɏ]{2,}")
_STOP = set('dan yang untuk dengan dari pada ini itu atau ke di akan agar para serta dalam oleh sebagai the and for of to in a an is are'.split())


# ------------------------------------------------------------------ utilitas murni
def _tok(s):
    return [w for w in _WORD.findall((s or '').lower()) if w not in _STOP]


def _new_id():
    return secrets.token_hex(6)


def _parse_dt(v):
    s = str(v or '').strip()
    if not s:
        return None
    s = s[:-1] + '+00:00' if s.endswith('Z') else s
    try:
        d = datetime.fromisoformat(s)
    except ValueError:
        return None
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


def _clean_model(m):
    if m is None or str(m).strip() == '':
        return None
    m = str(m).strip()
    if not re.fullmatch(r'[A-Za-z0-9._:\-]{1,80}', m):
        raise HTTPException(422, 'Nama model tidak valid (hanya huruf, angka, titik, titik dua, strip).')
    return m


def _provider(p):
    p = str(p or 'gemini').strip().lower()
    if p == 'custom':
        p = 'openai'
    if p not in ('gemini', 'openai', 'ollama'):
        raise HTTPException(422, 'Provider tidak dikenal. Gunakan gemini, openai/custom, atau ollama.')
    return p


def _agent_id(x):
    s = str(x or '').strip()
    if s.isdigit():
        s = s.zfill(2)
    if s not in AGENT_BY_ID:
        raise HTTPException(422, f'ID agen {s!r} tidak ada di direktori 50 agen.')
    return s


def _rank(items, query, fields):
    """TF-IDF leksikal sederhana. fields = [(kunci, bobot)]. Mengembalikan [(skor, item)] menurun."""
    terms = sorted(set(_tok(query)))
    if not terms or not items:
        return []
    docs = []
    for it in items:
        c = Counter()
        for key, w in fields:
            for t in _tok(str(it.get(key) or '')[:200000]):
                c[t] += w
        docs.append(c)
    n = len(items)
    df = {t: sum(1 for d in docs if d.get(t)) for t in terms}
    out = []
    for it, c in zip(items, docs):
        s = 0.0
        for t in terms:
            if c.get(t):
                s += math.log(1 + n / (1 + df[t])) * (1 + math.log(1 + c[t]))
        if s > 0:
            out.append((round(s, 4), it))
    out.sort(key=lambda x: -x[0])
    return out


def _snippet(text, query, width=260):
    text = text or ''
    low = text.lower()
    pos = -1
    for t in _tok(query):
        pos = low.find(t)
        if pos >= 0:
            break
    start = max(0, pos - 80) if pos >= 0 else 0
    s = text[start:start + width].replace('\n', ' ').strip()
    return ('…' if start else '') + s + ('…' if start + width < len(text) else '')


def validate_tasks(tasks):
    """Validasi DAG tugas; kembalikan daftar dict ternormalisasi atau lempar HTTPException 422."""
    if not tasks or len(tasks) > MAX_TASKS:
        raise HTTPException(422, f'Jumlah tugas harus 1 sampai {MAX_TASKS}.')
    out, ids = [], set()
    for t in tasks:
        tid = str(t.id).strip()
        if not tid or tid in ids:
            raise HTTPException(422, f'ID tugas kosong atau ganda: {tid!r}.')
        ids.add(tid)
        out.append({'id': tid, 'title': (t.title or tid).strip()[:200], 'agent_id': _agent_id(t.agent_id),
                    'instruction': t.instruction.strip(), 'depends_on': [str(d).strip() for d in (t.depends_on or [])]})
    for t in out:
        for d in t['depends_on']:
            if d not in ids or d == t['id']:
                raise HTTPException(422, f'Dependensi tidak valid pada tugas {t["id"]}: {d!r}.')
    indeg = {t['id']: len(set(t['depends_on'])) for t in out}
    ready = [i for i, v in indeg.items() if v == 0]
    seen = 0
    while ready:
        cur = ready.pop()
        seen += 1
        for t in out:
            if cur in t['depends_on']:
                indeg[t['id']] -= 1
                if indeg[t['id']] == 0:
                    ready.append(t['id'])
    if seen != len(out):
        raise HTTPException(422, 'Siklus dependensi terdeteksi. Dependensi harus membentuk DAG.')
    return out


def plan_by_keywords(goal, limit_specialists=3):
    """Rencana lokal berbasis kata kunci (BUKAN AI): analisis -> spesialis -> integrasi."""
    gt = set(_tok(goal))
    scored = []
    for a in AGENTS_DIRECTORY:
        at = set(_tok(' '.join([a['name'], a['role'], a['description'], a['division']])))
        ov = len(gt & at)
        if ov:
            scored.append((ov, a))
    scored.sort(key=lambda x: (-x[0], x[1]['id']))
    spec = [a for _, a in scored[:limit_specialists]]
    if not spec:
        spec = [AGENT_BY_ID['24']]
    analyst = AGENT_BY_ID['24']
    reviewer = AGENT_BY_ID['50']
    tasks = [{'id': 'T1', 'title': 'Analisis kebutuhan dan kerangka kerja', 'agent_id': analyst['id'], 'depends_on': [],
              'instruction': f'Analisis tujuan berikut, tentukan asumsi, ruang lingkup, dan kerangka langkah kerja.\nTujuan: {goal}'}]
    ids = []
    for i, a in enumerate(spec, 2):
        tid = f'T{i}'
        ids.append(tid)
        tasks.append({'id': tid, 'title': f'Pekerjaan spesialis: {a["role"]}', 'agent_id': a['id'], 'depends_on': ['T1'],
                      'instruction': f'Kerjakan bagian paling relevan dengan keahlian Anda ({a["role"]}) untuk tujuan ini. '
                                     f'Gunakan kerangka dari T1. Tandai asumsi dan keterbatasan.\nTujuan: {goal}'})
    tasks.append({'id': f'T{len(spec) + 2}', 'title': 'Tinjauan mutu dan integrasi', 'agent_id': reviewer['id'], 'depends_on': ids,
                  'instruction': 'Tinjau seluruh hasil spesialis, temukan celah/kontradiksi, lalu susun ringkasan terintegrasi dan daftar perbaikan.'})
    return tasks


# ------------------------------------------------------------------ ekstraksi dokumen
def _multipart(ctype, body):
    if not ctype or 'multipart/form-data' not in ctype.lower():
        raise HTTPException(415, 'Gunakan multipart/form-data.')
    raw = b'MIME-Version: 1.0\r\nContent-Type: ' + ctype.encode('latin-1', 'ignore') + b'\r\n\r\n' + body
    msg = BytesParser(policy=_HTTP_POLICY).parsebytes(raw)
    if not msg.is_multipart():
        raise HTTPException(400, 'Isi multipart tidak valid.')
    fields, files = {}, {}
    for part in msg.iter_parts():
        name = part.get_param('name', header='content-disposition')
        name = str(name[-1] if isinstance(name, tuple) else name)
        data = part.get_payload(decode=True) or b''
        fn = part.get_filename()
        if fn is not None:
            files[name] = (fn, data)
        else:
            fields[name] = data.decode('utf-8', 'replace')
    return fields, files


def extract_text(filename, data):
    ext = filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''
    if ext not in ('pdf', 'docx', 'txt', 'md'):
        raise HTTPException(415, 'Format tidak didukung. Gunakan pdf, docx, txt, atau md.')
    if ext in ('txt', 'md'):
        try:
            text = data.decode('utf-8')
        except UnicodeDecodeError:
            text = data.decode('latin-1')
    elif ext == 'docx':
        if not data.startswith(b'PK'):
            raise HTTPException(422, 'File bukan DOCX yang valid.')
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as zf:
                if len(zf.infolist()) > 3000:
                    raise HTTPException(422, 'Struktur DOCX tidak wajar.')
                info = zf.getinfo('word/document.xml')
                if info.file_size > 40 * 1024 * 1024:
                    raise HTTPException(422, 'Isi DOCX terlalu besar setelah dekompresi.')
                xml = zf.read(info).decode('utf-8', 'replace')
        except (zipfile.BadZipFile, KeyError):
            raise HTTPException(422, 'File bukan DOCX yang valid.')
        xml = re.sub(r'</w:p>', '\n', xml)
        xml = re.sub(r'<w:(?:tab|br)[^>]*/>', ' ', xml)
        text = _html.unescape(re.sub(r'<[^>]+>', '', xml))
    else:
        if not data.startswith(b'%PDF'):
            raise HTTPException(422, 'File bukan PDF yang valid.')
        try:
            from pypdf import PdfReader
        except ImportError:
            raise HTTPException(501, 'Pustaka pypdf belum terpasang di server (pip install pypdf).')
        try:
            reader = PdfReader(io.BytesIO(data))
            if reader.is_encrypted and not reader.decrypt(''):
                raise HTTPException(422, 'PDF terenkripsi; tidak dapat dibaca.')
            text = '\n'.join((p.extract_text() or '') for p in reader.pages[:300])
        except HTTPException:
            raise
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(422, 'PDF tidak dapat dibaca: ' + type(exc).__name__)
    text = re.sub(r'\n{3,}', '\n\n', text.replace('\x00', '')).strip()
    if not text:
        raise HTTPException(422, 'Tidak ada teks yang dapat diekstrak (mungkin dokumen hasil scan/gambar).')
    return ext, text[:2_000_000]


# ------------------------------------------------------------------ model request
class ChatIn34(BaseModel):
    message: str = Field(min_length=1, max_length=20000)
    provider: str = 'gemini'
    model: Optional[str] = None


class OrchTask34(BaseModel):
    id: str = Field(min_length=1, max_length=40)
    name: str = Field(default='Agen', max_length=120)
    role: str = Field(default='', max_length=200)
    instruction: str = Field(min_length=1, max_length=4000)


class Orchestrate34In(BaseModel):
    goal: str = Field(min_length=3, max_length=8000)
    tasks: list[OrchTask34] = Field(min_length=1, max_length=8)
    provider: str = 'gemini'
    model: Optional[str] = None


class KnowledgeIn34(BaseModel):
    title: str = Field(min_length=1, max_length=180)
    category: str = Field(default='Lainnya', max_length=80)
    tags: Any = None
    content: str = Field(min_length=1, max_length=30000)


class SearchIn34(BaseModel):
    query: str = Field(min_length=1, max_length=500)
    limit: int = 30
    scope: str = 'all'


class SummarizeIn34(BaseModel):
    provider: str = 'gemini'
    model: Optional[str] = None


class CompareIn34(BaseModel):
    question: str = Field(min_length=3, max_length=2000)
    sources: list[dict] = Field(min_length=2, max_length=8)
    provider: str = 'gemini'
    model: Optional[str] = None


class Task34(BaseModel):
    id: str = Field(min_length=1, max_length=40)
    title: str = Field(default='', max_length=200)
    agent_id: str = Field(min_length=1, max_length=10)
    instruction: str = Field(min_length=1, max_length=6000)
    depends_on: list[str] = Field(default_factory=list, max_length=12)


class AutoPlan34In(BaseModel):
    goal: str = Field(min_length=8, max_length=4000)
    provider: str = 'gemini'
    agents: Optional[list[dict]] = None     # diabaikan: server memakai direktorinya sendiri


class AutoRun34In(BaseModel):
    goal: str = Field(min_length=3, max_length=4000)
    tasks: list[Task34] = Field(min_length=1, max_length=MAX_TASKS)
    provider: str = 'gemini'
    model: Optional[str] = None
    max_parallel: int = 2
    max_retries: int = 1


class CollabPlan34In(BaseModel):
    goal: str = Field(min_length=8, max_length=4000)


class CollabRun34In(BaseModel):
    goal: str = Field(min_length=3, max_length=4000)
    shared_memory: str = Field(default='', max_length=8000)
    provider: str = 'gemini'
    model: Optional[str] = None
    tasks: list[Task34] = Field(min_length=1, max_length=MAX_TASKS)
    max_parallel: int = 2
    max_retries: int = 1
    correction_rounds: int = 1


class Project34In(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    description: str = Field(default='', max_length=4000)


class Memory34In(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    content: str = Field(min_length=1, max_length=20000)


class TaskNew34In(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    agent_id: str = Field(default='24', max_length=10)
    priority: str = 'normal'
    due_at: Optional[str] = None


class TaskPatch34In(BaseModel):
    status: Optional[str] = None
    score: Optional[int] = None


class Decision34In(BaseModel):
    decision: str
    note: str = Field(default='', max_length=1000)


class ScheduleIn34(BaseModel):
    project_id: str = Field(min_length=1, max_length=40)
    title: str = Field(min_length=1, max_length=200)
    due_at: str


class Prepare34In(BaseModel):
    project_id: str = Field(min_length=1, max_length=40)
    task_ids: list[str] = Field(min_length=1, max_length=MAX_TASKS)
    goal: str = Field(default='', max_length=4000)
    provider: str = 'gemini'
    mode: str = 'sequential'


class Launch34In(BaseModel):
    approval_id: str = Field(min_length=1, max_length=40)


class Feedback34In(BaseModel):
    task_id: str = Field(min_length=1, max_length=40)
    rating: int
    notes: str = Field(default='', max_length=2000)


class Route34In(BaseModel):
    goal: str = Field(min_length=3, max_length=2000)
    project_id: Optional[str] = None
    limit: int = 5


DDL = """
CREATE TABLE IF NOT EXISTS lg34_knowledge(
  id TEXT PRIMARY KEY, title TEXT NOT NULL, category TEXT NOT NULL, tags TEXT NOT NULL DEFAULT '[]',
  content TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS lg34_documents(
  id TEXT PRIMARY KEY, title TEXT NOT NULL, filename TEXT NOT NULL, file_type TEXT NOT NULL, category TEXT NOT NULL,
  text TEXT NOT NULL, char_count INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS lg34_projects(
  id TEXT PRIMARY KEY, name TEXT UNIQUE NOT NULL, description TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS lg34_project_memory(
  id TEXT PRIMARY KEY, project_id TEXT NOT NULL, title TEXT NOT NULL, content TEXT NOT NULL,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, FOREIGN KEY(project_id) REFERENCES lg34_projects(id));
CREATE TABLE IF NOT EXISTS lg34_tasks(
  id TEXT PRIMARY KEY, project_id TEXT NOT NULL, title TEXT NOT NULL, agent_id TEXT NOT NULL,
  priority TEXT NOT NULL DEFAULT 'normal', status TEXT NOT NULL DEFAULT 'open', score INTEGER, due_at TEXT,
  result TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, FOREIGN KEY(project_id) REFERENCES lg34_projects(id));
CREATE TABLE IF NOT EXISTS lg34_approvals(
  id TEXT PRIMARY KEY, title TEXT NOT NULL, details TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'pending',
  payload TEXT NOT NULL DEFAULT '{}', decided_by TEXT, decision_note TEXT, created_at TEXT NOT NULL, decided_at TEXT);
CREATE TABLE IF NOT EXISTS lg34_schedules(
  id TEXT PRIMARY KEY, project_id TEXT NOT NULL, title TEXT NOT NULL, due_at TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'scheduled', created_at TEXT NOT NULL, FOREIGN KEY(project_id) REFERENCES lg34_projects(id));
CREATE TABLE IF NOT EXISTS lg34_runs(
  id TEXT PRIMARY KEY, kind TEXT NOT NULL, goal TEXT NOT NULL, status TEXT NOT NULL, provider TEXT NOT NULL, model TEXT,
  config TEXT NOT NULL DEFAULT '{}', summary TEXT NOT NULL DEFAULT '{}', results TEXT NOT NULL DEFAULT '[]',
  final TEXT, quality_review TEXT NOT NULL DEFAULT '{}', shared_memory TEXT NOT NULL DEFAULT '{}',
  approval_id TEXT, project_id TEXT, synced INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, finished_at TEXT);
CREATE TABLE IF NOT EXISTS lg34_run_events(
  id INTEGER PRIMARY KEY, run_id TEXT NOT NULL, event TEXT NOT NULL, agent TEXT, task_id TEXT, message TEXT,
  created_at TEXT NOT NULL, FOREIGN KEY(run_id) REFERENCES lg34_runs(id));
CREATE TABLE IF NOT EXISTS lg34_feedback(
  id INTEGER PRIMARY KEY, task_id TEXT NOT NULL, agent_id TEXT NOT NULL, rating INTEGER NOT NULL, notes TEXT,
  created_at TEXT NOT NULL, FOREIGN KEY(task_id) REFERENCES lg34_tasks(id));
CREATE TABLE IF NOT EXISTS lg34_ai_calls(
  id INTEGER PRIMARY KEY, provider TEXT NOT NULL, call_type TEXT NOT NULL, agent_id TEXT,
  prompt_chars INTEGER NOT NULL DEFAULT 0, completion_chars INTEGER NOT NULL DEFAULT 0,
  prompt_tokens INTEGER NOT NULL DEFAULT 0, completion_tokens INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_lg34_tasks_project ON lg34_tasks(project_id);
CREATE INDEX IF NOT EXISTS idx_lg34_events_run ON lg34_run_events(run_id);
CREATE INDEX IF NOT EXISTS idx_lg34_runs_kind ON lg34_runs(kind, created_at);
CREATE UNIQUE INDEX IF NOT EXISTS ux_lg34_runs_approval ON lg34_runs(approval_id);
"""
# tabel yang ikut backup/restore: urutan induk -> anak; kolom id bertipe INTEGER tidak diikutkan
BACKUP_TABLES = {
    'lg34_knowledge': ['id', 'title', 'category', 'tags', 'content', 'created_at', 'updated_at'],
    'lg34_documents': ['id', 'title', 'filename', 'file_type', 'category', 'text', 'char_count', 'created_at'],
    'lg34_projects': ['id', 'name', 'description', 'status', 'created_at'],
    'lg34_project_memory': ['id', 'project_id', 'title', 'content', 'created_at', 'updated_at'],
    'lg34_tasks': ['id', 'project_id', 'title', 'agent_id', 'priority', 'status', 'score', 'due_at', 'result', 'created_at', 'updated_at'],
    'lg34_approvals': ['id', 'title', 'details', 'status', 'payload', 'decided_by', 'decision_note', 'created_at', 'decided_at'],
    'lg34_schedules': ['id', 'project_id', 'title', 'due_at', 'status', 'created_at'],
    'lg34_runs': ['id', 'kind', 'goal', 'status', 'provider', 'model', 'config', 'summary', 'results', 'final', 'quality_review',
                  'shared_memory', 'approval_id', 'project_id', 'synced', 'created_at', 'updated_at', 'finished_at'],
    'lg34_feedback': ['task_id', 'agent_id', 'rating', 'notes', 'created_at'],
}
MAX_BACKUP_ROWS = 20000
OPTIONAL_COLS = {'score', 'due_at', 'result', 'decided_by', 'decision_note', 'decided_at', 'model', 'final', 'approval_id',
                 'project_id', 'finished_at', 'notes'}


def register(app, *, conn, auth, require_operator, audit, now, llm, systems_by_number, service=''):
    STATE['llm'] = llm

    def require_admin(role=Depends(auth)):
        if role != 'admin':
            raise HTTPException(403, 'Hak Admin diperlukan.')
        return role

    # ---------------------------------------------------------------- DB helpers
    def rows(sql, params=()):
        with conn() as c:
            return [dict(r) for r in c.execute(sql, params).fetchall()]

    def one(sql, params=()):
        r = rows(sql, params)
        return r[0] if r else None

    def run_sql(sql, params=()):
        with conn() as c:
            c.execute(sql, params)

    def init_v34():
        with conn() as c:
            c.executescript(DDL)

    @app.on_event('startup')
    def startup_v34():
        init_v34()

    # ---------------------------------------------------------------- AI
    def ai_http(exc):
        msg = str(exc)[:500]
        return HTTPException(503 if 'belum dikonfigurasi' in msg else 502, msg)

    async def ask(provider, system, user, model=None, call_type='agent', agent=''):
        p = _provider(provider)
        reply, usage = await STATE['llm'](p, system, user, _clean_model(model))
        usage = usage or {}
        try:
            run_sql('INSERT INTO lg34_ai_calls(provider,call_type,agent_id,prompt_chars,completion_chars,prompt_tokens,completion_tokens,created_at) '
                    'VALUES(?,?,?,?,?,?,?,?)', (p, call_type, agent, len(user), len(reply or ''),
                                                int(usage.get('prompt_tokens', 0) or 0), int(usage.get('completion_tokens', 0) or 0), now()))
        except Exception:  # noqa: BLE001 - pencatatan tidak boleh menggagalkan jawaban
            pass
        return reply or ''

    def agent_system(aid):
        a = AGENT_BY_ID[aid]
        base = systems_by_number.get(aid) or (
            f'Anda adalah {a["name"]}, spesialis {a["role"]} pada divisi {a["division"]}. {a["description"]}')
        return (base + ' Anda bekerja dalam tim multi-agen. Jangan mengarang fakta; tandai asumsi dan keterbatasan. '
                       'Jawab dalam bahasa Indonesia dengan hasil konkret dan terstruktur.')

    async def body_bytes(request, limit):
        cl = request.headers.get('content-length')
        if cl and cl.isdigit() and int(cl) > limit:
            raise HTTPException(413, 'Ukuran request melewati batas.')
        buf = bytearray()
        async for chunk in request.stream():
            buf.extend(chunk)
            if len(buf) > limit:
                raise HTTPException(413, 'Ukuran request melewati batas.')
        return bytes(buf)

    # ---------------------------------------------------------------- run engine (DAG)
    def add_event(run_id, event, agent='', task_id='', message=''):
        run_sql('INSERT INTO lg34_run_events(run_id,event,agent,task_id,message,created_at) VALUES(?,?,?,?,?,?)',
                (run_id, event, str(agent)[:120], str(task_id)[:40], str(message)[:1500], now()))
        run_sql('UPDATE lg34_runs SET updated_at=? WHERE id=?', (now(), run_id))

    def events_of(run_id, limit=300):
        ev = rows('SELECT event,agent,task_id,message,created_at FROM lg34_run_events WHERE run_id=? ORDER BY id DESC LIMIT ?', (run_id, limit))
        ev.reverse()
        return [{'event': e['event'], 'time': e['created_at'], 'agent': e['agent'] or '', 'task_id': e['task_id'] or '',
                 'message': e['message'] or '', 'error': (e['message'] if 'failed' in e['event'] else '')} for e in ev]

    def new_run(kind, goal, provider, model, config, approval_id=None, project_id=None, status='running'):
        rid = _new_id()
        run_sql('INSERT INTO lg34_runs(id,kind,goal,status,provider,model,config,approval_id,project_id,created_at,updated_at) '
                'VALUES(?,?,?,?,?,?,?,?,?,?,?)', (rid, kind, goal, status, provider, model, json.dumps(config, ensure_ascii=False),
                                                   approval_id, project_id, now(), now()))
        return rid

    def reap_stale():
        """Run 'running' yang tidak ada kegiatan > STALE_RUN_SECONDS dianggap gagal (aman untuk multi-instance)."""
        for r in rows("SELECT id,updated_at FROM lg34_runs WHERE status IN ('running','queued')"):
            d = _parse_dt(r['updated_at'])
            if d and (datetime.now(timezone.utc) - d).total_seconds() > STALE_RUN_SECONDS:
                run_sql("UPDATE lg34_runs SET status='failed',final=COALESCE(final,'Terhenti: tidak ada kegiatan, kemungkinan server dimulai ulang.'),"
                        "finished_at=?,updated_at=? WHERE id=? AND status IN ('running','queued')", (now(), now(), r['id']))
                add_event(r['id'], 'run.failed', message='Dihentikan otomatis (stale).')

    async def execute_dag(run_id, goal, tasks, provider, model, max_parallel, max_retries, shared=None):
        max_parallel = max(1, min(5, int(max_parallel or 1)))
        max_retries = max(0, min(3, int(max_retries or 0)))
        sem = asyncio.Semaphore(max_parallel)
        done = {t['id']: asyncio.Event() for t in tasks}
        results = {}

        async def work(t):
            try:
                await work_inner(t)
            except Exception as exc:  # noqa: BLE001 - satu tugas rusak tidak boleh membuat dependen menunggu selamanya
                results.setdefault(t['id'], {'id': t['id'], 'status': 'failed', 'agent': AGENT_BY_ID[t['agent_id']]['name'], 'title': t['title'],
                                             'attempts': 0, 'error': 'Kesalahan internal: ' + str(exc)[:300]})
            finally:
                done[t['id']].set()

        async def work_inner(t):
            for d in t['depends_on']:
                await done[d].wait()
            agent = AGENT_BY_ID[t['agent_id']]
            if any(results[d]['status'] != 'completed' for d in t['depends_on']):
                results[t['id']] = {'id': t['id'], 'status': 'skipped', 'agent': agent['name'], 'title': t['title'], 'attempts': 0,
                                    'error': 'Dilewati karena dependensi gagal/dilewati.'}
                add_event(run_id, 'task.skipped', agent['name'], t['id'], 'Dependensi tidak selesai.')
                return
            dep_ctx = '\n\n'.join(f'HASIL {d}:\n{results[d].get("result", "")[:6000]}' for d in t['depends_on'])
            user = (f'TUJUAN UTAMA:\n{goal}\n\nTUGAS ANDA ({t["id"]} - {t["title"]}):\n{t["instruction"]}\n\n'
                    f'KONTEKS DEPENDENSI:\n{dep_ctx or "Tidak ada."}')
            if shared is not None:
                user += '\n\nSHARED MEMORY TIM:\n' + json.dumps(shared, ensure_ascii=False)[:4000]
            last = ''
            async with sem:
                for attempt in range(1, max_retries + 2):
                    add_event(run_id, 'task.started', agent['name'], t['id'], f'percobaan {attempt}')
                    try:
                        reply = await ask(provider, agent_system(t['agent_id']), user, model, 'agent', t['agent_id'])
                        if not reply.strip():
                            raise RuntimeError('Provider mengembalikan jawaban kosong.')
                        results[t['id']] = {'id': t['id'], 'status': 'completed', 'agent': agent['name'], 'title': t['title'],
                                            'attempts': attempt, 'result': reply, 'agent_id': t['agent_id']}
                        if shared is not None:
                            shared.setdefault('ringkasan_tugas', {})[t['id']] = reply[:300]
                        add_event(run_id, 'task.completed', agent['name'], t['id'], f'{len(reply)} karakter')
                        break
                    except Exception as exc:  # noqa: BLE001
                        last = str(exc)[:600]
                        add_event(run_id, 'task.failed' if attempt > max_retries else 'task.retry', agent['name'], t['id'], last)
                        if attempt <= max_retries:
                            await asyncio.sleep(0.2)
                else:
                    results[t['id']] = {'id': t['id'], 'status': 'failed', 'agent': agent['name'], 'title': t['title'],
                                        'attempts': max_retries + 1, 'error': last}

        await asyncio.gather(*(work(t) for t in tasks))
        return [results[t['id']] for t in tasks]

    def summarize_results(results):
        s = Counter(r['status'] for r in results)
        total = len(results)
        status = 'completed' if s['completed'] == total else ('partial' if s['completed'] else 'failed')
        return status, {'total': total, 'completed': s['completed'], 'failed': s['failed'], 'skipped': s['skipped']}

    async def quality_review(provider, model, goal, text_or_results):
        if isinstance(text_or_results, list):
            done_r = [r for r in text_or_results if r['status'] == 'completed']
            if not done_r:
                return {'reason': 'Tidak ada hasil selesai yang dapat direview.'}
            body = '\n\n'.join(f'[{r["agent"]} - {r["title"]}]\n{r["result"][:3000]}' for r in done_r)[:14000]
        else:
            body = str(text_or_results)[:14000]
        prompt = ('Nilai kualitas hasil kerja tim berikut terhadap tujuan. Balas HANYA JSON valid: '
                  '{"score":0-100,"feedback":"..."}. Nilai akurasi, kelengkapan, relevansi, dan keterlaksanaan.\n\n'
                  f'TUJUAN:\n{goal}\n\nHASIL:\n{body}')
        try:
            text = await ask(provider, 'Anda adalah reviewer AI independen yang kritis dan berbasis bukti.', prompt, model, 'reviewer')
            m = re.search(r'\{.*\}', text, re.S)
            if not m:
                return {'reason': 'Reviewer tidak mengembalikan JSON yang valid.'}
            obj = json.loads(m.group(0))
            return {'score': max(0, min(100, int(obj.get('score', 0)))), 'feedback': str(obj.get('feedback', ''))[:3000]}
        except Exception as exc:  # noqa: BLE001
            return {'reason': 'Review gagal: ' + str(exc)[:300]}

    def finish_run(run_id, status, summary, results, final=None, review=None, shared=None):
        run_sql('UPDATE lg34_runs SET status=?,summary=?,results=?,final=?,quality_review=?,shared_memory=?,finished_at=?,updated_at=? WHERE id=?',
                (status, json.dumps(summary), json.dumps(results, ensure_ascii=False), final, json.dumps(review or {}, ensure_ascii=False),
                 json.dumps(shared or {}, ensure_ascii=False), now(), now(), run_id))
        add_event(run_id, 'run.' + status, message=f'{summary["completed"]}/{summary["total"]} tugas selesai')

    async def collab_job(run_id, goal, tasks, provider, model, max_parallel, max_retries, rounds, shared):
        try:
            results = await execute_dag(run_id, goal, tasks, provider, model, max_parallel, max_retries, shared)
            status, summary = summarize_results(results)
            final, review = None, {}
            if summary['completed']:
                body = '\n\n'.join(f'[{r["agent"]} - {r["title"]}]\n{r["result"][:4000]}' for r in results if r['status'] == 'completed')[:20000]
                final = await ask(provider, 'Anda adalah Kanjeng Prabu, koordinator tim agen. Susun sintesis akhir yang runtut, konsisten, dan jujur tentang keterbatasan.',
                                  f'TUJUAN:\n{goal}\n\nHASIL TIM:\n{body}', model, 'synthesis')
                add_event(run_id, 'synthesis.completed')
                review = await quality_review(provider, model, goal, final)
                for i in range(1, rounds + 1):
                    if review.get('score', 100) >= 75:
                        break
                    add_event(run_id, 'correction.round', message=f'putaran {i}; skor {review.get("score")}')
                    final = await ask(provider, 'Anda adalah Kanjeng Prabu. Perbaiki sintesis berdasarkan umpan balik reviewer tanpa menambah fakta yang tidak ada di hasil tim.',
                                      f'TUJUAN:\n{goal}\n\nSINTESIS SAAT INI:\n{final[:12000]}\n\nUMPAN BALIK REVIEW:\n{review.get("feedback", "")}', model, 'correction')
                    review = await quality_review(provider, model, goal, final)
            finish_run(run_id, status, summary, results, final, review, shared)
        except Exception as exc:  # noqa: BLE001
            run_sql("UPDATE lg34_runs SET status='failed',final=?,finished_at=?,updated_at=? WHERE id=?", ('Run gagal: ' + str(exc)[:500], now(), now(), run_id))
            add_event(run_id, 'run.failed', message=str(exc)[:500])

    async def v14_job(run_id, goal, tasks, provider, max_parallel):
        try:
            results = await execute_dag(run_id, goal, tasks, provider, None, max_parallel, 1, None)
            status, summary = summarize_results(results)
            review = await quality_review(provider, None, goal, results) if summary['completed'] else {}
            finish_run(run_id, status, summary, results, None, review)
        except Exception as exc:  # noqa: BLE001
            run_sql("UPDATE lg34_runs SET status='failed',final=?,finished_at=?,updated_at=? WHERE id=?", ('Run gagal: ' + str(exc)[:500], now(), now(), run_id))
            add_event(run_id, 'run.failed', message=str(exc)[:500])

    # ================================================================ status
    @app.get('/api/v34/status')
    def v34_status(role=Depends(auth)):
        counts = {t: one(f'SELECT COUNT(*) AS n FROM {t}')['n'] for t in BACKUP_TABLES}
        return {'version': VERSION, 'service': service, 'role': role, 'agents': len(AGENTS_DIRECTORY), 'tables': counts,
                'providers': {'gemini_configured': bool(os.getenv('GEMINI_API_KEY')), 'openai_configured': bool(os.getenv('OPENAI_API_KEY')),
                              'ollama_configured': bool(os.getenv('NCK_OLLAMA_URL'))},
                'upload_max_bytes': UPLOAD_MAX_BYTES, 'planning': 'lokal berbasis kata kunci (bukan AI)',
                'search': 'TF-IDF leksikal lokal (bukan embedding semantik)'}

    # ================================================================ Tahap 6-7: chat & orkestrasi
    @app.post('/api/chat')
    async def chat34(data: ChatIn34, role=Depends(require_operator)):
        try:
            reply = await ask(data.provider, 'Anda adalah asisten Nusantara Cyber-Keraton. Jawab dalam bahasa pengguna dengan jelas dan jujur.',
                              data.message, data.model, 'chat')
        except HTTPException:
            raise
        except Exception as exc:  # noqa: BLE001
            raise ai_http(exc)
        audit(role, 'v34.chat', f'provider={data.provider}; chars={len(data.message)}')
        return {'reply': reply, 'provider': _provider(data.provider), 'model': _clean_model(data.model)}

    @app.post('/api/orchestrate')
    async def orchestrate34(data: Orchestrate34In, role=Depends(require_operator)):
        provider, model = _provider(data.provider), _clean_model(data.model)
        results, prev = [], ''
        try:
            for t in data.tasks:
                a = AGENT_BY_ID.get(str(t.id).zfill(2))
                system = agent_system(a['id']) if a else (f'Anda adalah {t.name}, spesialis {t.role}. Jangan mengarang fakta; tandai asumsi.')
                user = f'TUJUAN UTAMA:\n{data.goal}\n\nTUGAS ANDA:\n{t.instruction}\n\nHASIL AGEN SEBELUMNYA:\n{prev[-6000:] or "Belum ada."}'
                reply = await ask(provider, system, user, model, 'orchestrate', a['id'] if a else '')
                results.append({'agent': a['name'] if a else t.name, 'role': a['role'] if a else t.role, 'model': model or provider, 'result': reply})
                prev += f'\n\n[{results[-1]["agent"]}]\n{reply}'
            final = await ask(provider, 'Anda adalah Kanjeng Prabu. Susun sintesis akhir yang konsisten dan jujur tentang keterbatasan.',
                              f'TUJUAN:\n{data.goal}\n\nHASIL AGEN:\n{prev[-16000:]}', model, 'synthesis')
        except HTTPException:
            raise
        except Exception as exc:  # noqa: BLE001
            raise ai_http(exc)
        audit(role, 'v34.orchestrate', f'agents={len(data.tasks)}; provider={provider}')
        return {'final': final, 'agent_results': results, 'provider': provider}

    # ================================================================ Tahap 8: knowledge vault
    def kb_item(r):
        try:
            tags = json.loads(r['tags'] or '[]')
        except ValueError:
            tags = []
        return {'id': r['id'], 'title': r['title'], 'category': r['category'], 'tags': tags, 'content': r['content'],
                'created_at': r['created_at'], 'updated_at': r['updated_at']}

    def norm_tags(t):
        if isinstance(t, list):
            vals = [str(x).strip() for x in t]
        else:
            vals = [x.strip() for x in str(t or '').split(',')]
        return [x[:40] for x in vals if x][:20]

    @app.get('/api/knowledge')
    def kb_list(role=Depends(auth)):
        return {'items': [kb_item(r) for r in rows('SELECT * FROM lg34_knowledge ORDER BY updated_at DESC LIMIT 500')]}

    @app.post('/api/knowledge')
    def kb_add(data: KnowledgeIn34, role=Depends(require_operator)):
        kid, ts = _new_id(), now()
        run_sql('INSERT INTO lg34_knowledge(id,title,category,tags,content,created_at,updated_at) VALUES(?,?,?,?,?,?,?)',
                (kid, data.title.strip(), data.category.strip() or 'Lainnya', json.dumps(norm_tags(data.tags), ensure_ascii=False), data.content, ts, ts))
        audit(role, 'v34.knowledge.add', kid)
        return kb_item(one('SELECT * FROM lg34_knowledge WHERE id=?', (kid,)))

    @app.delete('/api/knowledge/{kid}')
    def kb_delete(kid: str, role=Depends(require_operator)):
        if not one('SELECT id FROM lg34_knowledge WHERE id=?', (kid,)):
            raise HTTPException(404, 'Catatan tidak ditemukan.')
        run_sql('DELETE FROM lg34_knowledge WHERE id=?', (kid,))
        audit(role, 'v34.knowledge.delete', kid)
        return {'deleted': kid}

    @app.post('/api/knowledge/search')
    def kb_search(data: SearchIn34, role=Depends(auth)):
        items = [kb_item(r) for r in rows('SELECT * FROM lg34_knowledge ORDER BY updated_at DESC LIMIT 1000')]
        for it in items:
            it['_tags'] = ' '.join(it['tags'])
        ranked = _rank(items, data.query, [('title', 3), ('_tags', 2), ('category', 1), ('content', 1)])
        lim = max(1, min(100, int(data.limit or 50)))
        out = []
        for s, it in ranked[:lim]:
            it = {k: v for k, v in it.items() if k != '_tags'}
            it['score'] = s
            out.append(it)
        return {'items': out, 'method': 'TF-IDF leksikal lokal'}

    # ================================================================ Tahap 9: dokumen
    DOC_COLS = 'id,title,filename,file_type,category,char_count,created_at'

    @app.get('/api/documents')
    def doc_list(role=Depends(auth)):
        return {'items': rows(f'SELECT {DOC_COLS}, SUBSTR(text,1,300) AS excerpt FROM lg34_documents ORDER BY created_at DESC LIMIT 300')}

    @app.post('/api/documents/upload')
    async def doc_upload(request: Request, role=Depends(require_operator)):
        body = await body_bytes(request, UPLOAD_MAX_BYTES + 65536)
        fields, files = _multipart(request.headers.get('content-type', ''), body)
        if 'file' not in files:
            raise HTTPException(422, 'Field file tidak ditemukan.')
        fn, data = files['file']
        if len(data) > UPLOAD_MAX_BYTES:
            raise HTTPException(413, f'File melebihi batas {UPLOAD_MAX_BYTES // (1024 * 1024)} MB.')
        fn = re.sub(r'[\x00-\x1f]', '', fn.replace('\\', '/').split('/')[-1])[:200] or 'dokumen'
        ext, text = extract_text(fn, data)
        did = _new_id()
        title = (fields.get('title', '').strip() or fn)[:180]
        run_sql('INSERT INTO lg34_documents(id,title,filename,file_type,category,text,char_count,created_at) VALUES(?,?,?,?,?,?,?,?)',
                (did, title, fn, ext, (fields.get('category', '').strip() or 'Dokumen')[:80], text, len(text), now()))
        audit(role, 'v34.document.upload', f'{did}; {fn}; {len(text)} karakter')
        return {'id': did, 'title': title, 'filename': fn, 'file_type': ext, 'char_count': len(text)}

    @app.post('/api/documents/search')
    def doc_search(data: SearchIn34, role=Depends(auth)):
        items = rows('SELECT id,title,filename,file_type,category,char_count,created_at,SUBSTR(text,1,200000) AS text FROM lg34_documents ORDER BY created_at DESC LIMIT 200')
        out = []
        for s, it in _rank(items, data.query, [('title', 3), ('text', 1)])[:max(1, min(100, int(data.limit or 50)))]:
            out.append({**{k: v for k, v in it.items() if k != 'text'}, 'excerpt': _snippet(it['text'], data.query), 'score': s})
        return {'items': out, 'method': 'TF-IDF leksikal lokal'}

    @app.get('/api/documents/{did}')
    def doc_get(did: str, role=Depends(auth)):
        d = one('SELECT * FROM lg34_documents WHERE id=?', (did,))
        if not d:
            raise HTTPException(404, 'Dokumen tidak ditemukan.')
        return d

    @app.delete('/api/documents/{did}')
    def doc_delete(did: str, role=Depends(require_operator)):
        if not one('SELECT id FROM lg34_documents WHERE id=?', (did,)):
            raise HTTPException(404, 'Dokumen tidak ditemukan.')
        run_sql('DELETE FROM lg34_documents WHERE id=?', (did,))
        audit(role, 'v34.document.delete', did)
        return {'deleted': did}

    @app.post('/api/documents/{did}/summarize')
    async def doc_summarize(did: str, data: SummarizeIn34, role=Depends(require_operator)):
        d = one('SELECT id,title,text FROM lg34_documents WHERE id=?', (did,))
        if not d:
            raise HTTPException(404, 'Dokumen tidak ditemukan.')
        size, max_chunks = 6000, 6
        chunks = [d['text'][i:i + size] for i in range(0, len(d['text']), size)]
        truncated = len(chunks) > max_chunks
        chunks = chunks[:max_chunks]
        sysm = 'Anda adalah analis dokumen. Ringkas dengan setia pada isi; jangan menambah fakta. Gunakan bahasa Indonesia.'
        try:
            parts = []
            for i, ch in enumerate(chunks, 1):
                parts.append(await ask(data.provider, sysm, f'Ringkas bagian {i} dari {len(chunks)} dokumen "{d["title"]}":\n\n{ch}', data.model, 'summarize'))
            summary = parts[0] if len(parts) == 1 else await ask(
                data.provider, sysm, 'Gabungkan ringkasan bagian berikut menjadi satu ringkasan utuh:\n\n' + '\n\n'.join(parts), data.model, 'summarize')
        except HTTPException:
            raise
        except Exception as exc:  # noqa: BLE001
            raise ai_http(exc)
        if truncated:
            summary += f'\n\n(Catatan: hanya {max_chunks * size:,} karakter pertama yang diringkas.)'
        audit(role, 'v34.document.summarize', did)
        return {'summary': summary, 'chunks_processed': len(chunks), 'truncated': truncated}

    # ================================================================ Tahap 9b: intelligence
    def corpus(scope):
        items = []
        if scope in ('all', 'knowledge'):
            for r in rows('SELECT * FROM lg34_knowledge ORDER BY updated_at DESC LIMIT 1000'):
                k = kb_item(r)
                items.append({'source_id': 'knowledge:' + k['id'], 'source_type': 'knowledge', 'source_name': k['category'], 'title': k['title'],
                              'text': k['content'], 'tags': k['tags'], 'category': k['category']})
        if scope in ('all', 'documents'):
            for r in rows('SELECT id,title,filename,category,SUBSTR(text,1,200000) AS text FROM lg34_documents ORDER BY created_at DESC LIMIT 200'):
                items.append({'source_id': 'document:' + r['id'], 'source_type': 'document', 'source_name': r['filename'], 'title': r['title'],
                              'text': r['text'], 'tags': [], 'category': r['category']})
        return items

    @app.post('/api/intelligence/search')
    def intel_search(data: SearchIn34, role=Depends(auth)):
        scope = data.scope if data.scope in ('all', 'documents', 'knowledge') else 'all'
        items = corpus(scope)
        ranked = _rank(items, data.query, [('title', 3), ('text', 1)])
        res = [{'title': it['title'], 'source_type': it['source_type'], 'source_name': it['source_name'], 'score': s,
                'snippet': _snippet(it['text'], data.query), 'source_id': it['source_id']}
               for s, it in ranked[:max(1, min(100, int(data.limit or 30)))]]
        return {'results': res, 'count': len(res), 'method': 'TF-IDF leksikal lokal (bukan embedding semantik)'}

    @app.get('/api/intelligence/graph')
    def intel_graph(role=Depends(auth)):
        nodes, edges = Counter(), Counter()
        for it in corpus('all'):
            labels = sorted({it['category']} | set(it['tags']))
            for lb in labels:
                nodes[lb] += 1
            for i in range(len(labels)):
                for j in range(i + 1, len(labels)):
                    edges[(labels[i], labels[j])] += 1
        return {'nodes': [{'label': k, 'count': v} for k, v in nodes.most_common(60)],
                'edges': [{'from': a, 'to': b, 'weight': w} for (a, b), w in edges.most_common(100)],
                'note': 'Graf dibangun dari kategori dan tag yang muncul bersama pada satu sumber; bukan analisis semantik.'}

    @app.post('/api/intelligence/compare')
    async def intel_compare(data: CompareIn34, role=Depends(require_operator)):
        srcs = [{'title': str(s.get('title', ''))[:200], 'source_id': str(s.get('source_id', ''))[:80], 'snippet': str(s.get('snippet', ''))[:2000]}
                for s in data.sources]
        body = '\n\n'.join(f'[{i}] {s["title"]} ({s["source_id"]})\n{s["snippet"]}' for i, s in enumerate(srcs, 1))
        try:
            analysis = await ask(data.provider, 'Anda adalah analis yang membandingkan sumber. Rujuk nomor sumber, tunjukkan kesamaan, perbedaan, dan keterbatasan; jangan menambah fakta di luar sumber.',
                                 f'PERTANYAAN:\n{data.question}\n\nSUMBER:\n{body}', data.model, 'compare')
        except HTTPException:
            raise
        except Exception as exc:  # noqa: BLE001
            raise ai_http(exc)
        audit(role, 'v34.intelligence.compare', f'sources={len(srcs)}')
        return {'analysis': analysis, 'sources': [{'title': s['title'], 'source_id': s['source_id']} for s in srcs]}

    # ================================================================ Tahap 10-12: agen, autonomous, kolaborasi
    @app.get('/api/agents')
    def agents34(role=Depends(auth)):
        return {'agents': [{'id': a['id'], 'name': a['name'], 'role': a['role'], 'division': a['division'], 'description': a['description']}
                           for a in AGENTS_DIRECTORY]}

    @app.post('/api/autonomous/plan')
    def auto_plan(data: AutoPlan34In, role=Depends(auth)):
        return {'tasks': plan_by_keywords(data.goal),
                'notice': 'Rencana disusun LOKAL dengan aturan kata kunci (bukan AI). Tinjau agen dan instruksi sebelum dijalankan.'}

    @app.post('/api/autonomous/run')
    async def auto_run(data: AutoRun34In, role=Depends(require_operator)):
        provider, model = _provider(data.provider), _clean_model(data.model)
        tasks = validate_tasks(data.tasks)
        mp, mr = max(1, min(5, int(data.max_parallel))), max(0, min(3, int(data.max_retries)))
        rid = new_run('autonomous', data.goal, provider, model, {'max_parallel': mp, 'max_retries': mr})
        add_event(rid, 'run.started', message=f'{len(tasks)} tugas')
        results = await execute_dag(rid, data.goal, tasks, provider, model, mp, mr, None)
        status, summary = summarize_results(results)
        review = await quality_review(provider, model, data.goal, results) if summary['completed'] else {'reason': 'Tidak ada hasil selesai.'}
        finish_run(rid, status, summary, results, None, review)
        audit(role, 'v34.autonomous.run', f'{rid}; {status}; {summary["completed"]}/{summary["total"]}')
        return {'run_id': rid, 'status': status, 'summary': summary, 'agent_results': results, 'quality_review': review,
                'execution_log': events_of(rid)}

    @app.get('/api/autonomous/logs')
    def auto_logs(limit: int = 20, role=Depends(auth)):
        reap_stale()
        lim = max(1, min(100, int(limit)))
        ev = rows("SELECT e.event,e.agent,e.task_id,e.message,e.created_at,r.goal FROM lg34_run_events e JOIN lg34_runs r ON r.id=e.run_id "
                  "WHERE r.kind='autonomous' ORDER BY e.id DESC LIMIT ?", (lim,))
        return {'events': [{'event': e['event'], 'time': e['created_at'], 'agent': e['agent'] or '', 'task_id': e['task_id'] or '',
                            'goal': e['goal'], 'error': e['message'] if 'failed' in e['event'] else ''} for e in ev]}

    @app.post('/api/collaboration/plan')
    def collab_plan(data: CollabPlan34In, role=Depends(auth)):
        return {'tasks': plan_by_keywords(data.goal),
                'notice': 'Workflow disusun LOKAL dengan aturan kata kunci (bukan AI). Periksa dependensi dan agen sebelum dijalankan.'}

    @app.post('/api/collaboration/run')
    async def collab_run(data: CollabRun34In, background_tasks: BackgroundTasks, role=Depends(require_operator)):
        provider, model = _provider(data.provider), _clean_model(data.model)
        tasks = validate_tasks(data.tasks)
        mp, mr = max(1, min(5, int(data.max_parallel))), max(0, min(3, int(data.max_retries)))
        rounds = max(0, min(3, int(data.correction_rounds)))
        shared = {'catatan_awal': data.shared_memory, 'ringkasan_tugas': {}}
        rid = new_run('collaboration', data.goal, provider, model, {'max_parallel': mp, 'max_retries': mr, 'correction_rounds': rounds, 'total_tasks': len(tasks)})
        add_event(rid, 'run.started', message=f'{len(tasks)} tugas')
        background_tasks.add_task(collab_job, rid, data.goal, tasks, provider, model, mp, mr, rounds, shared)
        audit(role, 'v34.collaboration.run', f'{rid}; tasks={len(tasks)}')
        return {'run_id': rid, 'status': 'running', 'events': events_of(rid)}

    @app.get('/api/collaboration/runs/{rid}')
    def collab_get(rid: str, role=Depends(auth)):
        reap_stale()
        r = one("SELECT * FROM lg34_runs WHERE id=? AND kind='collaboration'", (rid,))
        if not r:
            raise HTTPException(404, 'Run tidak ditemukan.')
        summary = json.loads(r['summary'] or '{}')
        if not summary:   # masih berjalan: hitung dari event
            st = {}
            for e in rows('SELECT event,task_id FROM lg34_run_events WHERE run_id=?', (rid,)):
                if e['event'] in ('task.completed', 'task.failed', 'task.skipped'):
                    st[e['task_id']] = e['event']
            summary = {'total': int(json.loads(r['config'] or '{}').get('total_tasks', 0)),
                       'completed': sum(1 for v in st.values() if v == 'task.completed'),
                       'failed': sum(1 for v in st.values() if v == 'task.failed'),
                       'skipped': sum(1 for v in st.values() if v == 'task.skipped')}
        return {'run_id': r['id'], 'status': r['status'], 'goal': r['goal'], 'summary': summary, 'events': events_of(rid),
                'final': r['final'], 'quality_review': json.loads(r['quality_review'] or '{}'),
                'shared_memory': json.loads(r['shared_memory'] or '{}'), 'results': json.loads(r['results'] or '[]')}

    @app.get('/api/collaboration/logs')
    def collab_logs(limit: int = 20, role=Depends(auth)):
        reap_stale()
        return {'items': rows("SELECT id,status,goal,created_at FROM lg34_runs WHERE kind='collaboration' ORDER BY created_at DESC LIMIT ?",
                              (max(1, min(100, int(limit))),))}

    # ================================================================ Tahap 13: command center
    def project_or_404(pid):
        p = one('SELECT * FROM lg34_projects WHERE id=?', (pid,))
        if not p:
            raise HTTPException(404, 'Proyek tidak ditemukan.')
        return p

    @app.get('/api/v13/overview')
    def v13_overview(role=Depends(auth)):
        n = lambda sql: one(sql)['n']  # noqa: E731
        usage = one('SELECT COUNT(*) AS n, '
                    'COALESCE(SUM(CASE WHEN prompt_tokens>0 THEN prompt_tokens ELSE prompt_chars/4 END),0) AS tin, '
                    'COALESCE(SUM(CASE WHEN completion_tokens>0 THEN completion_tokens ELSE completion_chars/4 END),0) AS tout FROM lg34_ai_calls')
        return {'role': role, 'projects': n('SELECT COUNT(*) AS n FROM lg34_projects'), 'tasks': n('SELECT COUNT(*) AS n FROM lg34_tasks'),
                'pending_approvals': n("SELECT COUNT(*) AS n FROM lg34_approvals WHERE status='pending'"),
                'ai_calls': int(usage['n']), 'input_tokens_est': int(usage['tin']), 'output_tokens_est': int(usage['tout']),
                'cost_usd': None}

    @app.get('/api/v13/projects')
    def v13_projects(role=Depends(auth)):
        return {'items': rows('SELECT * FROM lg34_projects ORDER BY created_at DESC LIMIT 200')}

    @app.post('/api/v13/projects')
    def v13_project_create(data: Project34In, role=Depends(require_operator)):
        pid = _new_id()
        if one('SELECT id FROM lg34_projects WHERE name=?', (data.name.strip(),)):
            raise HTTPException(409, 'Nama proyek sudah tersedia.')
        try:
            run_sql('INSERT INTO lg34_projects(id,name,description,status,created_at) VALUES(?,?,?,?,?)',
                    (pid, data.name.strip(), data.description.strip(), 'active', now()))
        except Exception as exc:  # noqa: BLE001 - balapan dua permintaan: UNIQUE menolak
            import nck_db
            if isinstance(exc, nck_db.INTEGRITY_ERRORS):
                raise HTTPException(409, 'Nama proyek sudah tersedia.')
            raise
        audit(role, 'v34.project.create', data.name)
        return one('SELECT * FROM lg34_projects WHERE id=?', (pid,))

    @app.get('/api/v13/projects/{pid}/memory')
    def v13_memory_list(pid: str, role=Depends(auth)):
        project_or_404(pid)
        return {'items': rows('SELECT * FROM lg34_project_memory WHERE project_id=? ORDER BY updated_at DESC LIMIT 200', (pid,))}

    @app.post('/api/v13/projects/{pid}/memory')
    def v13_memory_add(pid: str, data: Memory34In, role=Depends(require_operator)):
        project_or_404(pid)
        mid, ts = _new_id(), now()
        run_sql('INSERT INTO lg34_project_memory(id,project_id,title,content,created_at,updated_at) VALUES(?,?,?,?,?,?)',
                (mid, pid, data.title.strip(), data.content, ts, ts))
        audit(role, 'v34.memory.add', f'{pid}; {data.title[:80]}')
        return one('SELECT * FROM lg34_project_memory WHERE id=?', (mid,))

    def task_stats(project_id=None):
        w, p = ('WHERE project_id=?', (project_id,)) if project_id else ('', ())
        r = one(f'SELECT COUNT(score) AS rated, AVG(score) AS avg FROM lg34_tasks {w}', p)
        return {'rated_tasks': int(r['rated'] or 0), 'average_score': round(float(r['avg']), 2) if r['avg'] is not None else None}

    @app.get('/api/v13/projects/{pid}/tasks')
    def v13_tasks(pid: str, role=Depends(auth)):
        project_or_404(pid)
        return {'items': rows('SELECT * FROM lg34_tasks WHERE project_id=? ORDER BY created_at DESC LIMIT 300', (pid,)),
                'performance': task_stats(pid)}

    @app.post('/api/v13/projects/{pid}/tasks')
    def v13_task_create(pid: str, data: TaskNew34In, role=Depends(require_operator)):
        project_or_404(pid)
        if data.priority not in PRIORITIES:
            raise HTTPException(422, 'Prioritas harus salah satu dari: ' + ', '.join(PRIORITIES))
        due = None
        if data.due_at:
            d = _parse_dt(data.due_at)
            if not d:
                raise HTTPException(422, 'Format tenggat tidak valid.')
            due = d.isoformat()
        tid, ts = _new_id(), now()
        run_sql('INSERT INTO lg34_tasks(id,project_id,title,agent_id,priority,status,due_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)',
                (tid, pid, data.title.strip(), _agent_id(data.agent_id), data.priority, 'open', due, ts, ts))
        audit(role, 'v34.task.create', f'{pid}; {data.title[:80]}')
        return one('SELECT * FROM lg34_tasks WHERE id=?', (tid,))

    @app.patch('/api/v13/tasks/{tid}')
    def v13_task_patch(tid: str, data: TaskPatch34In, role=Depends(require_operator)):
        t = one('SELECT * FROM lg34_tasks WHERE id=?', (tid,))
        if not t:
            raise HTTPException(404, 'Tugas tidak ditemukan.')
        status = data.status if data.status is not None else t['status']
        if status not in TASK_STATES:
            raise HTTPException(422, 'Status harus salah satu dari: ' + ', '.join(TASK_STATES))
        score = t['score']
        if 'score' in getattr(data, 'model_fields_set', getattr(data, '__fields_set__', {'score'})):
            score = data.score
        if score is not None and not 1 <= int(score) <= 5:
            raise HTTPException(422, 'Skor harus 1 sampai 5.')
        run_sql('UPDATE lg34_tasks SET status=?,score=?,updated_at=? WHERE id=?', (status, score, now(), tid))
        audit(role, 'v34.task.update', f'{tid}; {status}; score={score}')
        return one('SELECT * FROM lg34_tasks WHERE id=?', (tid,))

    def agent_stats(project_id=None):
        w, p = ('WHERE project_id=?', (project_id,)) if project_id else ('', ())
        data = {}
        for r in rows(f'SELECT agent_id, status, score FROM lg34_tasks {w}', p):
            d = data.setdefault(r['agent_id'], {'assigned': 0, 'completed': 0, 'scores': []})
            d['assigned'] += 1
            d['completed'] += 1 if r['status'] == 'completed' else 0
            if r['score'] is not None:
                d['scores'].append(int(r['score']))
        return data

    @app.get('/api/v13/analytics/agents')
    def v13_analytics(limit: int = 50, role=Depends(auth)):
        items = []
        for aid, d in agent_stats().items():
            a = AGENT_BY_ID.get(aid, {'name': aid})
            items.append({'agent_id': aid, 'name': a['name'], 'assigned': d['assigned'], 'completed': d['completed'],
                          'average_score': round(sum(d['scores']) / len(d['scores']), 2) if d['scores'] else None})
        items.sort(key=lambda x: (x['average_score'] is None, -(x['average_score'] or 0), -x['completed']))
        return {'items': items[:max(1, min(100, int(limit)))]}

    @app.get('/api/v13/approvals')
    def v13_approvals(role=Depends(auth)):
        return {'items': rows('SELECT id,title,details,status,decided_by,decision_note,created_at,decided_at FROM lg34_approvals ORDER BY created_at DESC LIMIT 200')}

    @app.post('/api/v13/approvals/{aid}')
    def v13_decide(aid: str, data: Decision34In, role=Depends(require_operator)):
        if data.decision not in ('approved', 'rejected'):
            raise HTTPException(422, 'Keputusan harus approved atau rejected.')
        a = one('SELECT id,status FROM lg34_approvals WHERE id=?', (aid,))
        if not a:
            raise HTTPException(404, 'Approval tidak ditemukan.')
        if a['status'] != 'pending':
            raise HTTPException(409, f'Approval sudah {a["status"]}.')
        run_sql("UPDATE lg34_approvals SET status=?,decided_by=?,decision_note=?,decided_at=? WHERE id=? AND status='pending'",
                (data.decision, role, data.note, now(), aid))
        audit(role, 'v34.approval.' + data.decision, aid)
        return one('SELECT id,title,details,status,decided_by,decision_note,created_at,decided_at FROM lg34_approvals WHERE id=?', (aid,))

    @app.get('/api/v13/schedules')
    def v13_schedules(role=Depends(auth)):
        return {'items': rows('SELECT * FROM lg34_schedules ORDER BY due_at ASC LIMIT 200')}

    @app.post('/api/v13/schedules')
    def v13_schedule_create(data: ScheduleIn34, role=Depends(require_operator)):
        project_or_404(data.project_id)
        d = _parse_dt(data.due_at)
        if not d:
            raise HTTPException(422, 'Format due_at tidak valid.')
        sid = _new_id()
        run_sql('INSERT INTO lg34_schedules(id,project_id,title,due_at,status,created_at) VALUES(?,?,?,?,?,?)',
                (sid, data.project_id, data.title.strip(), d.isoformat(), 'scheduled', now()))
        audit(role, 'v34.schedule.create', f'{sid}; {data.title[:80]}')
        return one('SELECT * FROM lg34_schedules WHERE id=?', (sid,))

    @app.post('/api/v13/scheduler/tick')
    def v13_tick(role=Depends(require_operator)):
        """Jadwal yang jatuh tempo diubah menjadi permintaan approval (tidak ada eksekusi otomatis)."""
        promoted = 0
        nowdt = datetime.now(timezone.utc)
        for s in rows("SELECT * FROM lg34_schedules WHERE status='scheduled'"):
            d = _parse_dt(s['due_at'])
            if d and d <= nowdt:
                with conn() as c:
                    cur = c.execute("UPDATE lg34_schedules SET status='promoted' WHERE id=? AND status='scheduled'", (s['id'],))
                    if cur.rowcount:
                        c.execute('INSERT INTO lg34_approvals(id,title,details,status,payload,created_at) VALUES(?,?,?,?,?,?)',
                                  (_new_id(), f'Jadwal jatuh tempo: {s["title"]}', f'Jadwal {s["id"]} pada {s["due_at"]} membutuhkan keputusan.',
                                   'pending', json.dumps({'schedule_id': s['id'], 'project_id': s['project_id']}), now()))
                        promoted += 1
        if promoted:
            audit(role, 'v34.scheduler.tick', f'promoted={promoted}')
        return {'promoted': promoted}

    @app.get('/api/v13/audit')
    def v13_audit(role=Depends(auth)):
        return {'items': rows('SELECT role AS actor_role, action, detail, created_at FROM audit ORDER BY id DESC LIMIT 100')}

    @app.get('/api/v13/backup')
    def v13_backup(role=Depends(require_admin)):
        tables = {t: rows(f'SELECT {",".join(cols)} FROM {t}') for t, cols in BACKUP_TABLES.items()}
        audit(role, 'v34.backup', ', '.join(f'{t}={len(r)}' for t, r in tables.items()))
        return {'format': BACKUP_FORMAT, 'version': 1, 'created_at': now(), 'tables': tables}

    @app.post('/api/v13/restore')
    async def v13_restore(request: Request, role=Depends(require_admin)):
        raw = await body_bytes(request, UPLOAD_MAX_BYTES)
        try:
            data = json.loads(raw.decode('utf-8'))
        except ValueError:
            raise HTTPException(400, 'Isi backup bukan JSON yang valid.')
        if not isinstance(data, dict) or data.get('format') != BACKUP_FORMAT or not isinstance(data.get('tables'), dict):
            raise HTTPException(422, 'Format backup tidak dikenali (butuh backup Tahap 34: format nck-v34-backup).')
        tabs = data['tables']
        if set(tabs) - set(BACKUP_TABLES):
            raise HTTPException(422, 'Backup memuat tabel yang tidak dikenal: ' + ', '.join(sorted(set(tabs) - set(BACKUP_TABLES))))
        total = 0
        for t in tabs.values():
            if not isinstance(t, list) or any(not isinstance(r, dict) for r in t):
                raise HTTPException(422, 'Struktur tabel pada backup tidak valid.')
            total += len(t)
        if total > MAX_BACKUP_ROWS:
            raise HTTPException(422, f'Backup melebihi {MAX_BACKUP_ROWS} baris.')
        counts = {}
        with conn() as c:      # satu transaksi: gagal = tidak ada yang berubah
            for t in ('lg34_run_events', 'lg34_feedback', 'lg34_runs', 'lg34_schedules', 'lg34_approvals', 'lg34_tasks',
                      'lg34_project_memory', 'lg34_projects', 'lg34_documents', 'lg34_knowledge'):
                c.execute(f'DELETE FROM {t}')
            for t, cols in BACKUP_TABLES.items():
                for r in tabs.get(t, []):
                    missing = [k for k in cols if k not in r and k not in OPTIONAL_COLS]
                    if missing:
                        raise HTTPException(422, f'Baris pada {t} kehilangan kolom: {missing[:3]}')
                    c.execute(f'INSERT INTO {t}({",".join(cols)}) VALUES({",".join("?" * len(cols))})', tuple(r.get(k) for k in cols))
                counts[t] = len(tabs.get(t, []))
        audit(role, 'v34.restore', json.dumps(counts))
        return {'restored': counts}

    # ================================================================ Tahap 14: eksekusi proyek dengan approval
    @app.post('/api/v14/prepare-run')
    def v14_prepare(data: Prepare34In, role=Depends(require_operator)):
        p = project_or_404(data.project_id)
        if data.mode not in ('sequential', 'parallel'):
            raise HTTPException(422, 'Mode harus sequential atau parallel.')
        provider = _provider(data.provider)
        ids = list(dict.fromkeys(data.task_ids))
        tasks = []
        for tid in ids:
            t = one('SELECT * FROM lg34_tasks WHERE id=? AND project_id=?', (tid, data.project_id))
            if not t:
                raise HTTPException(404, f'Tugas {tid} tidak ditemukan pada proyek ini.')
            if t['status'] not in ('open', 'blocked'):
                raise HTTPException(409, f'Tugas "{t["title"]}" berstatus {t["status"]}; hanya open/blocked yang dapat dijalankan.')
            tasks.append(t)
        aid = _new_id()
        goal = data.goal.strip() or f'Selesaikan tugas proyek {p["name"]}'
        details = f'Proyek: {p["name"]}\nTujuan: {goal}\nProvider: {provider}; mode: {data.mode}\nTugas:\n' + '\n'.join(f'- {t["title"]} (agen {t["agent_id"]})' for t in tasks)
        run_sql('INSERT INTO lg34_approvals(id,title,details,status,payload,created_at) VALUES(?,?,?,?,?,?)',
                (aid, f'[TAHAP14] Eksekusi {len(tasks)} tugas — {p["name"]}'[:200], details, 'pending',
                 json.dumps({'project_id': data.project_id, 'task_ids': ids, 'goal': goal, 'provider': provider, 'mode': data.mode}), now()))
        audit(role, 'v34.v14.prepare', f'{aid}; tasks={len(tasks)}')
        return {'approval_id': aid, 'status': 'pending'}

    @app.post('/api/v14/launch-approved')
    async def v14_launch(data: Launch34In, background_tasks: BackgroundTasks, role=Depends(require_operator)):
        a = one('SELECT * FROM lg34_approvals WHERE id=?', (data.approval_id,))
        if not a or not a['title'].startswith('[TAHAP14]'):
            raise HTTPException(404, 'Approval Tahap 14 tidak ditemukan.')
        if a['status'] != 'approved':
            raise HTTPException(409, f'Approval berstatus {a["status"]}; harus approved sebelum dijalankan.')
        if one('SELECT id FROM lg34_runs WHERE approval_id=?', (a['id'],)):
            raise HTTPException(409, 'Approval ini sudah pernah dijalankan.')
        pl = json.loads(a['payload'])
        tasks, prev = [], None
        for tid in pl['task_ids']:
            t = one('SELECT * FROM lg34_tasks WHERE id=?', (tid,))
            if not t:
                raise HTTPException(409, f'Tugas {tid} sudah tidak ada.')
            item = {'id': t['id'], 'title': t['title'], 'agent_id': _agent_id(t['agent_id']), 'depends_on': [prev] if (pl['mode'] == 'sequential' and prev) else [],
                    'instruction': f'Kerjakan tugas proyek berikut dan berikan hasil yang konkret.\nTugas: {t["title"]}\nTujuan: {pl["goal"]}'}
            tasks.append(item)
            prev = t['id']
        import nck_db
        try:
            rid = new_run('v14', pl['goal'], pl['provider'], None, {'mode': pl['mode']}, approval_id=a['id'], project_id=pl['project_id'])
        except nck_db.INTEGRITY_ERRORS:
            raise HTTPException(409, 'Approval ini sudah pernah dijalankan.')
        for t in tasks:
            run_sql("UPDATE lg34_tasks SET status='in_progress',updated_at=? WHERE id=?", (now(), t['id']))
        add_event(rid, 'run.started', message=f'{len(tasks)} tugas')
        background_tasks.add_task(v14_job, rid, pl['goal'], tasks, pl['provider'], 1 if pl['mode'] == 'sequential' else 3)
        audit(role, 'v34.v14.launch', f'{rid}; approval={a["id"]}')
        return {'run_id': rid, 'status': 'running'}

    @app.get('/api/v14/runs')
    def v14_runs(role=Depends(auth)):
        reap_stale()
        return {'items': [{'run_id': r['id'], 'goal': r['goal'], 'status': r['status'], 'approval_id': r['approval_id'],
                           'project_id': r['project_id'], 'created_at': r['created_at'], 'synced': bool(r['synced'])}
                          for r in rows("SELECT * FROM lg34_runs WHERE kind='v14' ORDER BY created_at DESC LIMIT 100")]}

    @app.post('/api/v14/runs/{rid}/sync')
    def v14_sync(rid: str, role=Depends(require_operator)):
        reap_stale()
        r = one("SELECT * FROM lg34_runs WHERE id=? AND kind='v14'", (rid,))
        if not r:
            raise HTTPException(404, 'Run tidak ditemukan.')
        if r['status'] in ('running', 'queued'):
            return {'status': r['status'], 'synced': False, 'message': 'Belum selesai.'}
        if r['synced']:
            return {'status': r['status'], 'synced': True, 'message': 'Sudah disinkronkan sebelumnya.'}
        results = json.loads(r['results'] or '[]')
        with conn() as c:
            for x in results:
                if x['status'] == 'completed':
                    c.execute("UPDATE lg34_tasks SET status='completed',result=?,updated_at=? WHERE id=?", (x['result'], now(), x['id']))
                else:
                    c.execute("UPDATE lg34_tasks SET status='blocked',result=?,updated_at=? WHERE id=?", (x.get('error', ''), now(), x['id']))
            c.execute('UPDATE lg34_runs SET synced=1,updated_at=? WHERE id=?', (now(), rid))
        audit(role, 'v34.v14.sync', rid)
        final = '\n\n'.join(f'[{x["status"].upper()}] {x["agent"]} — {x["title"]}\n{x.get("result") or x.get("error", "")}' for x in results)
        return {'status': r['status'], 'synced': True, 'final': final, 'quality_review': json.loads(r['quality_review'] or '{}')}

    # ================================================================ Tahap 15: pembelajaran & routing
    def confidence(rated):
        return 'tinggi' if rated >= 10 else ('sedang' if rated >= 3 else 'rendah')

    @app.get('/api/v15/learning/overview')
    def v15_overview(role=Depends(auth)):
        stats = agent_stats()
        ts = task_stats()
        agents, recs = [], []
        for aid, d in sorted(stats.items(), key=lambda kv: (-len(kv[1]['scores']), kv[0])):
            a = AGENT_BY_ID.get(aid, {'name': aid, 'role': ''})
            avg = round(sum(d['scores']) / len(d['scores']), 2) if d['scores'] else None
            sig = 'data belum cukup' if len(d['scores']) < 3 else ('kuat' if avg >= 4 else ('stabil' if avg >= 3 else 'perlu perbaikan'))
            agents.append({'agent_id': aid, 'name': a['name'], 'role': a['role'], 'assigned': d['assigned'], 'completed': d['completed'],
                           'average_rating': avg, 'confidence': confidence(len(d['scores'])), 'signal': sig})
            if sig == 'perlu perbaikan':
                recs.append({'title': f'Tinjau penugasan {a["name"]}', 'detail': f'Rata-rata rating {avg}/5 dari {len(d["scores"])} penilaian. Periksa kecocokan instruksi dan jenis tugas.'})
        unrated = one("SELECT COUNT(*) AS n FROM lg34_tasks WHERE status='completed' AND score IS NULL")['n']
        if unrated:
            recs.append({'title': 'Beri rating pada tugas selesai', 'detail': f'{unrated} tugas selesai belum dinilai; rating dibutuhkan agar rekomendasi routing akurat.'})
        if not stats:
            recs.append({'title': 'Belum ada data', 'detail': 'Buat tugas di Command Center, jalankan, lalu beri rating.'})
        return {'summary': {'agent_count': len(AGENTS_DIRECTORY), 'task_count': one('SELECT COUNT(*) AS n FROM lg34_tasks')['n'],
                            'rated_count': ts['rated_tasks'], 'average_rating': ts['average_score']},
                'agents': agents, 'recommendations': recs,
                'note': 'Statistik dihitung dari tugas dan rating manual yang tersimpan; bukan pelatihan model.'}

    @app.get('/api/v15/feedback/tasks')
    def v15_feedback_tasks(role=Depends(auth)):
        return {'items': [{'id': r['id'], 'title': r['title'], 'agent_id': r['agent_id'], 'agent_name': AGENT_BY_ID.get(r['agent_id'], {'name': r['agent_id']})['name'],
                           'score': r['score']}
                          for r in rows("SELECT id,title,agent_id,score FROM lg34_tasks WHERE status='completed' ORDER BY updated_at DESC LIMIT 200")]}

    @app.post('/api/v15/feedback')
    def v15_feedback(data: Feedback34In, role=Depends(require_operator)):
        if not 1 <= int(data.rating) <= 5:
            raise HTTPException(422, 'Rating harus 1 sampai 5.')
        t = one('SELECT id,agent_id,status FROM lg34_tasks WHERE id=?', (data.task_id,))
        if not t:
            raise HTTPException(404, 'Tugas tidak ditemukan.')
        if t['status'] != 'completed':
            raise HTTPException(409, 'Hanya tugas berstatus completed yang dapat dinilai.')
        with conn() as c:
            c.execute('UPDATE lg34_tasks SET score=?,updated_at=? WHERE id=?', (int(data.rating), now(), t['id']))
            c.execute('INSERT INTO lg34_feedback(task_id,agent_id,rating,notes,created_at) VALUES(?,?,?,?,?)',
                      (t['id'], t['agent_id'], int(data.rating), data.notes, now()))
        audit(role, 'v34.feedback', f'{t["id"]}; rating={data.rating}')
        return {'task_id': t['id'], 'agent_id': t['agent_id'], 'rating': int(data.rating)}

    @app.post('/api/v15/route')
    def v15_route(data: Route34In, role=Depends(auth)):
        if data.project_id:
            project_or_404(data.project_id)
        stats = agent_stats(data.project_id or None)
        gt = set(_tok(data.goal))
        out = []
        for a in AGENTS_DIRECTORY:
            at = set(_tok(' '.join([a['name'], a['role'], a['description'], a['division']])))
            ov = len(gt & at)
            skill = min(100, ov * 25)
            d = stats.get(a['id'], {'assigned': 0, 'completed': 0, 'scores': []})
            avg = sum(d['scores']) / len(d['scores']) if d['scores'] else None
            rating_c = (avg / 5 * 100) if avg is not None else 50.0
            exp_c = min(d['completed'], 10) / 10 * 100
            score = round(0.6 * skill + 0.3 * rating_c + 0.1 * exp_c, 1)
            out.append({'agent_id': a['id'], 'name': a['name'], 'role': a['role'], 'score': score, 'skill_match': skill,
                        'confidence': confidence(len(d['scores'])), 'completed': d['completed'], 'assigned': d['assigned'],
                        'reason': (f'{ov} kata kunci cocok dengan keahlian; ' if ov else 'tidak ada kata kunci yang cocok; ') +
                                  (f'rata-rata rating {round(avg, 2)}/5' if avg is not None else 'belum ada rating (nilai netral 50)')})
        out.sort(key=lambda x: (-x['score'], x['agent_id']))
        return {'recommendations': out[:max(1, min(10, int(data.limit)))],
                'method': 'skor = 60% kecocokan kata kunci + 30% rating historis + 10% pengalaman (aturan lokal, bukan AI)'}

    return {'version': VERSION, 'init': init_v34}
