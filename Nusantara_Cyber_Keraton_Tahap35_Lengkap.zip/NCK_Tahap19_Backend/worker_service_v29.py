"""NCK Tahap 29 Redis Streams dispatch worker.
Requires an executor adapter URL that accepts POST /execute with task_id, executor,
payload, dispatch_id. The adapter must implement idempotency and authoritative DB
state transitions. This generic consumer deliberately does not import the API's
SQLite engine, so it cannot accidentally pretend to be a PostgreSQL worker.
"""
import json, os, socket, time, uuid
import httpx, redis
REDIS_URL=os.environ['NCK_REDIS_URL']; STREAM=os.getenv('NCK_V29_REDIS_STREAM','nck:v29:task-dispatch')
GROUP=os.getenv('NCK_V29_REDIS_GROUP','nck-workers-v29'); CONSUMER=os.getenv('NCK_WORKER_ID',socket.gethostname()+'-'+uuid.uuid4().hex[:6])
EXECUTOR=os.environ['NCK_V29_EXECUTOR_URL'].rstrip('/')
TOKEN=os.environ['NCK_V29_EXECUTOR_TOKEN']; BLOCK=int(os.getenv('NCK_V29_BLOCK_MS','5000'))
r=redis.Redis.from_url(REDIS_URL,decode_responses=True,socket_timeout=15)
try:r.xgroup_create(STREAM,GROUP,id='0',mkstream=True)
except redis.exceptions.ResponseError as e:
 if 'BUSYGROUP' not in str(e): raise
print(f'NCK worker {CONSUMER} listening on {STREAM}/{GROUP}')
while True:
 try:
  batches=r.xreadgroup(GROUP,CONSUMER,{STREAM:'>'},count=1,block=BLOCK)
  if not batches: continue
  for _,messages in batches:
   for mid,msg in messages:
    try:
     body={'task_id':int(msg['task_id']),'executor':msg.get('executor','default'),
       'payload':json.loads(msg.get('payload','{}')),'dispatch_id':msg.get('dispatch_id',mid)}
     with httpx.Client(timeout=180,headers={'Authorization':'Bearer '+TOKEN}) as client:
      res=client.post(EXECUTOR+'/execute',json=body); res.raise_for_status()
     r.xack(STREAM,GROUP,mid)
     r.xadd('nck:v29:worker-events',{'event':'completed','message_id':mid,'consumer':CONSUMER,'result':res.text[:3000]})
    except Exception as exc:
     # Leave pending for explicit reclaim/retry; record failure for observability.
     r.xadd('nck:v29:worker-events',{'event':'failed','message_id':mid,'consumer':CONSUMER,'error':str(exc)[:1000]})
     print('dispatch failed',mid,str(exc)[:300],flush=True)
 except Exception as exc:
  print('worker loop error',str(exc)[:300],flush=True); time.sleep(3)
