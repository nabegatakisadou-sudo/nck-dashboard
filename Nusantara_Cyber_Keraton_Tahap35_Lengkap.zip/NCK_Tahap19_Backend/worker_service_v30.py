"""NCK Stage 30 Redis Streams worker hardening.
Calls only an explicitly configured executor adapter. The adapter must enforce
idempotency using dispatch_id before performing side effects. Messages are ACKed
only after a successful 2xx response; failures are retried by stale-claim recovery.
"""
import json, os, socket, time, uuid
import httpx, redis
REDIS_URL=os.environ['NCK_REDIS_URL']; STREAM=os.getenv('NCK_V29_REDIS_STREAM','nck:v29:task-dispatch')
GROUP=os.getenv('NCK_V29_REDIS_GROUP','nck-workers-v29'); CONSUMER=os.getenv('NCK_WORKER_ID',socket.gethostname()+'-'+uuid.uuid4().hex[:6])
EXECUTOR=os.environ['NCK_V29_EXECUTOR_URL'].rstrip('/'); TOKEN=os.environ['NCK_V29_EXECUTOR_TOKEN']
BLOCK=int(os.getenv('NCK_V30_BLOCK_MS','5000')); CLAIM_IDLE=int(os.getenv('NCK_V30_CLAIM_IDLE_MS','60000'))
MAX_DELIVERIES=int(os.getenv('NCK_V30_MAX_DELIVERIES','8')); DLQ=os.getenv('NCK_V30_DLQ_STREAM','nck:v30:dead-letter')
r=redis.Redis.from_url(REDIS_URL,decode_responses=True,socket_timeout=15)
try:r.xgroup_create(STREAM,GROUP,id='0',mkstream=True)
except redis.exceptions.ResponseError as e:
 if 'BUSYGROUP' not in str(e): raise

def handle(mid,msg):
    deliveries=int(msg.get('_deliveries','1'))
    try:
        body={'task_id':int(msg['task_id']),'executor':msg.get('executor','default'),
          'payload':json.loads(msg.get('payload','{}')),'dispatch_id':msg.get('dispatch_id',mid)}
        with httpx.Client(timeout=httpx.Timeout(240),headers={'Authorization':'Bearer '+TOKEN,'Idempotency-Key':body['dispatch_id']}) as client:
            response=client.post(EXECUTOR+'/execute',json=body); response.raise_for_status()
        r.xack(STREAM,GROUP,mid)
        r.xadd('nck:v30:worker-events',{'event':'completed','message_id':mid,'consumer':CONSUMER,'dispatch_id':body['dispatch_id'],'at':str(time.time())})
    except Exception as exc:
        if deliveries>=MAX_DELIVERIES:
            r.xadd(DLQ,{'original_stream':STREAM,'original_id':mid,'payload':json.dumps(msg)[:12000],'error':str(exc)[:1000],'consumer':CONSUMER,'at':str(time.time())})
            r.xack(STREAM,GROUP,mid)
            r.xadd('nck:v30:worker-events',{'event':'dead_lettered','message_id':mid,'consumer':CONSUMER,'error':str(exc)[:500]})
        else:
            # Keep pending; XAUTOCLAIM will redeliver after CLAIM_IDLE.
            r.xadd('nck:v30:worker-events',{'event':'retry_pending','message_id':mid,'consumer':CONSUMER,'delivery':str(deliveries),'error':str(exc)[:500]})

print(f'NCK Stage30 worker {CONSUMER} listening on {STREAM}/{GROUP}',flush=True)
while True:
 try:
    # Recover messages abandoned by crashed consumers.
    cursor='0-0'
    claimed=r.xautoclaim(STREAM,GROUP,CONSUMER,min_idle_time=CLAIM_IDLE,start_id=cursor,count=10)
    for mid,msg in claimed[1]:
        # Redis delivery count is authoritative where available.
        try:
            pending=r.xpending_range(STREAM,GROUP,min=mid,max=mid,count=1)
            msg['_deliveries']=str((pending[0].get('times_delivered',1) if pending else 1))
        except Exception: msg['_deliveries']='1'
        handle(mid,msg)
    batches=r.xreadgroup(GROUP,CONSUMER,{STREAM:'>'},count=5,block=BLOCK)
    for _,messages in batches:
        for mid,msg in messages:
            msg['_deliveries']='1'; handle(mid,msg)
 except Exception as exc:
    print('worker loop error',str(exc)[:300],flush=True); time.sleep(3)
