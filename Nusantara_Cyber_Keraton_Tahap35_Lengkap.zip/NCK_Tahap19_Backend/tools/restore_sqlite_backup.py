#!/usr/bin/env python3
"""Safely restore a SQLite backup after integrity validation.
Stop the API/workers before running. A pre-restore copy is created by default.
"""
import argparse, os, shutil, sqlite3, tempfile
from datetime import datetime, timezone
from pathlib import Path

def check(path):
    c=sqlite3.connect(f'file:{Path(path).resolve()}?mode=ro',uri=True)
    try:
        result=c.execute('PRAGMA integrity_check').fetchone()[0]
        quick=c.execute('PRAGMA quick_check').fetchone()[0]
        if result!='ok' or quick!='ok': raise SystemExit(f'Backup invalid: integrity={result}; quick={quick}')
    finally:c.close()

def main():
    p=argparse.ArgumentParser(); p.add_argument('--backup',required=True); p.add_argument('--target',required=True); p.add_argument('--dry-run',action='store_true'); p.add_argument('--no-safety-copy',action='store_true'); a=p.parse_args()
    src=Path(a.backup).resolve(); dst=Path(a.target).resolve()
    if not src.is_file(): raise SystemExit('Backup file tidak ditemukan.')
    check(src)
    print(f'Backup valid: {src} ({src.stat().st_size} bytes)')
    if a.dry_run: print('DRY RUN: tidak ada file yang diubah.'); return
    dst.parent.mkdir(parents=True,exist_ok=True)
    if dst.exists() and not a.no_safety_copy:
        stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        safety=dst.with_name(dst.name+f'.pre-restore-{stamp}.bak')
        shutil.copy2(dst,safety); print('Safety copy:',safety)
    fd,tmp=tempfile.mkstemp(prefix=dst.name+'.restore-',dir=str(dst.parent)); os.close(fd)
    try:
        shutil.copy2(src,tmp); check(tmp); os.replace(tmp,dst)
    finally:
        if os.path.exists(tmp): os.remove(tmp)
    print('Restore berhasil. Jalankan kembali service setelah verifikasi aplikasi.')
if __name__=='__main__': main()
