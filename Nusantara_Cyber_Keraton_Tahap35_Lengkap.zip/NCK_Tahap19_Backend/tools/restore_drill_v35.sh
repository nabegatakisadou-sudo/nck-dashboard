#!/usr/bin/env bash
# Tahap 35 - LATIHAN RESTORE: memulihkan backup ke database sementara dan membuktikan isinya sama.
# Langkah: cek sha256 berkas -> dekripsi (sandi salah = gagal) -> cek sha256 isi -> siapkan server sementara ->
#          pg_restore (galat apa pun = gagal) -> hitung baris setiap tabel -> bandingkan dengan meta.
# Env wajib : NCK_DRILL_IN              folder berisi nck_backup_*.dump(.enc) + backup_meta.json (keluaran pg_backup_v35.sh)
#             salah satu dari:
#             NCK_DRILL_START_DOCKER=1  skrip menyalakan postgres:<mayor> sementara lewat docker (port NCK_DRILL_PORT, default 55432)
#             NCK_DRILL_DSN             DSN URI admin server sementara (boleh membuat/menghapus database)
# Env opsi  : NCK_BACKUP_PASSPHRASE (wajib bila backup terenkripsi), NCK_DRILL_DB (default nck_drill),
#             NCK_DRILL_RESULT (path JSON hasil), NCK_PG_TOOLS / NCK_PG_BIN_ROOT (lihat pgtools_v35.sh)
# Aturan banding: jumlah baris hasil restore harus berada di antara hitungan SEBELUM dan SESUDAH dump tiap tabel
#                 (tabel boleh berubah saat dump berjalan), dan himpunan tabel harus sama persis.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
# shellcheck source=pgtools_v35.sh
source "$HERE/pgtools_v35.sh"
fail() { echo "GAGAL: $*" >&2; exit 1; }
: "${NCK_DRILL_IN:?NCK_DRILL_IN wajib (folder backup)}"
IN="$(cd "$NCK_DRILL_IN" && pwd)"; META="$IN/backup_meta.json"
[ -f "$META" ] || fail "backup_meta.json tidak ada di $IN"
DB="${NCK_DRILL_DB:-nck_drill}"; [[ "$DB" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] || fail "NCK_DRILL_DB tidak valid"
sha() { sha256sum "$1" | cut -d' ' -f1; }

eval "$(META="$META" python3 - <<'PYEOF'
import json, os, shlex
m = json.load(open(os.environ['META']))
for k_env, k in (('M_FILE', 'file'), ('M_SHA', 'sha256'), ('M_PLAIN', 'plain_sha256'), ('M_ENC', 'encrypted'), ('M_MAJOR', 'server_major'), ('M_SCHEMA', 'schema')):
    print('%s=%s' % (k_env, shlex.quote(str(m[k]))))
PYEOF
)"
[[ "$M_SCHEMA" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] || fail "skema di meta tidak valid"
[ -f "$IN/$M_FILE" ] || fail "berkas backup $M_FILE tidak ada"
[ "$(sha "$IN/$M_FILE")" = "$M_SHA" ] || fail "sha256 berkas backup TIDAK cocok dengan meta (berkas rusak atau diubah)."
echo "sha256 berkas cocok dengan meta"

TMP="$(mktemp -d)"; CONTAINER=""
cleanup() {
  rm -rf "$TMP"
  if [ -n "$CONTAINER" ]; then docker rm -f "$CONTAINER" >/dev/null 2>&1 || true; fi
}
trap cleanup EXIT

PLAIN="$TMP/plain.dump"
if [ "$M_ENC" = "True" ] || [ "$M_ENC" = "true" ]; then
  [ -n "${NCK_BACKUP_PASSPHRASE:-}" ] || fail "backup terenkripsi tetapi NCK_BACKUP_PASSPHRASE kosong."
  openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 -in "$IN/$M_FILE" -out "$PLAIN" -pass env:NCK_BACKUP_PASSPHRASE 2>/dev/null \
    || fail "dekripsi gagal (sandi salah atau berkas rusak)."
else
  cp "$IN/$M_FILE" "$PLAIN"
fi
[ "$(sha "$PLAIN")" = "$M_PLAIN" ] || fail "sha256 isi setelah dekripsi TIDAK cocok (sandi salah atau data rusak)."
echo "dekripsi/isi cocok dengan sha256 asli"

# ---- server sementara
if [ "${NCK_DRILL_START_DOCKER:-0}" = "1" ]; then
  command -v docker >/dev/null 2>&1 || fail "NCK_DRILL_START_DOCKER=1 tetapi docker tidak tersedia."
  PORT="${NCK_DRILL_PORT:-55432}"; CONTAINER="nck-drill-$$"
  docker run -d --name "$CONTAINER" -e POSTGRES_PASSWORD=drill -p "127.0.0.1:$PORT:5432" "postgres:$M_MAJOR" >/dev/null || fail "gagal menyalakan postgres:$M_MAJOR"
  ok=0
  for _ in $(seq 1 60); do
    if docker exec "$CONTAINER" pg_isready -U postgres -h 127.0.0.1 >/dev/null 2>&1; then ok=1; break; fi
    sleep 1
  done
  [ "$ok" = 1 ] || fail "server sementara tidak siap dalam 60 detik."
  sleep 2   # image resmi sempat restart sekali setelah inisialisasi
  for _ in $(seq 1 30); do docker exec "$CONTAINER" pg_isready -U postgres -h 127.0.0.1 >/dev/null 2>&1 && break; sleep 1; done
  NCK_DRILL_DSN="postgresql://postgres:drill@127.0.0.1:$PORT/postgres"
  echo "server sementara: postgres:$M_MAJOR di 127.0.0.1:$PORT"
fi
: "${NCK_DRILL_DSN:?NCK_DRILL_DSN wajib bila NCK_DRILL_START_DOCKER bukan 1}"
RDSN="$(python3 "$HERE/dsn_with_db_v35.py" "$NCK_DRILL_DSN" "$DB")"

mv "$PLAIN" "$TMP/restore.dump"
pgt_init "$NCK_DRILL_DSN" "$TMP" || exit 1
echo "server sementara mayor=$PGT_MAJOR (backup mayor=$M_MAJOR); alat restore: mode=$PGT_MODE ${PGT_BIN}${PGT_IMAGE}"
[ "$PGT_MAJOR" -ge "$M_MAJOR" ] || fail "server sementara (PG $PGT_MAJOR) lebih LAMA dari asal backup (PG $M_MAJOR)."
psql "$NCK_DRILL_DSN" -qAt -c "DROP DATABASE IF EXISTS $DB" -c "CREATE DATABASE $DB TEMPLATE template0" >/dev/null || fail "gagal menyiapkan database sementara."
# pg_dump skema "public" ikut menulis CREATE SCHEMA public; database baru sudah punya skema itu -> kosongkan dulu.
if [ "$M_SCHEMA" = public ]; then psql "$RDSN" -qAt -c "DROP SCHEMA IF EXISTS public CASCADE" >/dev/null || fail "gagal mengosongkan skema public bawaan."; fi
pgt_restore "$RDSN" restore.dump || fail "pg_restore gagal (lihat galat di atas)."
echo "pg_restore selesai tanpa galat"

pgt_counts "$RDSN" "$M_SCHEMA" > "$TMP/restored.txt" || fail "gagal menghitung baris hasil restore."
RESULT="${NCK_DRILL_RESULT:-$TMP/result.json}"
META="$META" RESTORED="$TMP/restored.txt" RESULT="$RESULT" python3 - <<'PYEOF' || { psql "$NCK_DRILL_DSN" -qAt -c "DROP DATABASE IF EXISTS $DB" >/dev/null 2>&1 || true; exit 1; }
import json, os, sys
m = json.load(open(os.environ['META']))
r = {}
for ln in open(os.environ['RESTORED'], encoding='utf-8'):
    ln = ln.strip()
    if ln:
        k, v = ln.rsplit('|', 1)
        r[k] = int(v)
problems = []
missing = sorted(set(m['tables']) - set(r))
extra = sorted(set(r) - set(m['tables']))
if missing:
    problems.append('tabel hilang setelah restore: ' + ', '.join(missing))
if extra:
    problems.append('tabel tak terduga setelah restore: ' + ', '.join(extra))
for t, c in m['tables'].items():
    if t in r:
        lo, hi = min(c['before'], c['after']), max(c['before'], c['after'])
        if not (lo <= r[t] <= hi):
            problems.append('%s: hasil restore=%d, sumber sebelum=%d sesudah=%d' % (t, r[t], c['before'], c['after']))
res = {'ok': not problems, 'tables': len(m['tables']), 'rows_restored': sum(r.values()), 'rows_source_before': m['total_rows_before'], 'problems': problems}
json.dump(res, open(os.environ['RESULT'], 'w'), indent=1)
if problems:
    print('PERBEDAAN:\n  ' + '\n  '.join(problems), file=sys.stderr)
    sys.exit(1)
print('semua %d tabel cocok; %d baris dipulihkan (sumber saat dump: %d)' % (res['tables'], res['rows_restored'], res['rows_source_before']))
PYEOF
psql "$NCK_DRILL_DSN" -qAt -c "DROP DATABASE IF EXISTS $DB" >/dev/null 2>&1 || true
echo "== LATIHAN RESTORE BERHASIL =="
if [ -n "${GITHUB_OUTPUT:-}" ]; then echo "ok=true" >> "$GITHUB_OUTPUT"; fi
