#!/usr/bin/env python3
"""Controlled SQLite -> PostgreSQL migration toolkit for NCK Stage 32.
Does not delete/alter the SQLite source. Requires psycopg 3.
"""
import argparse, hashlib, json, os, sqlite3, sys, uuid
from datetime import datetime, timezone
from pathlib import Path
import psycopg
from psycopg import sql

INTERNAL={'_nck_migration_runs_v32'}
def qname(s): return '"'+s.replace('"','""')+'"'
def pg_type(decl, pk=False):
    t=(decl or '').upper()
    if pk and 'INT' in t: return 'BIGINT'
    if 'INT' in t: return 'BIGINT'
    if any(x in t for x in ('CHAR','CLOB','TEXT')): return 'TEXT'
    if 'BLOB' in t: return 'BYTEA'
    if any(x in t for x in ('REAL','FLOA','DOUB')): return 'DOUBLE PRECISION'
    if 'BOOL' in t: return 'BOOLEAN'
    if any(x in t for x in ('NUM','DEC')): return 'NUMERIC'
    return 'TEXT'
def inventory(src):
    src.row_factory=sqlite3.Row
    objects=src.execute("SELECT type,name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name").fetchall()
    tables=[]
    for o in objects:
        if o['type']!='table': continue
        name=o['name']; info=src.execute(f'PRAGMA table_info({json.dumps(name)})').fetchall()
        fks=src.execute(f'PRAGMA foreign_key_list({json.dumps(name)})').fetchall()
        indexes=src.execute(f'PRAGMA index_list({json.dumps(name)})').fetchall()
        pks=[r['name'] for r in sorted(info,key=lambda x:x['pk']) if r['pk']]
        tables.append({'name':name,'columns':[dict(x) for x in info],'primary_key':pks,'foreign_keys':[dict(x) for x in fks],
          'indexes':[dict(x) for x in indexes],'rows':src.execute(f'SELECT COUNT(*) FROM {qname(name)}').fetchone()[0]})
    return tables,[{'type':o['type'],'name':o['name'],'sql':o['sql']} for o in objects if o['type']!='table']
def snapshot(source,dest):
    target=sqlite3.connect(dest)
    try: source.backup(target); target.commit()
    finally: target.close()
def main():
    if '--allow-deprecated' not in sys.argv:
        raise SystemExit('DIHENTIKAN (Tahap 33): tool ini memuat tabel anak sebelum induk, tidak membuat kolom id otomatis, '
                         'dan tidak membawa UNIQUE/indeks. Gunakan tools/migrate_sqlite_to_postgres_v33.py. '
                         'Untuk tetap menjalankan tool lama, tambahkan --allow-deprecated (tidak disarankan).')
    sys.argv.remove('--allow-deprecated')
    ap=argparse.ArgumentParser()
    ap.add_argument('--sqlite',default=os.getenv('NCK_DB_PATH','nck_enterprise.db'))
    ap.add_argument('--postgres',default=os.getenv('NCK_POSTGRES_DSN',''))
    ap.add_argument('--schema',default='public')
    ap.add_argument('--dry-run',action='store_true')
    ap.add_argument('--snapshot',action='store_true',help='Create a consistent SQLite backup before migration')
    ap.add_argument('--snapshot-path',default='')
    ap.add_argument('--verify-only',action='store_true')
    ap.add_argument('--replace-target-data',action='store_true',help='Explicitly allow replacing existing rows in target tables')
    ap.add_argument('--batch-size',type=int,default=500)
    a=ap.parse_args()
    if not os.path.isfile(a.sqlite): raise SystemExit('SQLite source not found: '+a.sqlite)
    if not a.postgres: raise SystemExit('PostgreSQL DSN required (--postgres or NCK_POSTGRES_DSN).')
    if not (1<=a.batch_size<=5000): raise SystemExit('batch-size must be 1..5000')
    src=sqlite3.connect(f'file:{Path(a.sqlite).resolve()}?mode=ro',uri=True); src.row_factory=sqlite3.Row
    integrity=src.execute('PRAGMA integrity_check').fetchone()[0]
    fk_issues=[dict(x) for x in src.execute('PRAGMA foreign_key_check').fetchall()]
    if integrity!='ok' or fk_issues: raise SystemExit(json.dumps({'integrity':integrity,'foreign_key_issues':fk_issues[:20]}))
    snapshot_path=None
    if a.snapshot:
        snapshot_path=a.snapshot_path or (a.sqlite+'.pre_stage32_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'.bak')
        snapshot(src,snapshot_path)
    tables,other=inventory(src)
    report={'run_id':str(uuid.uuid4()),'source':str(Path(a.sqlite).resolve()),'schema':a.schema,'dry_run':a.dry_run,'snapshot':snapshot_path,
      'source_integrity':integrity,'source_foreign_key_issues':fk_issues,'tables':[],
      'objects_not_auto_migrated':other,'warnings':['SQLite triggers and views are inventoried but require manual PostgreSQL rewrite.','Partial/expression indexes require manual review.','Application cutover is not performed by this utility.']}
    for t in tables:
        report['tables'].append({'table':t['name'],'columns':len(t['columns']),'rows':t['rows'],'primary_key':t['primary_key'],'foreign_keys':len(t['foreign_keys']),'indexes':len(t['indexes'])})
    if a.dry_run:
        print(json.dumps(report,indent=2,default=str)); src.close(); return
    with psycopg.connect(a.postgres,connect_timeout=8) as dst:
      with dst.transaction():
        with dst.cursor() as cur:
          cur.execute(sql.SQL('CREATE SCHEMA IF NOT EXISTS {}').format(sql.Identifier(a.schema)))
          cur.execute(sql.SQL('CREATE TABLE IF NOT EXISTS {}.{} (run_id TEXT PRIMARY KEY, started_at TIMESTAMPTZ NOT NULL, source_path TEXT NOT NULL, report JSONB NOT NULL)').format(sql.Identifier(a.schema),sql.Identifier('_nck_migration_runs_v32')))
          # Build all table shells first, then add FKs after every table exists.
          for t in tables:
            info=t['columns']; pks=t['primary_key']; defs=[]
            for col in info:
              pk=bool(col['pk']); typ=pg_type(col['type'],pk)
              piece=sql.SQL('{} {}').format(sql.Identifier(col['name']),sql.SQL(typ))
              if col['notnull'] and not pk: piece+=sql.SQL(' NOT NULL')
              dv=col['dflt_value']
              if dv is not None and str(dv).upper() in ('CURRENT_TIMESTAMP','CURRENT_DATE','CURRENT_TIME','NULL'):
                piece+=sql.SQL(' DEFAULT ')+sql.SQL(str(dv))
              elif dv is not None and (str(dv).lstrip('-').isdigit() or (str(dv).startswith("'") and str(dv).endswith("'"))):
                piece+=sql.SQL(' DEFAULT ')+sql.SQL(str(dv))
              defs.append(piece)
            if pks: defs.append(sql.SQL('PRIMARY KEY ({})').format(sql.SQL(',').join(map(sql.Identifier,pks))))
            cur.execute(sql.SQL('CREATE TABLE IF NOT EXISTS {}.{} ({})').format(sql.Identifier(a.schema),sql.Identifier(t['name']),sql.SQL(',').join(defs)))
          for t in tables:
            groups={}
            for fk in t['foreign_keys']: groups.setdefault(fk['id'],[]).append(fk)
            for fid, parts in groups.items():
              parts=sorted(parts,key=lambda x:x['seq']); first=parts[0]; cname=f"fk32_{t['name']}_{fid}"
              cur.execute("SELECT 1 FROM information_schema.table_constraints WHERE constraint_schema=%s AND table_name=%s AND constraint_type='FOREIGN KEY' AND constraint_name=%s",(a.schema,t['name'],cname))
              if cur.fetchone(): continue
              src_cols=sql.SQL(',').join(sql.Identifier(x['from']) for x in parts); dst_cols=sql.SQL(',').join(sql.Identifier(x['to']) for x in parts)
              cur.execute(sql.SQL('ALTER TABLE {}.{} ADD CONSTRAINT {} FOREIGN KEY ({}) REFERENCES {}.{} ({})').format(
                sql.Identifier(a.schema),sql.Identifier(t['name']),sql.Identifier(cname),src_cols,sql.Identifier(a.schema),sql.Identifier(first['table']),dst_cols))
          if not a.verify_only:
            existing_tables=[]
            for t in tables:
              cur.execute(sql.SQL('SELECT COUNT(*) FROM {}.{}').format(sql.Identifier(a.schema),sql.Identifier(t['name'])))
              n=cur.fetchone()[0]
              if n: existing_tables.append((t['name'],n))
            if existing_tables and not a.replace_target_data:
              raise RuntimeError('Target schema is not empty: '+repr(existing_tables[:20])+'. Use a dedicated empty schema or pass --replace-target-data explicitly.')
            if existing_tables:
              targets=sql.SQL(',').join(sql.SQL('{}.{}').format(sql.Identifier(a.schema),sql.Identifier(t['name'])) for t in tables)
              cur.execute(sql.SQL('TRUNCATE TABLE {} RESTART IDENTITY CASCADE').format(targets))
            for t in tables:
              name=t['name']; cols=[x['name'] for x in t['columns']]; pks=t['primary_key']
              stmt=sql.SQL('INSERT INTO {}.{} ({}) VALUES ({})').format(sql.Identifier(a.schema),sql.Identifier(name),sql.SQL(',').join(map(sql.Identifier,cols)),sql.SQL(',').join(sql.Placeholder() for _ in cols))
              offset=0
              while True:
                batch=src.execute('SELECT * FROM '+qname(name)+' LIMIT ? OFFSET ?',(a.batch_size,offset)).fetchall()
                if not batch: break
                cur.executemany(stmt,[tuple(row[c] for c in cols) for row in batch]); offset+=len(batch)
          # Verify counts in target and record run. Verify-only never copies data.
          for t in tables:
            cur.execute(sql.SQL('SELECT COUNT(*) FROM {}.{}').format(sql.Identifier(a.schema),sql.Identifier(t['name'])))
            dest_count=cur.fetchone()[0]
            item=next(x for x in report['tables'] if x['table']==t['name'])
            item.update({'destination_rows':dest_count,'verified':dest_count==t['rows']})
          if not a.verify_only and any(x.get('verified') is False for x in report['tables']): raise RuntimeError('Row count mismatch; transaction rolled back.')
          cur.execute(sql.SQL('INSERT INTO {}.{} (run_id,started_at,source_path,report) VALUES (%s,%s,%s,%s::jsonb)').format(sql.Identifier(a.schema),sql.Identifier('_nck_migration_runs_v32')),
            (report['run_id'],datetime.now(timezone.utc),report['source'],json.dumps(report,default=str)))
    src.close()
    report['completed_at']=datetime.now(timezone.utc).isoformat()
    report['all_row_counts_verified']=all(x.get('verified') for x in report['tables'])
    print(json.dumps(report,indent=2,default=str))
    if not report['all_row_counts_verified']: raise SystemExit(2)
if __name__=='__main__': main()
