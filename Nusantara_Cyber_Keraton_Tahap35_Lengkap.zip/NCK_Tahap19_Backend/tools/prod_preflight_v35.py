#!/usr/bin/env python3
"""Tahap 35 - pemeriksaan pasca-deploy terhadap URL HIDUP (hanya pustaka standar Python).

Pemakaian:
  python tools/prod_preflight_v35.py --url https://nama.onrender.com --viewer-token TOKEN [--frontend-origin https://nama.github.io]
Variabel lingkungan setara: NCK_BASE_URL, NCK_VIEWER_TOKEN, NCK_FRONTEND_ORIGIN (token sebaiknya lewat env/secret, bukan argumen).
Opsi: --allow-http (uji lokal; HTTP jadi PERINGATAN, bukan GAGAL), --wait DETIK (tunggu server bangun, default 120).

Keluar kode 1 bila ada GAGAL. Token tidak pernah dicetak. Waktu tunggu awal memang perlu: layanan Render Free
yang sedang tidur butuh sekitar satu menit untuk bangun.
"""
import argparse
import json
import os
import ssl
import sys
import time
import urllib.error
import urllib.request

RES = {'PASS': 0, 'WARN': 0, 'FAIL': 0}


def say(level, msg):
    RES[level] += 1
    print(f'{level:<5} {msg}')


def call(base, path, method='GET', token=None, headers=None, timeout=30):
    h = {'Accept': 'application/json', 'User-Agent': 'nck-preflight/35'}
    if token:
        h['X-NCK-Token'] = token
    h.update(headers or {})
    req = urllib.request.Request(base + path, method=method, headers=h)
    t0 = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ssl.create_default_context()) as r:
            body, code, hd = r.read(), r.status, dict(r.headers)
    except urllib.error.HTTPError as e:
        body, code, hd = e.read(), e.code, dict(e.headers)
    ms = (time.perf_counter() - t0) * 1000.0
    hd = {k.lower(): v for k, v in hd.items()}
    try:
        js = json.loads(body.decode('utf-8', 'replace')) if body else None
    except ValueError:
        js = None
    return code, js, hd, ms


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--url', default=os.environ.get('NCK_BASE_URL', ''))
    ap.add_argument('--viewer-token', default=os.environ.get('NCK_VIEWER_TOKEN', ''))
    ap.add_argument('--frontend-origin', default=os.environ.get('NCK_FRONTEND_ORIGIN', ''))
    ap.add_argument('--allow-http', action='store_true')
    ap.add_argument('--wait', type=int, default=120)
    a = ap.parse_args()
    base = a.url.strip().rstrip('/')
    if not base:
        sys.exit('GAGAL: --url (atau NCK_BASE_URL) wajib diisi.')
    tok = a.viewer_token.strip()

    # 1. HTTPS
    if base.startswith('https://'):
        say('PASS', 'URL memakai HTTPS.')
    elif a.allow_http:
        say('WARN', 'URL memakai HTTP (diizinkan untuk uji lokal; tidak untuk produksi).')
    else:
        say('FAIL', 'URL memakai HTTP biasa; produksi wajib HTTPS.')

    # 2. server hidup (tunggu bila sedang bangun dari tidur)
    t_start, code, ms, hd, last = time.time(), None, 0.0, {}, ''
    while True:
        try:
            code, js, hd, ms = call(base, '/health')
            if code == 200:
                break
        except (urllib.error.URLError, OSError, TimeoutError) as e:
            code = None
            last = type(e).__name__
        if time.time() - t_start > a.wait:
            break
        time.sleep(5)
    waited = time.time() - t_start
    if code != 200:
        say('FAIL', f'/health tidak menjawab 200 dalam {a.wait} dtk (terakhir: {code if code else last}).')
        print(f'\nRINGKAS: {RES["PASS"]} lulus, {RES["WARN"]} peringatan, {RES["FAIL"]} gagal')
        sys.exit(1)
    say('PASS', f'/health 200 ({ms:.0f} ms' + (f'; server perlu ~{waited:.0f} dtk untuk bangun' if waited > 8 else '') + ').')
    if waited > 8:
        say('WARN', 'Server lambat bangun: tipikal Render Free setelah 15 menit tanpa trafik (bukan galat).')

    # 3. kesiapan database
    code, js, _, ms = call(base, '/ready')
    if code == 200 and js and js.get('ready') is True:
        say('PASS', f'/ready 200: database menjawab ({js.get("db_ms")} ms).')
    else:
        say('FAIL', f'/ready tidak 200 (kode {code}): database tidak siap.')

    # 4. kontrol akses
    code, *_ = call(base, '/api/v35/ops/status')
    say('PASS' if code == 401 else 'FAIL', f'Tanpa token -> {code} (harus 401).')
    code, *_ = call(base, '/api/v35/ops/status', token='token-salah-' + 'x' * 30)
    say('PASS' if code == 403 else 'FAIL', f'Token salah -> {code} (harus 403).')

    # 5. header keamanan
    code, _, hd, _ = call(base, '/health')
    need = {'x-content-type-options': 'nosniff', 'x-frame-options': 'DENY', 'referrer-policy': 'no-referrer'}
    miss = [k for k, v in need.items() if hd.get(k, '').lower() != v.lower()]
    say('PASS' if not miss else 'FAIL', 'Header keamanan lengkap.' if not miss else 'Header keamanan kurang: ' + ', '.join(miss))
    say('PASS' if hd.get('x-request-id') else 'WARN', 'X-Request-ID ada.' if hd.get('x-request-id') else 'X-Request-ID tidak ada.')
    if base.startswith('https://'):
        say('PASS' if 'max-age' in hd.get('strict-transport-security', '') else 'FAIL',
            'HSTS aktif.' if 'max-age' in hd.get('strict-transport-security', '') else 'HSTS tidak dikirim (set NCK_FORCE_HTTPS=1).')

    # 6. CORS
    code, _, hd, _ = call(base, '/api/v35/ops/status', method='OPTIONS',
                          headers={'Origin': 'https://evil.example', 'Access-Control-Request-Method': 'GET',
                                   'Access-Control-Request-Headers': 'x-nck-token'})
    acao = hd.get('access-control-allow-origin', '')
    say('PASS' if acao in ('',) else 'FAIL', 'Origin asing ditolak CORS.' if not acao else f'Origin asing DIIZINKAN CORS ({acao}) - bahaya.')
    if a.frontend_origin:
        code, _, hd, _ = call(base, '/api/v35/ops/status', method='OPTIONS',
                              headers={'Origin': a.frontend_origin, 'Access-Control-Request-Method': 'GET',
                                       'Access-Control-Request-Headers': 'x-nck-token'})
        ok = hd.get('access-control-allow-origin', '') == a.frontend_origin
        say('PASS' if ok else 'FAIL', 'Origin frontend Anda diizinkan CORS.' if ok else 'Origin frontend Anda DITOLAK CORS (periksa NCK_CORS_ORIGINS, tanpa garis miring akhir).')
    else:
        say('WARN', 'Origin frontend tidak diberikan; uji CORS positif dilewati.')

    # 7. kesiapan produksi dari server
    if not tok:
        say('WARN', 'Token viewer tidak diberikan; pemeriksaan kesiapan sisi-server dilewati.')
    else:
        code, js, _, _ = call(base, '/api/v35/ops/status', token=tok)
        if code == 200:
            rel = js.get('release', {}).get('commit', '?')
            say('PASS', f'Token viewer valid. Versi {js.get("version")}, commit {rel[:10]}, database {js.get("database")}, uptime {js.get("uptime_seconds")} dtk.')
        else:
            say('FAIL', f'Token viewer ditolak ({code}).')
        code, js, _, _ = call(base, '/api/v35/ops/readiness', token=tok)
        if code == 200 and js:
            print('--- daftar periksa dari server ---')
            for c in js['checks']:
                lv = {'pass': 'PASS', 'warn': 'WARN', 'fail': 'FAIL', 'info': None}[c['status']]
                if lv:
                    say(lv, f'{c["label"]}: {c["detail"]}' + (f'  -> {c["fix"]}' if c['fix'] and lv != 'PASS' else ''))
                else:
                    print(f'INFO  {c["label"]}: {c["detail"]}')
            print(f'Putusan server: {js["summary"]["verdict"]}')
            print('Batas pemeriksaan ini:')
            for ln in js.get('limits', []):
                print('  - ' + ln)
        else:
            say('FAIL', f'/api/v35/ops/readiness gagal (kode {code}).')

    print(f'\nRINGKAS: {RES["PASS"]} lulus, {RES["WARN"]} peringatan, {RES["FAIL"]} gagal')
    sys.exit(1 if RES['FAIL'] else 0)


if __name__ == '__main__':
    main()
