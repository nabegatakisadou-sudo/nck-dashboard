#!/usr/bin/env bash
# Tahap 35 - pustaka kecil: pilih pg_dump / pg_restore yang versi MAYOR-nya sama dengan server.
# Dipakai dengan:  source tools/pgtools_v35.sh ; pgt_init "$DSN"
# Alasan: pg_dump >= 17 menulis "SET transaction_timeout" yang ditolak server PostgreSQL 16 (CI Tahap 34 #2).
# Urutan pilihan: (1) biner berversi di $NCK_PG_BIN_ROOT/<mayor>/bin (default /usr/lib/postgresql)
#                 (2) pg_dump & pg_restore di PATH bila mayornya sama
#                 (3) image docker postgres:<mayor> dengan --network host (tanpa apt)
# Paksa dengan NCK_PG_TOOLS=local|docker (default auto). Berkas dump selalu berada di $PGT_WORK.
PGT_MODE=""; PGT_BIN=""; PGT_IMAGE=""; PGT_MAJOR=""

pgt_major_of() { "$1" --version 2>/dev/null | sed -E 's/[^0-9]*([0-9]+).*/\1/'; }

# pgt_init <dsn> <workdir>  -> mengisi PGT_MODE/PGT_BIN/PGT_IMAGE/PGT_MAJOR dan PGT_WORK (mutlak)
pgt_init() {
  local dsn="$1"; PGT_WORK="$2"
  mkdir -p "$PGT_WORK"; PGT_WORK="$(cd "$PGT_WORK" && pwd)"
  local vnum
  vnum=$(psql "$dsn" -qAt -c "SHOW server_version_num" 2>/dev/null) || { echo "GAGAL: tidak bisa terhubung ke database (periksa DSN, kata sandi, dan jaringan)." >&2; return 1; }
  [[ "$vnum" =~ ^[0-9]+$ ]] || { echo "GAGAL: versi server PostgreSQL tidak terbaca." >&2; return 1; }
  PGT_MAJOR=$(( vnum / 10000 ))
  local want="${NCK_PG_TOOLS:-auto}" d="${NCK_PG_BIN_ROOT:-/usr/lib/postgresql}/$PGT_MAJOR/bin"
  if [ "$want" != "docker" ]; then
    if [ -x "$d/pg_dump" ] && [ -x "$d/pg_restore" ]; then PGT_MODE=local; PGT_BIN="$d"; return 0; fi
    if command -v pg_dump >/dev/null 2>&1 && command -v pg_restore >/dev/null 2>&1 \
       && [ "$(pgt_major_of pg_dump)" = "$PGT_MAJOR" ] && [ "$(pgt_major_of pg_restore)" = "$PGT_MAJOR" ]; then
      PGT_MODE=local; PGT_BIN="$(dirname "$(command -v pg_dump)")"; return 0
    fi
  fi
  if [ "$want" != "local" ] && command -v docker >/dev/null 2>&1; then
    PGT_MODE=docker; PGT_IMAGE="postgres:$PGT_MAJOR"; return 0
  fi
  echo "GAGAL: tidak ada pg_dump/pg_restore PostgreSQL $PGT_MAJOR yang cocok, dan docker tidak tersedia atau dimatikan (NCK_PG_TOOLS=${NCK_PG_TOOLS:-auto})." >&2
  return 1
}

# pgt_dump <dsn> <nama-berkas-di-PGT_WORK> [skema]
pgt_dump() {
  local dsn="$1" f="$2" schema="${3:-}" extra=()
  [ -n "$schema" ] && extra=(-n "$schema")
  if [ "$PGT_MODE" = docker ]; then
    docker run --rm --network host -v "$PGT_WORK:/out" --entrypoint pg_dump "$PGT_IMAGE" "$dsn" ${extra[@]+"${extra[@]}"} --no-owner --no-privileges -Fc -f "/out/$f"
  else
    "$PGT_BIN/pg_dump" "$dsn" ${extra[@]+"${extra[@]}"} --no-owner --no-privileges -Fc -f "$PGT_WORK/$f"
  fi
}

# pgt_restore <dsn-tujuan> <nama-berkas-di-PGT_WORK>   (galat apa pun = gagal)
pgt_restore() {
  local dsn="$1" f="$2"
  if [ "$PGT_MODE" = docker ]; then
    docker run --rm --network host -v "$PGT_WORK:/out" --entrypoint pg_restore "$PGT_IMAGE" --no-owner --no-privileges --exit-on-error -d "$dsn" "/out/$f"
  else
    "$PGT_BIN/pg_restore" --no-owner --no-privileges --exit-on-error -d "$dsn" "$PGT_WORK/$f"
  fi
}

# pgt_list <nama-berkas-di-PGT_WORK>   (memeriksa arsip terbaca; tidak butuh database)
pgt_list() {
  local f="$1"
  if [ "$PGT_MODE" = docker ]; then
    docker run --rm -v "$PGT_WORK:/out" --entrypoint pg_restore "$PGT_IMAGE" --list "/out/$f"
  else
    "$PGT_BIN/pg_restore" --list "$PGT_WORK/$f"
  fi
}

# pgt_counts <dsn> <skema>  -> baris "tabel|jumlah" untuk setiap tabel dasar di skema (satu query)
pgt_counts() {
  psql "$1" -qAt -F'|' -c "SELECT table_name, (xpath('/row/c/text()', query_to_xml(format('select count(*) as c from %I.%I', table_schema, table_name), false, true, '')))[1]::text::bigint FROM information_schema.tables WHERE table_schema='$2' AND table_type='BASE TABLE' ORDER BY 1"
}
