#!/usr/bin/env python3
"""Read-only SQLite schema inventory and PostgreSQL portability report; no psycopg required."""
import argparse,json,sqlite3
from pathlib import Path

def qname(s): return '"'+s.replace('"','""')+'"'
def inventory(src):
    src.row_factory=sqlite3.Row
    objects=src.execute("SELECT type,name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name").fetchall()
    tables=[]
    for o in objects:
        if o['type']!='table': continue
        name=o['name']; info=src.execute(f'PRAGMA table_info({json.dumps(name)})').fetchall()
        fks=src.execute(f'PRAGMA foreign_key_list({json.dumps(name)})').fetchall()
        indexes=src.execute(f'PRAGMA index_list({json.dumps(name)})').fetchall()
        pks=[r['name'] for r in sorted(info,key=lambda x:x['pk']) if r['pk']]
        tables.append({'name':name,'columns':[dict(x) for x in info],'primary_key':pks,'foreign_keys':[dict(x) for x in fks],
          'indexes':[dict(x) for x in indexes],'rows':src.execute(f'SELECT COUNT(*) FROM {qname(name)}').fetchone()[0]})
    return tables,[{'type':o['type'],'name':o['name'],'sql':o['sql']} for o in objects if o['type']!='table']
p=argparse.ArgumentParser();p.add_argument('--sqlite',required=True);p.add_argument('--output',default='nck_schema_audit_v32.json');a=p.parse_args()
c=sqlite3.connect(f'file:{Path(a.sqlite).resolve()}?mode=ro',uri=True);c.row_factory=sqlite3.Row
integrity=c.execute('PRAGMA integrity_check').fetchone()[0]; fks=[dict(x) for x in c.execute('PRAGMA foreign_key_check')]
tables,objects=inventory(c)
report={'integrity':integrity,'foreign_key_issues':fks,'tables':tables,'views_triggers_indexes':objects,
 'manual_review_required':[{'table':t['name'],'index':i['name']} for t in tables for i in t['indexes'] if i.get('partial')],
 'cutover_recommendation':'BLOCKED' if integrity!='ok' or fks else 'REVIEW_REQUIRED'}
Path(a.output).write_text(json.dumps(report,indent=2,default=str));print(json.dumps(report,indent=2,default=str));c.close()
