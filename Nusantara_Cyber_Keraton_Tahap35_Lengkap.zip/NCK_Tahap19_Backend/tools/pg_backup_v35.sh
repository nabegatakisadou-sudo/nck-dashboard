#!/usr/bin/env bash
# Tahap 35 - backup PostgreSQL TERVERIFIKASI.
# Langkah: hitung baris -> pg_dump (-Fc) -> hitung baris lagi -> cek arsip terbaca & memuat SETIAP tabel -> sha256
#          -> (opsional) enkripsi AES-256 + uji putar-balik dekripsi -> tulis backup_meta.json.
# Env wajib : NCK_BACKUP_DSN        DSN URI database yang dicadangkan (disarankan pengguna read-only)
# Env opsi  : NCK_BACKUP_SCHEMA     skema yang dicadangkan (default: public)
#             NCK_BACKUP_OUT        folder keluaran (default ./nck-backup-out; DIHAPUS dulu lalu dibuat ulang)
#             NCK_BACKUP_PASSPHRASE sandi enkripsi (>=12 karakter). Kosong = backup TIDAK terenkripsi (diberi peringatan).
#             NCK_PG_TOOLS / NCK_PG_BIN_ROOT  lihat tools/pgtools_v35.sh
# Keluaran  : <OUT>/nck_backup_<UTC>.dump(.enc) + <OUT>/backup_meta.json ; juga ke $GITHUB_OUTPUT bila ada.
# Keluar kode 1 pada kegagalan apa pun (backup yang tidak bisa diverifikasi dianggap GAGAL).
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
# shellcheck source=pgtools_v35.sh
source "$HERE/pgtools_v35.sh"
fail() { echo "GAGAL: $*" >&2; exit 1; }
: "${NCK_BACKUP_DSN:?NCK_BACKUP_DSN wajib diisi (DSN database yang dicadangkan)}"
SCHEMA="${NCK_BACKUP_SCHEMA:-public}"
OUT="${NCK_BACKUP_OUT:-./nck-backup-out}"
PASS="${NCK_BACKUP_PASSPHRASE:-}"
if [ -n "$PASS" ] && [ "${#PASS}" -lt 12 ]; then fail "NCK_BACKUP_PASSPHRASE terlalu pendek (minimal 12 karakter)."; fi
[[ "$SCHEMA" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] || fail "nama skema tidak valid: $SCHEMA"
sha() { sha256sum "$1" | cut -d' ' -f1; }

rm -rf "$OUT"; mkdir -p "$OUT"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
pgt_init "$NCK_BACKUP_DSN" "$OUT" || exit 1
echo "server PostgreSQL mayor=$PGT_MAJOR; alat dump: mode=$PGT_MODE ${PGT_BIN}${PGT_IMAGE}; skema=$SCHEMA"

pgt_counts "$NCK_BACKUP_DSN" "$SCHEMA" > "$TMP/before.txt" || fail "tidak bisa membaca database (periksa DSN/jaringan)."
NT=$(wc -l < "$TMP/before.txt" | tr -d ' ')
[ "$NT" -ge 1 ] || fail "skema '$SCHEMA' tidak memiliki tabel; backup kosong ditolak (salah skema atau database kosong?)."
echo "tabel di sumber: $NT"

STAMP=$(date -u +%Y%m%dT%H%M%SZ)
FILE="nck_backup_${STAMP}.dump"
pgt_dump "$NCK_BACKUP_DSN" "$FILE" "$SCHEMA" || fail "pg_dump gagal."
[ -s "$OUT/$FILE" ] || fail "berkas dump kosong."
pgt_counts "$NCK_BACKUP_DSN" "$SCHEMA" > "$TMP/after.txt" || fail "gagal menghitung baris setelah dump."

# arsip harus terbaca dan memuat data SETIAP tabel sumber
pgt_list "$FILE" > "$TMP/toc.txt" 2>"$TMP/toc.err" || fail "arsip tidak terbaca oleh pg_restore --list: $(head -c 300 "$TMP/toc.err")"
while IFS='|' read -r t _; do
  grep -qF "TABLE DATA $SCHEMA $t " "$TMP/toc.txt" || fail "tabel '$t' tidak ada di arsip dump."
done < "$TMP/before.txt"
echo "arsip terbaca; semua $NT tabel ada di dalamnya"

PLAIN_SHA=$(sha "$OUT/$FILE"); STORED="$FILE"; ENC=false
if [ -n "$PASS" ]; then
  export NCK_BACKUP_PASSPHRASE="$PASS"
  openssl enc -aes-256-cbc -pbkdf2 -iter 200000 -salt -in "$OUT/$FILE" -out "$OUT/$FILE.enc" -pass env:NCK_BACKUP_PASSPHRASE || fail "enkripsi gagal."
  openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 -in "$OUT/$FILE.enc" -out "$TMP/roundtrip.dump" -pass env:NCK_BACKUP_PASSPHRASE || fail "uji dekripsi gagal."
  [ "$(sha "$TMP/roundtrip.dump")" = "$PLAIN_SHA" ] || fail "uji putar-balik enkripsi menghasilkan data berbeda."
  rm -f "$OUT/$FILE" "$TMP/roundtrip.dump"
  STORED="$FILE.enc"; ENC=true
  echo "terenkripsi AES-256-CBC (PBKDF2); uji dekripsi putar-balik cocok; berkas polos dihapus"
else
  echo "PERINGATAN: NCK_BACKUP_PASSPHRASE kosong -> backup TIDAK terenkripsi. Jangan simpan di tempat yang dapat dibaca orang lain." >&2
fi
SIZE=$(stat -c %s "$OUT/$STORED"); STORED_SHA=$(sha "$OUT/$STORED")

BEFORE="$TMP/before.txt" AFTER="$TMP/after.txt" META="$OUT/backup_meta.json" M_FILE="$STORED" M_SHA="$STORED_SHA" M_PLAIN="$PLAIN_SHA" \
M_SIZE="$SIZE" M_ENC="$ENC" M_MAJOR="$PGT_MAJOR" M_SCHEMA="$SCHEMA" M_MODE="$PGT_MODE" python3 - <<'PYEOF'
import json, os, datetime
def rd(p):
    d = {}
    for ln in open(p, encoding='utf-8'):
        ln = ln.strip()
        if ln:
            k, v = ln.rsplit('|', 1)
            d[k] = int(v)
    return d
b, a = rd(os.environ['BEFORE']), rd(os.environ['AFTER'])
tables = {t: {'before': b[t], 'after': a.get(t, b[t])} for t in b}
meta = {'format': 'nck-pg-backup-v35', 'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'),
        'server_major': int(os.environ['M_MAJOR']), 'schema': os.environ['M_SCHEMA'], 'file': os.environ['M_FILE'],
        'bytes': int(os.environ['M_SIZE']), 'sha256': os.environ['M_SHA'], 'plain_sha256': os.environ['M_PLAIN'],
        'encrypted': os.environ['M_ENC'] == 'true', 'tool_mode': os.environ['M_MODE'], 'tables': tables,
        'total_rows_before': sum(b.values()), 'total_rows_after': sum(a.get(t, b[t]) for t in b)}
json.dump(meta, open(os.environ['META'], 'w'), indent=1)
print('meta ditulis: %d tabel, %d baris' % (len(tables), meta['total_rows_before']))
PYEOF

echo "== BACKUP BERHASIL: $STORED ($SIZE byte, sha256 ${STORED_SHA:0:16}...) =="
if [ -n "${GITHUB_OUTPUT:-}" ]; then
  { echo "file=$STORED"; echo "bytes=$SIZE"; echo "sha256=$STORED_SHA"; echo "encrypted=$ENC"; } >> "$GITHUB_OUTPUT"
fi
