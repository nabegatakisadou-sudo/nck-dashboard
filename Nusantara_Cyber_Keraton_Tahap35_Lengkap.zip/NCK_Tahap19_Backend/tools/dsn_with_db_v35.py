#!/usr/bin/env python3
"""Tahap 35 - ganti nama database pada DSN bentuk URI (query seperti ?host=... atau ?sslmode=... dipertahankan).
Pemakaian: python tools/dsn_with_db_v35.py "<dsn>" <nama_db>
Kata sandi tidak pernah dicetak selain di DSN keluaran yang memang diminta."""
import sys
from urllib.parse import quote, urlsplit, urlunsplit

if len(sys.argv) != 3:
    sys.exit('pemakaian: dsn_with_db_v35.py <dsn-uri> <nama_db>')
dsn, db = sys.argv[1].strip(), sys.argv[2]
if '://' not in dsn:
    sys.exit('GAGAL: DSN harus berbentuk URI postgresql://...')
u = urlsplit(dsn)
print(urlunsplit((u.scheme, u.netloc, '/' + quote(db, safe=''), u.query, u.fragment)))
