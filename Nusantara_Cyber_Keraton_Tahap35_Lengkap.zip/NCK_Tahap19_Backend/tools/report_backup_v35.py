#!/usr/bin/env python3
"""Tahap 35 - laporkan hasil backup / latihan restore ke API NCK (POST /api/v35/ops/backup-report, perlu token ADMIN).
Env: NCK_BASE_URL, NCK_ADMIN_TOKEN (token tidak pernah dicetak). Server Render Free bisa tidur: skrip menunggu sampai --wait detik.
Pemakaian: python tools/report_backup_v35.py --kind backup --ok true --meta nck-backup-out/backup_meta.json [--detail "teks"]
           python tools/report_backup_v35.py --kind restore_drill --ok false --detail "pg_restore gagal"
Keluar 0 bila tercatat, 1 bila gagal."""
import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request

ap = argparse.ArgumentParser()
ap.add_argument('--kind', required=True, choices=['backup', 'restore_drill'])
ap.add_argument('--ok', required=True, choices=['true', 'false'])
ap.add_argument('--meta', default='')
ap.add_argument('--bytes', type=int, default=0)
ap.add_argument('--sha256', default='')
ap.add_argument('--detail', default='')
ap.add_argument('--source', default=os.environ.get('NCK_REPORT_SOURCE', 'github-actions'))
ap.add_argument('--wait', type=int, default=120)
a = ap.parse_args()
base, tok = os.environ.get('NCK_BASE_URL', '').strip().rstrip('/'), os.environ.get('NCK_ADMIN_TOKEN', '').strip()
if not base or not tok:
    sys.exit('GAGAL: NCK_BASE_URL dan NCK_ADMIN_TOKEN wajib diisi.')
size, sha = a.bytes, a.sha256
if a.meta:
    m = json.load(open(a.meta, encoding='utf-8'))
    size, sha = int(m.get('bytes', 0)), str(m.get('sha256', ''))
body = json.dumps({'kind': a.kind, 'ok': a.ok == 'true', 'bytes': size, 'sha256': sha, 'detail': a.detail[:800], 'source': a.source[:60]}).encode()
t0, last = time.time(), ''
while True:
    req = urllib.request.Request(base + '/api/v35/ops/backup-report', data=body, method='POST',
                                 headers={'Content-Type': 'application/json', 'X-NCK-Token': tok, 'User-Agent': 'nck-report/35'})
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            if r.status == 200:
                print(f'Tercatat di server: kind={a.kind} ok={a.ok}')
                sys.exit(0)
            last = f'HTTP {r.status}'
    except urllib.error.HTTPError as e:
        last = f'HTTP {e.code}'
        if e.code in (400, 401, 403, 404, 422):   # kesalahan permanen: jangan diulang
            sys.exit(f'GAGAL melapor ({last}); periksa NCK_BASE_URL dan NCK_ADMIN_TOKEN.')
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        last = type(e).__name__
    if time.time() - t0 > a.wait:
        sys.exit(f'GAGAL melapor dalam {a.wait} dtk (terakhir: {last}).')
    time.sleep(5)
