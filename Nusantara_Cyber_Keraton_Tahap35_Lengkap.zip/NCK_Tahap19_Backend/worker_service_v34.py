"""NCK worker mandiri (Tahap 34) — memproses antrean tugas AI tanpa melayani HTTP.

Dipakai untuk deployment terdistribusi: satu/lebih instance API (NCK_WORKER_MODE=api) + satu/lebih proses ini,
semuanya memakai PostgreSQL yang SAMA (NCK_DB_BACKEND=postgres). Antrean memakai klaim atomik (SELECT ... FOR UPDATE SKIP LOCKED),
heartbeat, dan pemulihan tugas yatim saat worker mati. Semantik pengiriman: AT-LEAST-ONCE (tugas dapat dijalankan ulang bila
worker membeku lebih lama dari NCK_WORKER_STALE_SECONDS; hasil pertama yang tercatat yang dipakai).

Jalankan:  python worker_service_v34.py      (env sama dengan API: NCK_POSTGRES_DSN, OPENAI_API_KEY/GEMINI_API_KEY, dst.)
Berhenti terkendali: SIGTERM/SIGINT -> menunggu tugas berjalan hingga NCK_SHUTDOWN_GRACE_SECONDS, sisanya dikembalikan ke antrean.
"""
import asyncio
import os
import signal
import sys

os.environ['NCK_WORKER_MODE'] = 'worker'
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import main  # noqa: E402  (memuat aplikasi; tidak membuka port)

STARTUP_ATTEMPTS = int(os.environ.get('NCK_WORKER_STARTUP_ATTEMPTS', '4'))


async def _enter_lifespan():
    """Jalankan semua handler startup lewat lifespan aplikasi (berlaku untuk FastAPI/Starlette lama maupun baru).
    Handler idempoten (CREATE ... IF NOT EXISTS); bila gagal (mis. database belum siap) ulangi beberapa kali."""
    last = None
    for attempt in range(1, STARTUP_ATTEMPTS + 1):
        cm = main.app.router.lifespan_context(main.app)
        try:
            await cm.__aenter__()
            return cm
        except Exception as exc:  # noqa: BLE001
            last = exc
            print(f'[worker] startup percobaan {attempt}/{STARTUP_ATTEMPTS} gagal: {exc!r}'[:400], flush=True)
            await asyncio.sleep(min(1.5 * attempt, 5))
    raise SystemExit(f'[worker] startup gagal setelah {STARTUP_ATTEMPTS} percobaan: {last!r}'[:500])


async def _serve():
    loop = asyncio.get_running_loop()
    stop = asyncio.Event()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, stop.set)
    cm = await _enter_lifespan()
    print(f'[worker] aktif id={main._WORKER_ID27} slot={main._WORKER_CAP27} db={main.nck_db.BACKEND} '
          f'stale={main.NCK_WORKER_STALE34}s heartbeat={main.NCK_HEARTBEAT34}s', flush=True)
    while not stop.is_set():
        try:
            await asyncio.wait_for(stop.wait(), 300)
        except asyncio.TimeoutError:
            print(f'[worker] hidup id={main._WORKER_ID27}', flush=True)
    print('[worker] sinyal berhenti diterima; menyelesaikan tugas berjalan...', flush=True)
    released = await loop.run_in_executor(None, main.graceful_shutdown34)
    print(f'[worker] berhenti; {len(released)} tugas dikembalikan ke antrean.', flush=True)
    try:
        await cm.__aexit__(None, None, None)   # handler shutdown aplikasi (graceful_shutdown34 bersifat idempoten)
    except Exception:  # noqa: BLE001
        pass


def run():
    try:
        asyncio.run(_serve())
    finally:
        sys.stdout.flush()
        os._exit(0)   # thread worker daemon yang masih menunggu LLM tidak boleh menahan proses


if __name__ == '__main__':
    run()
